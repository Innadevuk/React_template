# OE-DynamicPage

- components
- listeners
- routes
- styles
- utils

## Content

- ReactJS 16.8+
- Webpack 4.19+

## Usage

### Prerequisite

Ensure to have NodeJS v12.13.1
NPM 6.12.1
Yarn 1.21.0

### Installation

`# clone the repo git clone git@bitbucket.org:OpenZNet/oe-dynamicpage.git`

`# dev server with hot reload at http://localhost:3000`

`$ yarn install`

`$ yarn start`

`$ for production yarn build`

Navigate to http://localhost:3000. The app will automatically reload if you change any of the source files.

### Technologies used

- [Webpack 4](https://github.com/webpack/webpack)
- [Babel 7](https://github.com/babel/babel) [ transforming JSX and ES6,ES7,ES8 ]
- [React](https://github.com/facebook/react) `16.8`
- [Style](https://github.com/webpack-contrib/style-loader)
- [CSS Loader](https://github.com/webpack-contrib/css-loader)
- [SASS-loader](https://github.com/webpack-contrib/sass-loader)
- [File-Loader](https://github.com/webpack-contrib/file-loader)
- [Axios](https://github.com/axios/axios)

## Copyright and License

Copyright ©2019. OpenZNet,Inc. Mountain View, CA 94040
All Rights Reserved. Permission to use, copy, modify, and distribute this software is held by OpenZNet Inc. Contact us: info@openznet.com for commercial licensing opportunities.

IN NO EVENT SHALL OpenZNET BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST
PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF OpenZNet HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

OpenZNet SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS". OpenZNet HAS NO
OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
