import React from 'react'
import ReactPlayer from 'react-player'

const GRAPHQL_URIS = {
  https: 'https://backend-dev.oelement.openznet.com:4001',
  wss: 'wss://backend-dev.oelement.openznet.com:4001',
}

export const EMAIL_NOW_API_URL =
  'https://backend-dev.oelement.openznet.com:4001/api/communication/emailNow'
export const DEV_CLIENT = 'oelement.net'

const QA = [
  {
    question: 'How do you connect with your end-users directly and quickly?',
    answer: (
      <div>
        Can your organization reach targeted end-users with the most up-to-date and relevant
        information in real-time? Can your communication platform provide rich multimedia messages
        in a format that is easy-to-digest by the end-users? Do you require help from software
        developers to change or update information on your website or mobile apps?
        <br />
        <br />
        Crisis management is not an easy task in high-stake stressful situations, our
        state-of-the-art communication platform makes it easy for officials to use to provide
        relevant and up-to-date information in real-time to any or all platforms and applications.
      </div>
    ),
  },
  {
    question: 'What is different about O-Element Multimedia Notification Platform?',
    answer: (
      <div>
        There is currently no other solution in the market to create geo-targeted and schedule-based
        authoring tool that can be deployed without expensive customized development process that
        may not meet all the demands of ever-changing landscape of notifications requirement.
        <br />
        <br />
        Our intuitive and easy-to-use dashboard can provide all the tools to create a multimedia
        notification from creation or ingest to publishing directly to the users in matter of
        minutes. while eliminating the need to have a software developer and website manager to do
        the task. Creating an interactive multimedia event notification is as easy as filling out a
        few form-entries with the most relevant information to the event.
        <br />
        <br />
        Our tools creates a readers-digest interactive version of the information that is easy to
        drill-down to get more information, instead of overwhelming the end-users with massive
        amount of textual or images that is provided in a typical website with myriads of links and
        pages.
      </div>
    ),
  },
  {
    question: 'Why is it important to deploy this Platform now?',
    answer: (
      <div>
        In the age of information technology, where consumable and relevant content is transient and
        can quickly be obsoleted as soon as it is published, it is important to have the right
        communication tools to easily and quickly convey most-up-to-date and critical information to
        the end-users.
        <br />
        <br />
        The ability to easily create a consistent flow of information reliably that is based on
        location, schedule, or personalized user preferences, is more important now than ever to
        harbor a loyal and recurring visitors to your online Digital presence.
      </div>
    ),
  },
  {
    question: 'How easy is it to deploy this Platform?',
    answer: (
      <div>
        We know how valuable your time is in this time of crisis, where you might be short-staffed,
        overwhelmed with all the nuances of your existing communication platforms and thought of
        adopting another technology may be a daunting. We are here to make this deployment process
        quick and fast, so you can immediately take advantage of its rich set of capabilities to
        make your day-to-day task easier. We can have a fully functioning addition to your digital
        presence in a matter of hours with very little integration effort from your team.
      </div>
    ),
  },
  {
    question: 'How easy is it to use this Platform?',
    answer: (
      <div>
        Creating a notification is as easy as filling out a few simple text fields and publishing
        them with a click of a button. The end-to-end creation time takes less than 15 seconds;
        watch the video to see how quickly you can create an event.
        <br />
        <div className="player-wrapper">
          <ReactPlayer
            url="https://s3.us-west-1.amazonaws.com/assets.oelement.openznet.com/images/1585064271011-lg.mov"
            controls
            width="100%"
            height="100%"
          />
        </div>
        <br />
        You can enhance the messages by stylizing and adding icons to meet the importance of the
        message you need to convey. Watch this 15 seconds video on how to stylize the notifications.
        <br />
        <div className="player-wrapper">
          <ReactPlayer
            url="https://s3.us-west-1.amazonaws.com/assets.oelement.openznet.com/images/1585069604848-lg.mp4"
            controls
            width="100%"
            height="100%"
          />
        </div>
        <br />
        To enrich the user experience even further, you can add additional content that has either
        been ingested from external sources or created with our full-featured
        what-you-see-is-what-you-get (WYSIWYG) editing tools. Watch the video demo below to see how
        easily you can create such enhancements.
        <br />
        <div className="player-wrapper">
          <ReactPlayer
            url="https://s3.us-west-1.amazonaws.com/assets.oelement.openznet.com/images/1585070637260-lg.mp4"
            controls
            width="100%"
            height="100%"
          />
        </div>
        <br />
        Creating a schedule-based notification enables you to communicate important information at
        specific or recurring schedules, just as you do scheduling an event on your calendar. Watch
        the video demo below to see how easily and quickly you can create a scheduled event.
        <br />
        <div className="player-wrapper">
          <ReactPlayer
            url="https://s3.us-west-1.amazonaws.com/assets.oelement.openznet.com/images/1585071771506-lg.mp4"
            controls
            width="100%"
            height="100%"
          />
        </div>
        <br />
        One of the most important feature of the platform is to create a location-specific
        notification that is visible ONLY to the users in the area. Creating a message with a
        geolocation is as easy as dropping a pin on a map. Watch the video demo below to see how to
        use the pin drop tool to create a hot spot for an event.
        <br />
        <div className="player-wrapper">
          <ReactPlayer
            url="https://s3.us-west-1.amazonaws.com/assets.oelement.openznet.com/images/1585075043239-lg.mp4"
            controls
            width="100%"
            height="100%"
          />
        </div>
        <br />
        There are myriads of other features that will be delivered as part of this platform. Please{' '}
        <a href="mailto:info@openznet.com">contact us</a> for a full demo and list of all features.
      </div>
    ),
  },
  {
    question: 'Can the Platform ingest content from other sources?',
    answer: (
      <div>
        The Platform enables ingesting of content from external sources and social media either
        directly on to the client side or ingested on the server-side to be further enriched with
        additional enhancements. As we are in the process of integrating with a myriads of external
        sources quickly, <a href="mailto:info@openznet.com">contact us</a> to see if your ingest
        source has already been integrated with our platform or how it be prioritized to be
        integrated.,
      </div>
    ),
  },
  {
    question: 'What kind of customer-service is provided?',
    answer: (
      <div>
        We provide a fully managed white-gloves service with a 24x7 call center with any information
        that you might need to ensure your success at your job. In addition, to a rich set of
        authoring tools, we can also provide a data-entry service to create your messaging and
        publish it to public. <a href="mailto:info@openznet.com">Contact us</a> for more information
        about our customer service.,
      </div>
    ),
  },
  {
    question: 'How does the Platform work?',
    answer: (
      <div>
        We use the latest proven technologies used by many large organizations such as Amazon,
        Google, and Facebook to provide the most up-to-date near real-time message notification. The
        Platform is built on a highly scalable Amazon Web Services and can be scaled to your usage
        needs.
      </div>
    ),
  },
  {
    question: 'What should I look for in the upcoming releases?',
    answer: (
      <div>
        We know how important it is to use the dashboard on any platform, anywhere, any time. We
        will soon offer a mobile version of the dashboard where you can easily and quickly create
        notification and other interactivity on-the-go to meet the demands of a fast-paced mobile
        environment. <a href="mailto:info@openznet.com">Contact us</a> to see the release date for
        the mobile version of the dashboard.
      </div>
    ),
  },
  {
    question: 'Can the Platform be used for other purposes?',
    answer: (
      <div>
        The Platform provides a wide range of usage in other industries such as targeted and
        political advertising and content catalog management, while providing an enriched
        value-added services that goes beyond watching the content. Our platform will soon be fully
        integrated with the broadcast newsroom tools using MOS APIs to provide a direct link between
        broadcast and broadband content. We also provide targeted advertising tools and management
        that can connect with any ad decision engine. Please{' '}
        <a href="https://www.openznet.com" target="_blank">
          visit our site
        </a>{' '}
        for our other services and offerings.
      </div>
    ),
  },
  {
    question: 'How to get an evaluation copy?',
    answer: (
      <div>
        We want to make sure you can experience of power of the Platform first-hand and see how it
        can make your day-to-day operation job easier.{' '}
        <a href="mailto:info@openznet.com">Contact us</a> to see how to get an evaluation copy.
      </div>
    ),
  },
  {
    question: 'What is the pricing like?',
    answer: (
      <div>
        We want to make a difference in the world. We can work with your organization to create a
        turn-key solution that fits your budgets and needs.{' '}
        <a href="mailto:info@openznet.com">Contact us</a> and see how we can work with your
        organization.
      </div>
    ),
  },
]

export { GRAPHQL_URIS, QA }
