import gql from 'graphql-tag'

const upsertTracking = gql`
  mutation upsertTracking(
    $_id: String!
    $collectionName: String!
    $serverId: String
    $url: String
    $userId: String
    $action: String!
    $comment: String
  ) {
    upsertTracking(
      _id: $_id
      collectionName: $collectionName
      serverId: $serverId
      url: $url
      userId: $userId
      action: $action
      comment: $comment
    ) {
      _id
      collectionName
      serverId
      IPaddress
      url
      userId
      action
      comment
      timestamp
    }
  }
`

const upsertEmail = gql`
  mutation upsertEmail($_id: String!, $collectionName: String!, $email: String!) {
    upsertEmail(_id: $_id, collectionName: $collectionName, email: $email)
  }
`

const upsertPhoneNumber = gql`
  mutation upsertPhoneNumber($_id: String!, $collectionName: String!, $phoneNumber: String!) {
    upsertPhoneNumber(_id: $_id, collectionName: $collectionName, phoneNumber: $phoneNumber)
  }
`

const deletePhoneNumber = gql`
  mutation deletePhoneNumber($_id: String!, $collectionName: String!, $phoneNumber: String!) {
    deletePhoneNumber(_id: $_id, collectionName: $collectionName, phoneNumber: $phoneNumber)
  }
`
const createGroupingMutation = gql`
  mutation createGrouping(
    $customerId: String
    $platformId: String
    $clientId: String
    $partitionId: String
    $siteId: String
    $appId: String
    $type: String
    $schemaType: String
    $name: String!
    $collectionName: String!
    $list: [ActiveIdInput]
    $presentationMode: PresentationModeInput
    $majorMinor: MajorMinorInput
    $schedule: ScheduleInput
    $availability: AvailabilityInput
    $schemaVersion: String
    $data: JSONObject
    $style: JSONObject
    $notification: String
    $rank: Int
  ) {
    createGrouping(
      customerId: $customerId
      platformId: $platformId
      clientId: $clientId
      partitionId: $partitionId
      siteId: $siteId
      appId: $appId
      type: $type
      schemaType: $schemaType
      name: $name
      collectionName: $collectionName
      list: $list
      presentationMode: $presentationMode
      majorMinor: $majorMinor
      schedule: $schedule
      availability: $availability
      schemaVersion: $schemaVersion
      data: $data
      style: $style
      notification: $notification
      rank: $rank
    ) {
      _id
      collectionName
      name
      customerId
      clientId
      partitionId
      siteId
      appId
      platformId
      type
      list {
        id
        active
      }
      presentationMode {
        firstViewMode
        firstViewModeValue
        majorUpdateMode
        majorUpdateModeValue
        minorUpdateMode
        minorUpdateModeValue
        recallMode
        recallModeValue
      }
      majorMinor {
        major
        minor
      }
      schedule {
        bActive
        bFilter
        startAt
        endAt
        recurrenceType
        repeatsEvery
        repeatsType
        repeatsOn
        endType
        endOn
        endAfter
        status
      }
      availability {
        state
      }
      notification
      schemaType
      schemaVersion
      data
      style
      articles {
        _id
        style
        name
        version
      }
      rank
      version
      state
      updatedAt
    }
  }
`

export { upsertTracking, upsertEmail, upsertPhoneNumber, deletePhoneNumber, createGroupingMutation }
