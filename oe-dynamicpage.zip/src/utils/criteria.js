import inside from 'point-in-polygon'

function arePointsNear(checkPoint, centerPoint, km) {
  const ky = 40000 / 360
  const kx = Math.cos((Math.PI * centerPoint.lat) / 180.0) * ky
  const dx = Math.abs(centerPoint.lng - checkPoint.lng) * kx
  const dy = Math.abs(centerPoint.lat - checkPoint.lat) * ky

  return Math.sqrt(dx * dx + dy * dy) <= km
}

function insideZones(checkPoint, zones, unit) {
  let km = 0.0
  switch (unit) {
    case 'feet':
      km = 0.0003048
      break
    case 'mile':
      km = 1.60934
      break
    case 'meter':
      km = 0.001
      break
    default:
      break
  }
  for (const i in zones) {
    if (arePointsNear(checkPoint, zones[i], km * zones[i].radius)) return true
  }

  return false
}

function isValidLocation(location, myGeo) {
  if (!myGeo) return true

  if (
    !location ||
    !location.bFilter ||
    !location.bActive ||
    !location.type ||
    location.type === 'none'
  ) {
    return true
  }

  let bValid = true
  switch (location.type) {
    case 'radius':
      if (location.zones && location.viewport) {
        bValid = insideZones(
          {
            lat: myGeo.coordinate.latitude,
            lng: myGeo.coordinate.longitude,
          },
          location.zones,
          location.viewport.unit,
        )
      }
      break
    case 'polygon':
      bValid = inside(
        [myGeo.coordinate.latitude, myGeo.coordinate.longitude],
        !location.coordinates ? [] : location.coordinates.map(coord => [coord.lat, coord.lng]),
      )
      break
    case 'zip-code':
      if (location.strings) {
        bValid = location.strings.map(string => string.value).includes(myGeo.zip)
      }
      break
    default:
      break
  }

  return bValid
}

export { isValidLocation }
