import { gql } from 'apollo-boost'

const articleUpdate = gql`
  subscription articleUpdate {
    articleUpdate {
      _id
      name
      title
      shortDescr
      data
      style
      location
      startAt
      endAt
      source {
        name
        url
      }
      imageList {
        name
        url
      }
      videoList {
        name
        url
      }
      videoURL
      version
      updatedAt
    }
  }
`

const groupingAdd = gql`
  subscription groupingAdd {
    groupingAdd {
      _id
      collectionName
      name
      customerId
      clientId
      partitionId
      siteId
      appId
      platformId
      type
      list {
        id
        active
      }
      presentationMode {
        firstViewMode
        firstViewModeValue
        majorUpdateMode
        majorUpdateModeValue
        minorUpdateMode
        minorUpdateModeValue
        recallMode
        recallModeValue
      }
      majorMinor {
        major
        minor
      }
      schedule {
        bActive
        bFilter
        startAt
        endAt
        recurrenceType
        repeatsEvery
        repeatsType
        repeatsOn
        endType
        endOn
        endAfter
        status
      }
      availability {
        state
        availableAt
      }
      notification
      schemaType
      schemaVersion
      data
      style
      private
      articles {
        _id
        name
        title
        shortDescr
        data
        style
        location
        startAt
        endAt
        source {
          name
          url
        }
        imageList {
          name
          url
        }
        videoList {
          name
          url
        }
        videoURL
        version
        updatedAt
      }
      version
      state
      createdAt
      updatedAt
    }
  }
`
const groupingUpdate = gql`
  subscription groupingUpdate {
    groupingUpdate {
      _id
      collectionName
      name
      customerId
      clientId
      partitionId
      siteId
      appId
      platformId
      type
      list {
        id
        active
      }
      presentationMode {
        firstViewMode
        firstViewModeValue
        majorUpdateMode
        majorUpdateModeValue
        minorUpdateMode
        minorUpdateModeValue
        recallMode
        recallModeValue
      }
      majorMinor {
        major
        minor
      }
      schedule {
        bActive
        bFilter
        startAt
        endAt
        recurrenceType
        repeatsEvery
        repeatsType
        repeatsOn
        endType
        endOn
        endAfter
        status
      }
      availability {
        state
        availableAt
      }
      notification
      schemaType
      schemaVersion
      data
      style
      private
      articles {
        _id
        name
        title
        shortDescr
        data
        style
        location
        startAt
        endAt
        source {
          name
          url
        }
        imageList {
          name
          url
        }
        videoList {
          name
          url
        }
        videoURL
        version
        updatedAt
      }
      version
      state
      createdAt
      updatedAt
    }
  }
`

const dataUpdate = gql`
  subscription dataUpdate {
    dataUpdate {
      _id
      version
      createdAt
      updatedAt
      name
      type
      access
      schemaType
      schemaVersion
      summary
      data
      private
      style
      tags
      customerId
      componentId
      schedule {
        bActive
        bFilter
        startAt
        endAt
        status
      }
    }
  }
`

const documentDelete = gql`
  subscription documentDelete {
    documentDelete {
      _id
      _ids
      collectionName
    }
  }
`

export { articleUpdate, groupingUpdate, groupingAdd, dataUpdate, documentDelete }
