import { gql } from 'apollo-boost'

const phoneNumbersQuery = gql`
  query groupingQuery($ids: [String!]) {
    grouping(ids: $ids) {
      _id
      phoneNumbers
    }
  }
`

const groupingQuery = gql`
  query groupingQuery(
    $names: [String!]
    $ids: [String!]
    $appId: String
    $clientId: String
    $customerId: String
    $platformId: String
    $type: String
  ) {
    grouping(
      names: $names
      ids: $ids
      appId: $appId
      clientId: $clientId
      customerId: $customerId
      platformId: $platformId
      type: $type
    ) {
      _id
      appId
      clientId
      customerId
      platformId
      type
      name
      collectionName
      list {
        id
        active
      }
      articles {
        _id
        name
        title
        shortDescr
        data
        style
        location
        startAt
        endAt
        source {
          name
          url
        }
        imageList {
          name
          url
        }
        videoList {
          name
          url
        }
        videoURL
        version
        updatedAt
      }
      data
      style
      private
      state
      availability {
        state
        availableAt
      }
      schedule {
        bActive
        bFilter
        startAt
        endAt
        status
      }
      majorMinor {
        major
        minor
      }
      version
      createdAt
      updatedAt
    }
  }
`
const dataQuery = gql`
  query data($names: [String!], $ids: [String!], $types: [String!], $collectionName: String!) {
    data(names: $names, ids: $ids, types: $types, collectionName: $collectionName) {
      _id
      name
      data
      root
      type
      version
      createdAt
      updatedAt
      private
      style
      customerId
      schedule {
        bActive
        bFilter
        startAt
        endAt
        recurrenceType
        repeatsEvery
        repeatsType
        repeatsOn
        endType
        endOn
        endAfter
      }
      __typename
    }
  }
`

const eventQuery = gql`
  query article($_id: String, $collectionName: String!) {
    article(_id: $_id, collectionName: $collectionName) {
      _id
      name
      title
      shortDescr
      data
      style
      location
      startAt
      endAt
      source {
        name
        url
      }
      imageList {
        name
        url
      }
      videoList {
        name
        url
      }
      videoURL
      version
      updatedAt
    }
  }
`

const accessedQuery = gql`
  query accessed($ids: [String!], $collectionName: String!, $action: String) {
    accessed(ids: $ids, collectionName: $collectionName, action: $action) {
      _id
      accessed {
        action
        counter
      }
    }
  }
`

export { groupingQuery, dataQuery, eventQuery, accessedQuery, phoneNumbersQuery }
