import React from 'react'
import { ApolloClient, HttpLink } from 'apollo-boost'
import { ApolloProvider } from 'react-apollo'
import { createBrowserHistory } from 'history'
import { split } from 'apollo-link'
import { WebSocketLink } from 'apollo-link-ws'
import { getMainDefinition } from 'apollo-utilities'
import { InMemoryCache } from 'apollo-cache-inmemory'
import CacheBuster from './CacheBuster'
import { GRAPHQL_URIS } from './utils/constants'
import Routes from './routes/index'

const httpLink = new HttpLink({
  uri: GRAPHQL_URIS.https,
})

const wsLink = new WebSocketLink({
  uri: GRAPHQL_URIS.wss,
  options: {
    reconnect: true,
  },
})

const link = split(
  ({ query }) => {
    const definition = getMainDefinition(query)

    return definition.kind === 'OperationDefinition' && definition.operation === 'subscription'
  },
  wsLink,
  httpLink,
)

const cache = new InMemoryCache({
  cacheRedirects: {
    Query: {
      article: (_, args, { getCacheKey }) => getCacheKey({ __typename: 'Article', _id: args._id }),
    },
  },
})

cache.writeData({
  data: {
    firstCounts: [],
  },
})

const client = new ApolloClient({
  link,
  cache,
  resolvers: {},
})

const history = createBrowserHistory()
export default function App() {
  return (
    <ApolloProvider client={client}>
      <CacheBuster>
        {({ loading, isLatestVersion, refreshCacheAndReload }) => {
          if (loading) return null
          return <Routes history={history} />
        }}
      </CacheBuster>
    </ApolloProvider>
  )
}
