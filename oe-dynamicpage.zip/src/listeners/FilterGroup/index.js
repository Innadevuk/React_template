import React from 'react'
import _ from 'lodash'
import { useQuery } from '@apollo/react-hooks'
import * as queries from 'utils/queries'
import { isValidLocation } from 'utils/criteria'

const FilterGroup = ({ groupId, children, myGeo, ignoreLocationFilter = true, filter = true }) => {
  const { loading, error, data } = useQuery(queries.groupingQuery, {
    variables: {
      ids: groupId ? [groupId] : null,
    },
  })

  if (loading || error || !data) {
    return ''
  }

  const { grouping: groups } = data

  if (!groups) {
    return ''
  }

  const [group] = groups

  if (!group) {
    // console.log('Group is invalid or there is no active article in the Group')
    return ''
  }

  const groupLocation = _.get(group, 'data.location')

  const bAvailability = _.get(group, 'availability.state') === 'on'
  const bSchedule =
    !_.get(group, 'schedule.bActive') || _.get(group, 'schedule.status') === 'active'
  const bGroupLocation = isValidLocation(groupLocation, myGeo)

  if (filter && (!bAvailability || !bSchedule || (!ignoreLocationFilter && !bGroupLocation))) {
    // console.log('Group is invalid', bAvailability, bSchedule, bGroupLocation)
    return ''
  }

  const articles = []

  // Object.values(group.list).forEach(item => {
  //   if (item.active === 'true') {
  //     const findArticleIndex = group.articles.findIndex(article => article._id === item.id)
  //     if (findArticleIndex >= 0) {
  //       const { location } = group.articles[findArticleIndex]
  //       if (!filter || ignoreLocationFilter || isValidLocation(location, myGeo)) {
  //         articles.push(group.articles[findArticleIndex])
  //       }
  //     }
  //   }
  // })

  return React.Children.map(children, child => {
    if (child) {
      return React.cloneElement(child, {
        ...child.props,
        group: {
          ...group,
          articles,
        },
        myGeo,
      })
    }

    return ''
  })
}

export default FilterGroup
