import React from 'react'
import _ from 'lodash'
import { isValidLocation } from 'utils/criteria'

const FilterGroups = ({ groups, children, myGeo, ignoreLocationFilter }) => {
  const validGroups = []
  const inactiveGroups = []

  for (const group of groups) {
    if (!group || !group.list) {
      // console.log('Group is invalid or there is no active article in the Group')
      continue
    }

    const groupLocation = _.get(group, 'data.location')

    const bAvailability =
      _.get(group, 'availability.state') === 'on' || !!_.get(group, 'availability.availableAt') // OLD ACTIVE GROUPS
    const bSchedule =
      !_.get(group, 'schedule.bActive') || _.get(group, 'schedule.status') === 'active'
    const bGroupLocation = isValidLocation(groupLocation, myGeo)

    if (!bAvailability) {
      inactiveGroups.push(group)
      continue
    }

    if (!bSchedule) continue

    if (!ignoreLocationFilter && !bGroupLocation) continue

    const articles = []

    Object.values(group.list).forEach(item => {
      if (item.active === 'true') {
        const findArticleIndex = group.articles.findIndex(article => article._id === item.id)

        if (findArticleIndex >= 0) {
          const { location } = group.articles[findArticleIndex]
          if (ignoreLocationFilter || isValidLocation(location, myGeo)) {
            articles.push(group.articles[findArticleIndex])
          }
        }
      }
    })

    validGroups.push({ ...group, articles })
  }

  const reordered = []
  validGroups.forEach(group => {
    if (group?.availability?.state === 'on') reordered.push(group)
  })
  validGroups.forEach(group => {
    if (group?.availability?.state !== 'on') reordered.push(group)
  })

  return React.Children.map(children, child => {
    if (child) {
      return React.cloneElement(child, {
        ...child.props,
        groups: reordered,
        myGeo,
        inactiveGroups,
      })
    }

    return ''
  })
}
export default FilterGroups
