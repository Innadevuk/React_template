import React from 'react'
import packageJson from '../package.json'
global.appVersion = packageJson.version

// version from response - first param, local version second param
const semverGreaterThan = (versionA, versionB) => {
  const versionsA = versionA.split(/\./g)

  const versionsB = versionB.split(/\./g)
  while (versionsA.length || versionsB.length) {
    const a = Number(versionsA.shift())

    const b = Number(versionsB.shift())
    // eslint-disable-next-line no-continue
    if (a === b) continue
    // eslint-disable-next-line no-restricted-globals
    return a > b || isNaN(b)
  }
  return false
}

class CacheBuster extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      loading: true,
      isLatestVersion: false,
    }
  }

  componentDidMount() {
    if (caches) {
      // Service worker cache should be cleared with caches.delete()
      caches.keys().then(names => {
        const promises = []
        for (const name of names) promises.push(caches.delete(name))

        console.log(names)
        if (names && names.length) {
          Promise.all(promises)
            .then(() => {
              caches.keys().then(names => console.log('after delete', names))
              // window.location.reload(true)
            })
            .catch(err => {
              console.log(err)
            })
            .finally(() => {
              this.setState({ loading: false })
            })
        } else {
          this.setState({ loading: false })
        }
      })
    } else {
      this.setState({ loading: false })
    }
    // fetch('/meta.json')
    //   .then(response => response.json())
    //   .then(meta => {
    //     const latestVersion = meta.version
    //     const currentVersion = global.appVersion

    //     console.log(latestVersion, currentVersion)

    //     const shouldForceRefresh = semverGreaterThan(latestVersion, currentVersion)
    //     if (shouldForceRefresh) {
    //       console.log(`We have a new version - ${latestVersion}. Should force refresh`)
    //       this.setState({ loading: false, isLatestVersion: false })
    //     } else {
    //       console.log(
    //         `You already have the latest version - ${latestVersion}. No cache refresh needed.`,
    //       )
    //       this.setState({ loading: false, isLatestVersion: true })
    //     }
    //   })
  }

  refreshCacheAndReload = () => {
    console.log('Clearing cache and hard reloading...')
    if (caches) {
      // Service worker cache should be cleared with caches.delete()
      caches.keys().then(function (names) {
        for (let name of names) caches.delete(name)
        console.log('cleared cache', names)

        // window.location.reload(true)
      })
    }

    // delete browser cache and hard reload
    // console.log('reload')
  }

  render() {
    const { loading, isLatestVersion } = this.state
    const { children } = this.props

    return children({
      loading,
      isLatestVersion,
      refreshCacheAndReload: this.refreshCacheAndReload,
    })
  }
}

export default CacheBuster
