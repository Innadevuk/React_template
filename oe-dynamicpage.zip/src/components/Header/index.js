import React, { useEffect, useState } from 'react'
import { Container, Row, Col } from 'react-bootstrap'
import _ from 'lodash'
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
// import { faPhoneVolume } from '@fortawesome/free-solid-svg-icons'
import './index.scss'

const Header = ({ generic, data, style }) => {
  const dividerColor = _.get(style, 'divider_major')

  const logo = _.get(generic, 'header.logo')
  const phone = _.get(generic, 'contact.phone')
  const desc = _.get(generic, 'header.desc')
  const email = _.get(generic, 'contact.email')

  const headerStyle = {
    height: style.mediabox.height,
    backgroundColor: style.title.bg_type === 'color' ? style.title.bg_color : 'none',
    backgroundImage: style.title.bg_type === 'color' ? 'none' : `url(${style.title.bg_image})`,
    backgroundPosition: 'top',
    backgroundRepeat: 'no-repeat',
    backgroundSize: '100% auto',
  }

  const icon = _.get(data, 'icon.url')
  const iconLocation = _.get(data, 'icon.location') || 'left'
  const logoLocation = _.get(data, 'logo.location') || 'left'
  const positionMap = {
    left: 'flex-start',
    center: 'center',
    right: 'flex-end',
  }

  return (
    <section className="oe-dynamicpage-header" style={headerStyle}>
      <div className="oe-dynamicpage-header-container">
        <div
          className="oe-dynamicpage-header-logo"
          style={{ justifyContent: positionMap[logoLocation] }}
        >
          {logo && <img src={logo} alt="logo" />}
        </div>
        <div
          className="oe-dynamicpage-header-icon"
          style={{ justifyContent: positionMap[iconLocation] }}
        >
          {icon && <img src={icon} alt="icon" />}
        </div>
        {/* <Row>
          <Col md="4">
            <div className="oe-dynamicpage-header-logo">
              {logo && <img src={logo} alt="logo" />}
            </div>
            <div className="oe-dynamicpage-header-icon">
              {icon && <img src={icon} alt="icon" />}
            </div>
          </Col>
          <Col md="8" className="text-right">
            <div>
              {phone && (
                <a href={`tel:${phone}`} className="oe-dynamicpage-header-phone">
                  <div>
                    <img src="/images/phone.png" alt="phone" />
                    <span>{phone}</span>
                  </div>
                </a>
              )}
              {email && (
                <a href={`mailto:${email}`} className="oe-dynamicpage-header-email">
                  <div>
                    <img src="/images/mail.png" alt="mail" />
                    <span>{email}</span>
                  </div>
                </a>
              )}
            </div>
            <div className="oe-dynamicpage-header-addr">
              <div className="oe-dynamicpage-header-divider">
                <hr style={{ backgroundColor: dividerColor }} />
              </div>
              {desc}
            </div>
          </Col>
        </Row> */}
      </div>
    </section>
  )
}

export default Header
