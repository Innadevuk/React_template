import React from 'react'
import { Form, Col, Row } from 'react-bootstrap'

import './index.scss'

export default function SubscribeForm() {
  return (
    <Form className="oe-subscribe-form">
      <h2>Please sign in to subscribe, unsubscribe, or manage your subscriptions</h2>
      <Form.Group as={Row}>
        <Form.Label column sm="12">
          Email Address
        </Form.Label>
        <Col sm="10" md={6}>
          <Form.Control />
        </Col>
      </Form.Group>
      <Form.Group as={Row}>
        <Form.Label column sm="12">
          Phone number
        </Form.Label>
        <Col sm="10" md={6}>
          <Form.Control />
        </Col>
      </Form.Group>
      {/* <div className="subscribeForm formline onTop" id="divSignIn">
        <h2>Please sign in to subscribe, unsubscribe, or manage your subscriptions</h2>
        <div className="formline">
          <label htmlFor="emailAddressSignIn">Email Address</label>
          <div>
            <input
              type="text"
              value=""
              id="emailAddressSignIn"
              onKeyDown="emailAddressSignIn_KeyDown(event);"
            />
          </div>
        </div>
        <div className="formline nolabel">
          <div>
            <input
              type="button"
              value="Sign In"
              title="Sign In"
              onKeyPress="this.onclick();"
              onClick="signIn();"
            />
          </div>
        </div>
      </div> */}
    </Form>
  )
}
