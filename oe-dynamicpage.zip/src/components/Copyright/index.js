import React from 'react'
import moment from 'moment'
import './index.scss'

const Copyright = ({ generic, data, style }) => {
  return (
    <section className="oe-dynamicpage-copyright">
      <div className="oe-dynamicpage-copyright-text">
        <a className="oe-dynamicpage-copyright-text-link" href="https://openznet.com">{`All rights reserved. © OpenZNet Inc. ${moment().year()}`}</a>
      </div>
    </section>
  )
}

export default Copyright
