import React, { Component } from 'react'
import { graphql, withApollo } from 'react-apollo'
import * as queries from 'utils/queries'
import * as compose from 'lodash.flowright'
import * as mutations from 'utils/mutations'
import PropTypes from 'prop-types'
import _ from 'lodash'
import { Player } from 'video-react'
import objectAssignDeep from 'object-assign-deep'
import { DEFAULT_STYLE } from 'utils/defaultValues'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faHeart as faHeartEmpty } from '@fortawesome/free-regular-svg-icons'
import { faHeart, faHeartBroken } from '@fortawesome/free-solid-svg-icons'
import HLSSource from 'components/HLSSource'
import './index.scss'

const HEART_STATUS = ['Liked', 'Neutral', 'Disliked']

function isHLSformat(URL) {
  const re = /(?:\.([^.]+))?$/
  const ext = re.exec(URL)[1]

  return ext === 'm3u8'
}

class GroupAdW300H250 extends Component {
  constructor(props) {
    super(props)

    this.state = {
      answered: false,
      isFlipped: false,
      heartStatus: 0,
      surveyList: [],
      article: null,
      notification: '',
    }

    this.playerRef = React.createRef()
  }

  fetchCount = async actionName => {
    const {
      client: { query },
    } = this.props
    const result = await query({
      query: queries.accessedQuery,
      variables: {
        collectionName: 'Articles',
        action: `Survey - ${actionName}`,
      },
    })
    const data = _.get(result, 'data.accessed') || []
    const returnVal = data.length > 0 ? data[0].accessed[0].counter : 0

    return returnVal
  }

  componentDidMount = async () => {
    const { upsertTracking, group } = this.props
    const { list } = group

    const articles = []
    list.forEach(item => {
      if (item.active === 'true' && group.articles) {
        const article = group.articles.find(article => article._id === item.id)
        articles.push(article)
      }
    })

    if (!articles || !articles[0]) return ''

    const article = articles[0]

    const surveyList = _.get(article, 'data.surveyList') || []

    for (let i = 0; i < surveyList.length; i += 1) {
      surveyList[i].checked = false
      surveyList[i].counter = await this.fetchCount(surveyList[i].name)
    }

    this.setState({
      article: articles[0],
      surveyList,
      notification: 'Sent Tracking: Viewed',
    })

    upsertTracking({
      variables: {
        _id: articles[0]._id,
        collectionName: 'Articles',
        action: 'Viewed',
        comment: `Article (${articles[0].name}) is viewed`,
      },
    })
      .then(() => {})
      .catch(err => {
        console.log(err)
      })
  }

  fetchCounts = async () => {
    const { surveyList } = this.state
    const nSurveyList = surveyList

    for (let i = 0; i < nSurveyList.length; i += 1) {
      nSurveyList[i].counter = await this.fetchCount(nSurveyList[i].name)
    }

    this.setState({ surveyList: nSurveyList })
  }

  cardFlip = async title => {
    const { isFlipped, article } = this.state
    const { upsertTracking } = this.props

    this.setState({ isFlipped: !isFlipped })

    let actionName
    switch (title) {
      case 'Watch Video >':
        actionName = 'More - Video'
        break
      case 'Take a Survey >':
        actionName = 'More - Survey'
        break
      case 'See More >':
        actionName = 'More - LongDesc'
        break
      default:
        actionName = 'Viewed'
        break
    }

    upsertTracking({
      variables: {
        _id: article?._id,
        collectionName: 'Articles',
        action: actionName,
      },
    })
      .then(() => {})
      .catch(err => {
        console.log(err)
      })

    this.setState({ notification: 'Sent Tracking: ' + actionName })
    if (actionName === 'Viewed') {
      this.setState({ answered: false })
    }
  }

  clickHeart = () => {
    const { heartStatus, article } = this.state
    const { upsertTracking } = this.props

    upsertTracking({
      variables: {
        _id: article?._id,
        collectionName: 'Articles',
        action: HEART_STATUS[heartStatus],
        comment: `Changed State of the Article to '${HEART_STATUS[heartStatus]}'`,
      },
    })
      .then(() => {})
      .catch(err => {
        console.log(err)
      })

    const nHeartStatus = (heartStatus + 1) % 3
    this.setState({
      heartStatus: nHeartStatus,
      notification: 'Sent Tracking: ' + HEART_STATUS[nHeartStatus],
    })
  }

  handleSubmit = async () => {
    const { answered } = this.state
    this.setState({ answered: !answered })
  }

  handleSurveyCheck = async (index, value) => {
    const { surveyList, article } = this.state
    const { upsertTracking } = this.props

    const nSurveyList = surveyList
    nSurveyList[index].checked = value
    this.setState({ surveyList: nSurveyList })

    upsertTracking({
      variables: {
        _id: article._id,
        collectionName: 'Articles',
        action: 'Survey - ' + nSurveyList[index].name,
        comment: `Survey (${nSurveyList[index].name}) is answered`,
      },
    })
      .then(() => {})
      .catch(err => {
        console.log(err)
      })

    nSurveyList[index].counter++

    this.setState({
      surveyList: nSurveyList,
      notification: 'Sent Tracking: ' + 'Survey - ' + nSurveyList[index].name,
    })
  }

  handleWebLink = webLink => {
    const { article } = this.state
    const { upsertTracking } = this.props

    upsertTracking({
      variables: {
        _id: article._id,
        collectionName: 'Articles',
        action: 'WebLink -' + webLink.name,
        comment: `WebLink (${webLink.name}) is clicked`,
      },
    })
      .then(() => {})
      .catch(err => {
        console.log(err)
      })
    this.setState({ notification: 'Sent Tracking: ' + 'WebLink - ' + webLink.name })
  }

  handleSharedLink = sharedLink => {
    const { article } = this.state
    const { upsertTracking } = this.props

    upsertTracking({
      variables: {
        _id: article._id,
        collectionName: 'Articles',
        action: 'Shared -' + sharedLink.name,
        comment: `SharedLink (${sharedLink.name}) is clicked`,
      },
    })
      .then(() => {})
      .catch(err => {
        console.log(err)
      })

    this.setState({ notification: 'Sent Tracking: ' + 'Shared - ' + sharedLink.name })
  }

  render() {
    const { isFlipped, heartStatus, surveyList, answered, article, notification } = this.state
    const { forwardedRef } = this.props

    let heart = faHeartBroken

    if (heartStatus === 0) {
      heart = faHeart
    } else if (heartStatus === 1) {
      heart = faHeartEmpty
    }

    if (!article) {
      return (
        <div className="oe-group-add-300-250" style={cardStyle}>
          <h5>Nothing is available</h5>
        </div>
      )
    }

    const heartWidth = heartStatus === 2 ? '15px' : '20px'

    const cardTitle = _.get(article, 'data.desc.title') || ''

    const iconURL = _.get(article, 'data.desc.icon')
    const sharedIconURL = _.get(article, 'data.sharedLinks') || []
    const webLinks = _.get(article, 'data.webLinks') || []
    // const surveyList = _.get(article, 'data.surveyList') || []
    const sharedLinks = _.get(article, 'data.sharedLinks') || []

    const isFirstLine = webLinks && webLinks.length >= 1
    const isSecondLine = webLinks && webLinks.length === 4
    const streamURL = _.get(article, 'data.streaming.broadband_url')
    const externalVideo = _.get(article, 'videoURL')
    const stockVideo = _.get(article, 'videoList.0.url')
    const videoURL = streamURL || externalVideo || stockVideo
    const imageList = _.get(article, 'imageList') || []
    const longDescr = _.get(article, 'data.desc.longDescr') || ''
    const shortDescr = _.get(article, 'data.desc.shortDescr') || ''

    const isMore = (article.data && (surveyList.length > 0 || longDescr.length > 0)) || !!videoURL

    const { style: articleStyleFrom } = article

    const style = objectAssignDeep({ ...DEFAULT_STYLE }, articleStyleFrom)

    let title = ''

    if (videoURL) {
      title = 'Watch Video >'
    } else if (surveyList.length > 0 && _.get(surveyList[0], 'desc')) {
      title = 'Take a Survey >'
    } else if (longDescr.length > 0) {
      title = 'See More >'
    }

    const textColor = {
      color: style?.fg_color,
    }

    const cardStyle = {
      backgroundColor: style?.bg_color,
    }

    cardStyle.color = style?.fg_color

    if (style?.b_outline) {
      cardStyle.border = `solid 1px ${style?.outline_color}`
    }

    if (style?.b_shadow) {
      cardStyle.boxShadow = `3px 3px 3px ${style?.shadow_color}`
    }

    return (
      <div ref={forwardedRef}>
        {!isFlipped ? (
          <div className="oe-group-add-300-250" style={cardStyle}>
            {/* header */}
            <div className="oe-group-add-300-250-header">
              <div className="oe-group-add-300-250-header-logo">
                {iconURL && <img src={iconURL} alt="logo" />}
              </div>
              <h5>{cardTitle}</h5>
            </div>

            <div className="oe-group-add-300-250-divider" />
            {/* main */}
            <div className="oe-group-add-300-250-desc">
              {imageList.length > 0 ? (
                <img src={imageList[0].url} className="img" />
              ) : (
                <h5>{shortDescr}</h5>
              )}
            </div>
            {sharedLinks.length > 0 && <div className="oe-group-add-300-250-divider" />}
            {sharedLinks.length > 0 && (
              <div className="oe-group-add-300-250-share">
                <div className="oe-group-add-300-250-share-left">
                  <h5>Share:</h5>
                  {sharedLinks.map((sharedLink, index) => (
                    <a
                      key={index}
                      onClick={() => {
                        this.handleSharedLink(sharedLink)
                      }}
                    >
                      {sharedLink.iconURL && (
                        <img
                          src={sharedLink.iconURL}
                          key={index}
                          className="oe-group-add-300-250-share-left-circle"
                        />
                      )}
                    </a>
                  ))}
                </div>
              </div>
            )}
            {webLinks && isFirstLine && <div className="oe-group-add-300-250-divider" />}
            {webLinks && isFirstLine && (
              <div className="oe-group-add-300-250-url">
                <div className="oe-group-add-300-250-url-weblink">
                  <a>
                    {webLinks[0] && webLinks[0].iconURL && (
                      <img
                        src={webLinks[0].iconURL}
                        style={{ width: 'auto', height: '35px' }}
                        alt="icon"
                      />
                    )}
                  </a>
                  <div className="oe-group-add-300-250-url-weblink-label">
                    {webLinks[0] && webLinks[0].label && (
                      <a style={{ color: 'white' }} onClick={() => this.handleWebLink(webLinks[0])}>
                        {webLinks[0].label}
                      </a>
                    )}
                  </div>
                </div>
                <div className="oe-group-add-300-250-url-weblink">
                  {webLinks[1] && webLinks[1].iconURL && (
                    <a>
                      <img
                        src={webLinks[1].iconURL}
                        style={{ width: 'auto', height: '35px' }}
                        alt="icon"
                      />
                    </a>
                  )}

                  {webLinks[1] && webLinks[1].label && (
                    <div className="oe-group-add-300-250-url-weblink-label">
                      <a style={{ color: 'white' }} onClick={() => this.handleWebLink(webLinks[1])}>
                        {webLinks[1].label}
                      </a>
                    </div>
                  )}
                </div>
              </div>
            )}
            {webLinks && isSecondLine && <div className="oe-group-add-300-250-divider" />}
            {/* visitor */}
            {webLinks && isSecondLine && (
              <div className="oe-group-add-300-250-visit">
                <a style={{ color: 'white' }} onClick={() => this.handleWebLink(webLinks[2])}>
                  {webLinks[2].label}
                </a>
                <a style={{ color: 'white' }} onClick={() => this.handleWebLink(webLinks[3])}>
                  {webLinks[3].label}
                </a>
              </div>
            )}
            {isMore && <div className="oe-group-add-300-250-divider" />}
            {isMore && (
              <div className="oe-group-add-300-250-survey">
                {/* <img
                  src={heart}
                  style={{ width: heartWidth, height: '20px' }}
                  className="fa-heart"
                  onClick={() => this.clickHeart()}
                /> */}
                <FontAwesomeIcon
                  className="fa-heart"
                  icon={heart}
                  onClick={() => this.clickHeart()}
                  size="2x"
                />
                <a onClick={() => this.cardFlip(title)} style={textColor}>
                  {title}
                </a>
              </div>
            )}
            <div>{notification}</div>
          </div>
        ) : (
          <div className="oe-group-add-300-250" style={cardStyle}>
            <div className="oe-group-add-300-250-header">
              <div className="oe-group-add-300-250-header-logo">
                {iconURL && <img src={iconURL} alt="logo" />}
              </div>
              <h5>{cardTitle}</h5>
            </div>

            <div className="oe-group-add-300-250-back">
              {title === 'See More >' && (
                <div className="oe-group-add-300-250-back-long">
                  <h5>{longDescr}</h5>
                </div>
              )}
              {title === 'Watch Video >' && (
                <div className="oe-group-add-300-250-back-video">
                  {isHLSformat(videoURL) ? (
                    <Player ref={this.playerRef}>
                      <HLSSource isVideoChild src={videoURL} />
                    </Player>
                  ) : (
                    <Player ref={this.playerRef} src={videoURL} />
                  )}
                </div>
              )}
              {title === 'Take a Survey >' && answered === false && (
                <div className="oe-group-add-300-250-back-container">
                  <div className="oe-group-add-300-250-back-container-top">
                    <div className="oe-group-add-300-250-back-container-top-webLink-label">
                      <a>Which issues are important to you?</a>
                    </div>
                    {surveyList.map((survey, index) => {
                      return (
                        <div
                          className="oe-group-add-300-250-back-container-top-webLink"
                          key={index}
                        >
                          <input
                            name="isGoing"
                            type="checkbox"
                            value={survey.checked}
                            onClick={e => this.handleSurveyCheck(index, e.target.checked)}
                          />
                          <div className="oe-group-add-300-250-back-container-top-webLink-label">
                            <a>{survey.desc}</a>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                  <div className="oe-group-add-300-250-back-container-bottom">
                    <a onClick={() => this.handleSubmit()}>Submit to see result</a>
                  </div>
                </div>
              )}
              {title === 'Take a Survey >' && answered === true && (
                <div className="oe-group-add-300-250-back-container">
                  <div className="oe-group-add-300-250-back-container-top">
                    <div className="oe-group-add-300-250-back-container-top-issue">
                      <a>{'Issues by order of importance'}</a>
                    </div>
                    {surveyList.map((survey, index) => {
                      return (
                        <div className="oe-group-add-300-250-back-container-top-answer" key={index}>
                          <div className="oe-group-add-300-250-back-container-top-answer-label">
                            <a>{survey.name}</a>
                          </div>
                          <div className="oe-group-add-300-250-back-container-top-answer-count">
                            <a>: {survey.counter}</a>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              )}
            </div>

            {sharedLinks.length > 0 && (
              <div className="oe-group-add-300-250-share">
                <div className="oe-group-add-300-250-share-left">
                  <h5>Share:</h5>
                  {sharedLinks.map((sharedLink, index) => (
                    <a
                      key={index}
                      onClick={() => {
                        this.handleSharedLink(sharedLink)
                      }}
                    >
                      {sharedLink.iconURL && (
                        <img
                          src={sharedLink.iconURL}
                          key={index}
                          className="oe-group-add-300-250-share-left-circle"
                        />
                      )}
                    </a>
                  ))}
                </div>
              </div>
            )}

            {sharedLinks.length > 0 && <div className="oe-group-add-300-250-divider" />}
            {/* <div className="oe-group-add-300-250-visit">
              <a href="#" style={textColor}>Visit our site</a>
              <a href="#" style={textColor}>Donate</a>
            </div> */}
            {/* <div className="oe-group-add-300-250-divider" /> */}
            <div className="oe-group-add-300-250-first">
              <a onClick={() => this.cardFlip('')} style={textColor}>
                {'< Back'}
              </a>
            </div>
            <div>{notification}</div>
          </div>
        )}
      </div>
    )
  }
}

GroupAdW300H250.propTypes = {
  data: PropTypes.object,
  onExit: PropTypes.func,
  group: PropTypes.object,
  articles: PropTypes.array,
  upsertTracking: PropTypes.func,
}

GroupAdW300H250.defaultProps = {
  data: {},
  group: {},
  articles: [],
  onExit: () => {},
  upsertTracking: () => {},
}

export default compose(
  graphql(mutations.upsertTracking, { name: 'upsertTracking' }),
  withApollo,
)(GroupAdW300H250)
