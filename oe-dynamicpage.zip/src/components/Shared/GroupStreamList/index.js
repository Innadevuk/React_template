import React, { useState, useEffect, createRef, useRef } from 'react'
import { Player } from 'video-react'
import HLSSourceList from 'components/HLSSourceList'
import _ from 'lodash'
import classnames from 'classnames'
import objectAssignDeep from 'object-assign-deep'
import { DEFAULT_STYLE } from 'utils/defaultValues'
import { useWindowSize } from 'utils/hooks'

import './index.scss'

const GroupStreamList = React.forwardRef(({ group }, ref) => {
  if (!group) return ''
  const [muted, setMuted] = useState(true)
  const [current, setCurrent] = useState(0)
  const [showTitle, setShowTitle] = useState(false)
  const [mediaWidth, setMediawidth] = useState('undefined')
  const size = useWindowSize()

  const streamArticles = []
  const videoRef = useRef(null)

  const articles = group.articles || []
  const groupStyle = objectAssignDeep({ ...DEFAULT_STYLE }, group.style)

  articles.forEach(article => {
    const streamURL = _.get(article, 'data.streaming.broadband_url')
    if (streamURL) streamArticles.push(article)
  })

  const autoPlay = _.get(group, 'data.layout.autoPlay') || false
  const autoLoop = _.get(group, 'data.layout.autoLoop') || false

  // useEffect(() => {
  //   const dropdown = document.getElementsByClassName('video-react')[0]
  //   const width = dropdown?.offsetWidth || 'undefined'
  //   setMediawidth(width)

  //   const timer1 = setTimeout(() => {
  //     setShowTitle(true)
  //     setMuted(false)
  //     setTimeout(() => setShowTitle(false), 14000)
  //   }, 100)

  //   return () => {
  //     clearTimeout(timer1)
  //   }
  // }, [autoPlay])

  useEffect(() => {
    console.log(videoRef)

    let timer = null
    const dropdown = document.getElementsByClassName('video-react')[0]
    const width = dropdown?.offsetWidth || 'undefined'
    setMediawidth(width)

    if (videoRef.current) {
      videoRef.current.subscribeToStateChange((state, prevState) => {
        if (_.get(prevState, 'currentTime') === 0 && _.get(state, 'currentTime') > 0) {
          timer = setTimeout(() => {
            setShowTitle(true)
            setMuted(false)
            setTimeout(() => setShowTitle(false), 14000)
          }, 100)
        }
      })
    }

    return () => {
      clearTimeout(timer)
    }
  }, [videoRef])

  const onEnded = e => {
    setShowTitle(true)

    if (current + 1 < streamArticles.length || autoLoop) {
      setCurrent(current + 1)
    }

    setTimeout(() => {
      setShowTitle(false)
    }, 14000)
  }

  const currentArticle = streamArticles.length
    ? streamArticles[current % streamArticles.length]
    : null

  const streamURL = _.get(currentArticle, 'data.streaming.broadband_url')
  const title = _.get(currentArticle, 'data.desc.title')
  const shortDescr = _.get(currentArticle, 'data.desc.shortDescr')
  const longDescr = _.get(currentArticle, 'data.desc.longDescr')
  const articleIcon = _.get(currentArticle, 'data.desc.icon')
  const articleImage = _.get(currentArticle, 'data.desc.image')
  const titleClass = classnames('title', { show: showTitle })
  const bgClass = classnames('bg', { show: showTitle })

  const articleStyle = objectAssignDeep({ ...DEFAULT_STYLE }, _.get(currentArticle, 'style'))

  const videoOptions = {
    fluid: false,
    muted,
    autoPlay,
    height: size.width > 525 ? groupStyle?.mediabox?.height : undefined,
    width: size.width > 525 ? undefined : size.width,
    poster: _.get(currentArticle, 'data.desc.image'),
  }

  return (
    <div className="oe-dynamicpage-group-streamlist" ref={ref}>
      <div className="video-wrapper">
        {currentArticle && (
          <>
            <Player onEnded={onEnded} ref={videoRef} {...videoOptions}>
              <HLSSourceList
                isVideoChild
                src={streamURL}
                key={current}
                current={current}
                autoPlay={autoPlay}
                autoLoop={autoLoop}
              />
              <div className={titleClass}>
                <div className="left" style={{ display: title ? 'inline-block' : 'none' }} />
                <span>{title}</span>
              </div>

              <div
                className={bgClass}
                style={{
                  backgroundColor: articleStyle.title.bg_color,
                  display: title ? 'inline-block' : 'none',
                }}
              />
            </Player>
            <div
              className="oe-dynamicpage-group-streamlist-descr"
              style={{
                backgroundColor: articleStyle.bg_color,
                color: articleStyle.fg_color,
                width: mediaWidth,
              }}
            >
              {shortDescr && (
                <div className="oe-dynamicpage-group-streamlist-descr__short">
                  {articleIcon && <img className="icon" src={articleIcon} alt="icon" />}
                  <span>{shortDescr}</span>
                </div>
              )}
              {longDescr && (
                <div className="oe-dynamicpage-group-streamlist-descr__long">
                  {articleImage && <img src={articleImage} alt="desc.clip" />}
                  <div className="oe-dynamicpage-group-streamlist-descr__long-text">
                    <div className="oe-dynamicpage-group-streamlist-descr__long-text-long">
                      {longDescr}
                    </div>
                  </div>
                </div>
              )}
            </div>
            {/* <div className="btn-actions">
              <FontAwesomeIcon icon={faAddressBook} />
              <FontAwesomeIcon icon={faCommentMedical} />
              <FontAwesomeIcon icon={faBookmark} />
              <FontAwesomeIcon icon={faHeart} />
              <FontAwesomeIcon icon={faShareAlt} />
            </div> */}
          </>
        )}
      </div>
    </div>
  )
})

GroupStreamList.displayName = 'GroupStreamList'

export default GroupStreamList
