import React, { useEffect, useState } from 'react'
import Slider from 'react-slick'
import _ from 'lodash'

import './index.scss'

const settings = {
  dots: true,
  infinite: true,
  fade: true,
  speed: 1500,
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplaySpeed: 5000,
  autoplay: true,
}

const GroupImageList = React.forwardRef(({ group }, ref) => {
  if (!group) return ''
  const height = _.get(group, 'style.mediabox.height') || 100
  const [slickHeight, setSlickHeight] = useState(height)
  useEffect(() => {
    if (typeof window.orientation !== 'undefined') {
      setSlickHeight('auto')
    } else {
      setSlickHeight(height)
      const slickSlider = document.getElementsByClassName('slick-slider')[0]
      if (slickSlider) {
        document.getElementsByClassName('slick-slider')[0].style.height = `${slickHeight}px`
      }
    }
  })

  const imageList = _.get(group, 'data.imageList')
  const bImageList = imageList && imageList.length > 0

  return (
    <div className="oe-dynamicpage-group-imagelist" style={{ slickHeight }} ref={ref}>
      {_.get(group, 'availability.state') === 'on' && (
        <Slider {...settings} style={{ slickHeight }}>
          {bImageList &&
            imageList.map((image, index) => <img alt="slide" src={image.url} key={index} />)}
        </Slider>
      )}
    </div>
  )
})

GroupImageList.displayName = 'GroupImageList'
export default GroupImageList
