/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import React from 'react'
import _ from 'lodash'
import moment from 'moment'
import objectAssignDeep from 'object-assign-deep'
import { DEFAULT_STYLE } from 'utils/defaultValues'
import './index.scss'

const MediaViewGroupHeader = ({ group }) => {
  if (!group) return ''

  const { data, style: groupStyleFrom } = group
  const style = objectAssignDeep({ ...DEFAULT_STYLE }, groupStyleFrom)
  const updatedAt = _.get(group, 'updatedAt')
  const titleFgColor = style?.title?.fg_color
  const titleBgColor = style?.title?.bg_color
  const fgColor = style?.fg_color
  const bgColor = style?.bg_color

  const groupImage = _.get(data, 'desc.image') || null
  const groupShortDescr = _.get(data, 'desc.shortDescr') || null
  const groupLongDescr = _.get(data, 'desc.longDescr') || null
  const groupUpdatedAt = group?.style?.b_timestamp ? _.get(group, 'updatedAt') : null
  const groupIcon = _.get(data, 'desc.icon') || null
  const groupTitle = _.get(data, 'desc.title') || null

  const outline = {
    backgroundColor: titleBgColor,
    padding: !groupTitle && !groupShortDescr && !groupLongDescr ? '0 0 15px 0' : '35px 0 15px 0',
  }

  if (style?.b_outline === true) {
    outline.borderWidth = style?.outline?.width
    outline.borderStyle = 'solid'
    outline.borderColor = style?.outline?.color
    outline.borderRadius = style?.outline?.radius
  }

  if (style?.b_shadow === true) {
    outline.boxShadow = `3px 3px 3px${style?.shadow?.color}`
  }

  const groupHeaderBarStyle = {
    color: titleFgColor,
  }

  const groupTimeBarStyle = {
    display: _.get(group, 'style.b_timestamp') ? 'inherit' : 'none',
    color: titleFgColor,
    backgroundColor: 'rgba(196, 196, 196, 0.5)',
  }

  // const groupBarStyle = {
  //   color: titleFgColor,
  //   backgroundColor: titleBgColor,
  // }

  const groupBodyBarStyle = {
    color: fgColor,
    backgroundColor: bgColor,
  }

  const groupShortDescrStyle = {
    marginRight: style.b_divider_major ? '14px' : '0px',
  }

  const majorDividerStyle = {
    backgroundColor: style?.b_divide_major ? style.divider_major : 'inherit',
  }

  const minorDividerStyle = {
    backgroundColor: style?.b_divide_minor ? style.divider_minor : 'inherit',
  }

  return (
    <div className="oe-featured-layout" style={outline}>
      <div className="oe-featured-layout-group">
        {(groupIcon || groupTitle || groupImage || groupShortDescr || groupLongDescr) && (
          <div className="oe-featured-layout-group-header">
            {(groupIcon || groupTitle) && (
              <div
                className="oe-featured-layout-group-header-title-bar"
                style={groupHeaderBarStyle}
              >
                <div className="oe-featured-layout-group-header-title-bar-group">
                  {groupIcon && <img src={groupIcon} alt="desc.icon" />}
                  <span>{groupTitle}</span>
                </div>
                {groupShortDescr && style?.b_divide_major && (
                  <div
                    className="oe-featured-layout-group-header-title-bar-divider"
                    style={majorDividerStyle}
                  />
                )}
              </div>
            )}
          </div>
        )}
        <div className="oe-featured-layout-group-body">
          {(groupImage || groupShortDescr || groupLongDescr) && (
            <div className="oe-featured-layout-group-body-desc-bar" style={groupBodyBarStyle}>
              {groupImage && <img src={groupImage} alt="desc.clip" />}
              <div className="oe-featured-layout-group-body-desc-bar-text">
                <div
                  className="oe-featured-layout-group-body-desc-bar-text-short"
                  style={groupShortDescrStyle}
                >
                  {groupShortDescr}
                  {groupShortDescr && style?.b_divide_minor && (
                    <div
                      className="oe-featured-layout-group-body-desc-bar-text-divider"
                      style={minorDividerStyle}
                    />
                  )}
                </div>
                <div
                  className="oe-featured-layout-group-body-desc-bar-text-long"
                  style={groupBodyBarStyle}
                >
                  {groupLongDescr}
                </div>
              </div>
            </div>
          )}
          {(groupIcon || groupTitle || groupImage || groupShortDescr || groupLongDescr) && (
            <div className="oe-featured-layout-group-header-time-bar" style={groupTimeBarStyle}>
              <div className="oe-featured-layout-group-header-time-bar-updatedAt">{`Updated: ${moment(
                updatedAt,
              ).format('MMM DD, hh:mm A')}`}</div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default MediaViewGroupHeader
