/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import React from 'react'
import Carousel from 're-carousel'

import IndicatorDots from 'components/carousel/indicatorDots'
import Buttons from 'components/carousel/buttons'
import Article from './Article'

import './BarCarousel.scss'

const MediaViewGroupContentTopBar = ({ myGeo, group }) => {
  const { articles } = group

  if (articles.length > 1) {
    return (
      <div className="oe-featured-layout-group-body-featured-bar-carousel">
        <Carousel loop widgets={[IndicatorDots, Buttons]}>
          {articles.map((article, index) => (
            <Article key={index} article={article} groupStyle={group?.style} myGeo={myGeo} />
          ))}
        </Carousel>
      </div>
    )
  }

  return (
    <div
      className="oe-featured-layout-group-body-featured-bar-carousel"
      style={{ height: '320px' }}
    >
      <Article article={articles[0]} myGeo={myGeo} groupStyle={group?.style} />
    </div>
  )
}

export default MediaViewGroupContentTopBar
