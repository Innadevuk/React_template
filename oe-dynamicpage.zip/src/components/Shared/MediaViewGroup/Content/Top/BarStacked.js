/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import React from 'react'
import Article from './Article'

import './BarStacked.scss'

const MediaViewGroupContentTopBar = ({ myGeo, group, layoutType, current }) => {
  const { articles } = group

  return (
    <div className="oe-featured-layout-group-body-featured-bar-stacked">
      {layoutType !== 'AlertStack' && articles.map(article => <Article key={article._id} article={article} myGeo={myGeo} groupStyle={group.style} layoutType={layoutType} />)}
      {layoutType === 'AlertStack' && current > -1 && <Article key={articles[current]._id} article={articles[current]} myGeo={myGeo} groupStyle={group.style} layoutType={layoutType} />}
    </div>
  )
}

export default MediaViewGroupContentTopBar
