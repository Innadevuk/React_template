/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import React, { useState } from 'react'
import Slider from 'react-slick'
import { Player } from 'video-react'
import _ from 'lodash'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faVideo, faImage, faMapMarkerAlt } from '@fortawesome/free-solid-svg-icons'
import MapComponent from 'components/Shared/MapComponent'
import objectAssignDeep from 'object-assign-deep'
import { DEFAULT_STYLE } from 'utils/defaultValues'

import './Article.scss'

const Modes = {
  NONE: 'none',
  LIVE: 'Live',
  IMAGE: 'Images',
  VIDEO: 'Videos',
  LOC: 'Location',
}

const settings = {
  infinite: true,
  fade: true,
  speed: 1500,
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplaySpeed: 5000,
  autoplay: true,
}

const FeaturedArticleNormal = ({ myGeo, article, groupStyle: groupStyleFrom, width }) => {
  const [mode, setMode] = useState(Modes.VIDEO)

  const groupStyle = objectAssignDeep({ ...DEFAULT_STYLE }, groupStyleFrom)

  let contentRender = ''

  const imageList = _.get(article, 'imageList')
  const videoList = _.get(article, 'videoList')
  const location = _.get(article, 'location')
  const viewPort = _.get(location, 'viewport') || null
  const bImageList = imageList && imageList.length > 0
  const bVideoList = videoList && videoList.length > 0
  const bLocation =
    location && location.bActive && location.type && location.type !== 'none' && viewPort
  let mMode = mode

  const availableModes = []
  if (bImageList) availableModes.push(Modes.IMAGE)
  if (bVideoList) availableModes.push(Modes.VIDEO)
  if (bLocation) availableModes.push(Modes.LOC)

  if (availableModes.length) {
    if (mMode === Modes.IMAGE && !bImageList) [mMode] = availableModes
    if (mMode === Modes.VIDEO && !bVideoList) [mMode] = availableModes
    if (mMode === Modes.LOC && !bLocation) [mMode] = availableModes
  } else {
    mMode = Modes.NONE
  }

  const judgeMainBar = availableModes.length

  switch (mMode) {
    case Modes.VIDEO:
      contentRender = (
        <div className="oe-featured-layout-group-body-articles-bar-article-item-media-video">
          {videoList && videoList.length > 0 && <Player src={videoList[0].url} playsInline />}
        </div>
      )
      break
    case Modes.IMAGE:
      contentRender = (
        <div className="oe-featured-layout-group-body-articles-bar-article-item-media-image">
          <Slider {...settings}>
            {bImageList &&
              imageList.map((image, index) => <img alt="slide" src={image.url} key={index} />)}
          </Slider>
        </div>
      )
      break
    case Modes.LOC:
      contentRender = (
        <div className="oe-featured-layout-group-body-articles-bar-article-item-media-location">
          {bLocation && myGeo && (
            <MapComponent
              googleMapURL="https://maps.googleapis.com/maps/api/js?key=AIzaSyDQ6fOZioeYFWHF-Q02vErr8v7duPXywRA&v=3.exp&libraries=geometry,drawing,places"
              loadingElement={<div className="loadingelement" />}
              mapElement={<div className="mapelement" id="map" />}
              containerElement={<div className="containerelement" />}
              zoom={location.viewport.zoom}
              center={{
                lat: myGeo.coordinate.latitude,
                lng: myGeo.coordinate.longitude,
              }}
              type={location.type}
              color={location.color}
              onPointAdd={() => {}}
              useCase={location.useCase}
              coordinates={location.coordinates}
              zones={location.zones}
              unit={location.viewport.unit}
              points={location.points}
              showCenterMark
            />
          )}
        </div>
      )
      break
    case Modes.NONE:
      contentRender = ''
      break
    default:
      break
  }

  const articleTitle = _.get(article, 'data.desc.title') || null
  const articleShortDescr = _.get(article, 'data.desc.shortDescr') || null
  const articleLongDescr = _.get(article, 'data.desc.longDescr') || null
  const articleID = _.get(article, '_id') || 0

  const articleStyle = objectAssignDeep({ ...DEFAULT_STYLE }, _.get(article, 'style'))
  const articleFgColor = articleStyle?.title?.fg_color
  const articleBgColor = articleStyle?.title?.bg_color || groupStyle?.title?.bg_color

  const articleOutline = {
    color: articleFgColor,
    backgroundColor: articleBgColor,
    // boxShadow: `5px 5px 30px 15px ${groupStyle.hl_color}`,
  }

  if (!article) {
    articleOutline.padding = '0px 30px'
  }

  if (articleStyle?.b_outline === true) {
    articleOutline.borderWidth = articleStyle?.outline?.width
    articleOutline.borderStyle = 'solid'
    articleOutline.borderColor = articleStyle?.outline?.color
    articleOutline.borderRadius = articleStyle?.outline?.radius
  }

  if (articleStyle?.b_shadow === true) {
    articleOutline.boxShadow = `3px 3px 3px ${articleStyle?.shadow?.color}`
  }

  const textHeight = groupStyle?.mediabox?.height

  return (
    <div className="oe-featured-layout-group-body-articles-bar-article" key={articleID}>
      <div
        className="oe-featured-layout-group-body-articles-bar-article-item"
        style={articleOutline}
      >
        <div
          className="oe-featured-layout-group-body-articles-bar-article-item-media"
          style={{ height: (width * 9) / 16 }}
        >
          {mMode !== Modes.NONE && (
            <>
              {contentRender}
              <div
                className="oe-featured-layout-group-body-articles-bar-article-item-media-selector"
                style={{ display: judgeMainBar > 1 ? 'flex' : 'none' }}
              >
                {bVideoList && (
                  <span>
                    <FontAwesomeIcon
                      icon={faVideo}
                      // size="xs"
                      color="#1b95e0"
                      onClick={() => setMode(Modes.VIDEO)}
                    />
                  </span>
                )}
                {bImageList && (
                  <span>
                    <FontAwesomeIcon
                      icon={faImage}
                      // size="xs"
                      color="#1b95e0"
                      onClick={() => setMode(Modes.IMAGE)}
                    />
                  </span>
                )}
                {bLocation && (
                  <span>
                    <FontAwesomeIcon
                      icon={faMapMarkerAlt}
                      // size="xs"
                      color="#1b95e0"
                      onClick={() => setMode(Modes.LOC)}
                    />
                  </span>
                )}
              </div>
            </>
          )}
        </div>
        {(articleTitle || articleShortDescr || articleLongDescr) && (
          <div
            className="oe-featured-layout-group-body-articles-bar-article-item-text"
            style={{ height: textHeight }}
          >
            <div className="oe-featured-layout-group-body-articles-bar-article-item-text-title">
              {articleTitle}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default FeaturedArticleNormal
