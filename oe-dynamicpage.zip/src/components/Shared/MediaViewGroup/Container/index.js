/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import React from 'react'
import _ from 'lodash'
import objectAssignDeep from 'object-assign-deep'
import { DEFAULT_STYLE } from 'utils/defaultValues'
import MediaViewGroupHeader from '../Header'
import ArticlesGridHeader from '../Header/ArticlesGridHeader'
import './index.scss'

const MediaViewGroupContainer = React.forwardRef(
  ({ group, children, layoutType = 'ArticlesCarousel' }, ref) => {
    if (!group) return ''

    const { style: groupStyleFrom } = group

    const style = objectAssignDeep({ ...DEFAULT_STYLE }, groupStyleFrom)

    const containerStyle = {
      backgroundColor: ['ArticlesStack', 'ArticleText'].includes(layoutType)
        ? style?.title?.bg_color
        : 'white',
    }

    const layoutStyle = {
      padding: group.articles && group.articles.length ? undefined : '0',
    }

    return (
      <div className="oe-mediaview-group-container" style={containerStyle} ref={ref}>
        {['ArticlesStack', 'ArticleText'].includes(layoutType) && (
          <MediaViewGroupHeader group={group} />
        )}
        {layoutType === 'ArticlesGrid' && <ArticlesGridHeader group={group} />}
        {_.get(group, 'availability.state') === 'on' && (
          <div className="oe-featured-layout" style={layoutStyle}>
            <div className="oe-featured-layout-group">
              <div className="oe-featured-layout-group-body">{children}</div>
            </div>
          </div>
        )}
      </div>
    )
  },
)

MediaViewGroupContainer.displayName = 'MediaViewGroupContainer'

export default MediaViewGroupContainer
