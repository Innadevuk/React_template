import React from 'react'
import PropTypes from 'prop-types'
import _ from 'lodash'
import objectAssignDeep from 'object-assign-deep'
import { DEFAULT_STYLE } from 'utils/defaultValues'
import ContentGroup from 'components/ContentGroup'
import './index.scss'

function MenuStack({ groups = [], myGeo, data, style }) {
  if (!groups || !groups.length) return ''

  const refs = groups.reduce((acc, value) => {
    acc[value._id] = React.createRef()

    return acc
  }, {})

  const handleClick = id => {
    if (refs[id] && refs[id].current) {
      refs[id].current.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      })
    }
  }

  return (
    <div className="oe-dynamic-notification-menustack">
      <ul className="topbar">
        {groups.map(group => {
          const style = objectAssignDeep({ ...DEFAULT_STYLE }, _.get(group, 'style'))
          const groupIcon = _.get(group, 'data.desc.icon') || null
          const groupTitle = _.get(group, 'data.desc.title') || null

          const headStyle = {
            color: style?.title?.fg_color,
          }

          const lineStyle = {
            backgroundColor: style?.title?.bg_color,
            borderRadius: style?.outline?.radius,
          }

          return (
            <li className="topbar-item" key={group._id} onClick={() => handleClick(group._id)}>
              <div className="topbar-item-head" style={headStyle}>
                {groupIcon && <img src={groupIcon} alt="desc.icon" />}
                <div>{groupTitle}</div>
              </div>
              <div className="topbar-item-line" style={lineStyle} />
            </li>
          )
        })}
      </ul>
      {groups.map(group => (
        <ContentGroup group={group} key={group._id} myGeo={myGeo} ref={refs[group._id]} />
      ))}
    </div>
  )
}

MenuStack.propTypes = {
  groups: PropTypes.array,
  myGeo: PropTypes.object,
}

export default MenuStack
