import React from 'react'
import { Form, Row, Button } from 'react-bootstrap'
import * as queries from 'utils/queries'
import { useQuery } from '@apollo/react-hooks'
import InputSearchBar from 'components/InputSearchBar'
import './index.scss'

function WidgetsBar({ clientInfo, groupType, data }) {
  const { loading: loadingAreas, error: errorAreas, data: areas } = useQuery(
    queries.groupingQuery,
    {
      variables: {
        ids: null,
        clientId: clientInfo._id,
        type: 'Areas',
      },
    },
  )

  const { loading: loadingCatgs, error: errorCatgs, data: categories } = useQuery(
    queries.groupingQuery,
    {
      variables: {
        ids: null,
        clientId: clientInfo._id,
        type: groupType,
      },
    },
  )

  const bSearch = data?.widgets?.search || false
  const bCategory = (data?.widgets?.category || false) && !!groupType
  const bLocation = data?.widgets?.location || false
  const bSubscribe = data?.widgets?.subscribe || false

  if (!bSearch && !bCategory && !bLocation && !bSubscribe) return ''

  return (
    <div className="oe-dynamicpage-widgets-bar">
      <Form inline>
        {bSearch && (
          <Form.Group as={Row}>
            <InputSearchBar />
          </Form.Group>
        )}

        {bCategory && (
          <Form.Group as={Row} style={{ marginLeft: 'auto' }}>
            <Form.Label>Categories:&nbsp;&nbsp;</Form.Label>
            {loadingCatgs ? (
              <Form.Control as="select">
                <option value={null}>Loading</option>
              </Form.Control>
            ) : (
              <Form.Control as="select">
                <option value={null}>All</option>
                {categories.grouping.map(area => (
                  <option value={area._id} key={area._id}>
                    {area.name}
                  </option>
                ))}
              </Form.Control>
            )}
          </Form.Group>
        )}
        {bLocation && (
          <Form.Group as={Row} style={{ marginLeft: 'auto' }}>
            <Form.Label>Locations:&nbsp;&nbsp;</Form.Label>
            {loadingAreas ? (
              <Form.Control as="select">
                <option value={null}>Loading</option>
              </Form.Control>
            ) : (
              <Form.Control as="select">
                <option value={null}>All</option>
                <option value="myloc">My location</option>
                {areas.grouping.map(area => (
                  <option value={area._id} key={area._id}>
                    {area.name}
                  </option>
                ))}
              </Form.Control>
            )}
          </Form.Group>
        )}
        {bSubscribe && (
          <Form.Group as={Row} style={{ marginLeft: 'auto' }}>
            <Button variant="primary">Subscribe</Button>
          </Form.Group>
        )}
      </Form>
    </div>
  )
}

export default WidgetsBar
