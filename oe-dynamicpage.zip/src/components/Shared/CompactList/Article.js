/* eslint-disable no-nested-ternary */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import React, { useEffect, useState } from 'react'
import Slider from 'react-slick'
import { Player } from 'video-react'
import _ from 'lodash'
import moment from 'moment'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faVideo, faImage, faMapMarkerAlt } from '@fortawesome/free-solid-svg-icons'
import MapComponent from 'components/Shared/MapComponent'
import objectAssignDeep from 'object-assign-deep'
import { DEFAULT_STYLE } from 'utils/defaultValues'

import './Article.scss'

const Modes = {
  NONE: 'none',
  LIVE: 'Live',
  IMAGE: 'Images',
  VIDEO: 'Videos',
  LOC: 'Location',
}

const settings = {
  dots: true,
  infinite: true,
  fade: true,
  speed: 1500,
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplaySpeed: 5000,
  autoplay: true,
}

const CompactListArticle = ({
  myGeo,
  article,
  groupStyle: groupStyleFrom,
  layoutType,
  modeType,
}) => {
  const groupStyle = objectAssignDeep({ ...DEFAULT_STYLE }, groupStyleFrom)

  const [mode, setMode] = useState(modeType)
  const articleHeight = groupStyle?.mediabox?.height || 320
  const mediaLocation = groupStyle?.mediabox?.location
  const [height, setHeight] = useState(articleHeight)
  const [width, setWidth] = useState(articleHeight * (16 / 9))

  useEffect(() => {
    if (layoutType === 'AccordionArticle') setMode(modeType)
  }, [modeType, layoutType])

  useEffect(() => {
    if (typeof window.orientation !== 'undefined') {
      // setHeight('auto')
      setWidth('auto')
    } else if (layoutType === 'ArticleText') {
      setHeight('auto')
    } else {
      setWidth(articleHeight * (16 / 9))
    }

    window.addEventListener('resize', () => {
      if (window.innerWidth < 576) {
        // setHeight('auto')
        setWidth('auto')
      } else if (layoutType === 'ArticleText') {
        setHeight('auto')
      } else {
        setHeight(articleHeight)
        setWidth(articleHeight * (16 / 9))
      }
    })
  }, [])

  if (!article) return ''

  let contentRender = ''

  const imageList = _.get(article, 'imageList')
  const videoList = _.get(article, 'videoList')
  const location = _.get(article, 'location')
  const viewPort = _.get(location, 'viewport') || null
  const bImageList = imageList && imageList.length > 0
  const bVideoList = videoList && videoList.length > 0
  const bLocation =
    location && location.bActive && location.type && location.type !== 'none' && viewPort
  let mMode = mode

  const availableModes = []
  if (bImageList) availableModes.push(Modes.IMAGE)
  if (bVideoList) availableModes.push(Modes.VIDEO)
  if (bLocation) availableModes.push(Modes.LOC)

  if (availableModes.length) {
    if (mMode === Modes.IMAGE && !bImageList) [mMode] = availableModes
    if (mMode === Modes.VIDEO && !bVideoList) [mMode] = availableModes
    if (mMode === Modes.LOC && !bLocation) [mMode] = availableModes
  } else {
    mMode = Modes.NONE
  }

  const judgeMainBar = availableModes.length

  switch (mMode) {
    case Modes.IMAGE:
      contentRender = (
        <div className="oe-compact-list-article-item-media-image">
          <Slider {...settings}>
            {bImageList &&
              imageList.map((image, index) => <img alt="slide" src={image.url} key={index} />)}
          </Slider>
        </div>
      )
      break
    case Modes.VIDEO:
      contentRender = (
        <div className="oe-compact-list-article-item-media-video">
          {videoList && videoList.length > 0 && <Player src={videoList[0].url} playsInline />}
        </div>
      )
      break
    case Modes.LOC:
      contentRender = (
        <div className="oe-compact-list-article-item-media-location">
          {bLocation && myGeo && (
            <MapComponent
              googleMapURL="https://maps.googleapis.com/maps/api/js?key=AIzaSyDQ6fOZioeYFWHF-Q02vErr8v7duPXywRA&v=3.exp&libraries=geometry,drawing,places"
              loadingElement={<div className="loadingelement" />}
              mapElement={<div className="mapelement" id="map" />}
              containerElement={<div className="containerelement" />}
              zoom={location.viewport.zoom}
              center={{
                lat: myGeo.coordinate.latitude,
                lng: myGeo.coordinate.longitude,
              }}
              type={location.type}
              color={location.color}
              onPointAdd={() => {}}
              useCase={location.useCase}
              coordinates={location.coordinates}
              zones={location.zones}
              unit={location.viewport.unit}
              points={location.points}
              showCenterMark
            />
          )}
        </div>
      )
      break
    case Modes.NONE:
      contentRender = ''
      break
    default:
      break
  }

  const articleTitle = _.get(article, 'data.desc.title') || null
  const articleIcon = _.get(article, 'data.desc.icon')
  const articleShortDescr = _.get(article, 'data.desc.shortDescr') || null
  const articleLongDescr = _.get(article, 'data.desc.longDescr') || null
  const articleUpdatedAt = _.get(article, 'style.b_timestamp') ? _.get(article, 'updatedAt') : null
  const articleID = _.get(article, '_id') || 0
  const articleBody = _.get(article, 'data.HTML.body')

  const articleStyle = objectAssignDeep({ ...DEFAULT_STYLE }, _.get(article, 'style'))
  const articleFgColor = articleStyle?.fg_color
  const articleBgColor = articleStyle?.bg_color || groupStyle?.bg_color

  const articleOutline = {
    color: articleFgColor,
    backgroundColor: articleBgColor,
  }

  if (!article) {
    articleOutline.padding = '0px 30px'
  }

  if (articleStyle?.b_outline === true) {
    articleOutline.borderWidth = articleStyle?.outline?.width
    articleOutline.borderStyle = 'solid'
    articleOutline.borderColor = articleStyle?.outline?.color
    articleOutline.borderRadius = articleStyle?.outline?.radius
  }

  if (articleStyle?.b_shadow === true) {
    articleOutline.boxShadow = `3px 3px 3px ${articleStyle?.shadow?.color}`
  }

  return (
    <div className="oe-compact-list-article" key={articleID} style={{ height: 'auto' }}>
      <div className="oe-compact-list-article-item" style={articleOutline}>
        {layoutType !== 'AccordionArticle' && (
          <>
            {/* {mMode !== Modes.NONE && mediaLocation === 'left' && (
              <div className="oe-compact-list-article-item-media" style={{ height, width }}>
                {contentRender}
              </div>
            )} */}
            {/* <div className="oe-compact-list-article-item-text" style={{ height: 'auto' }}>
              {layoutType === 'AccordionArticle'
                ? articleLongDescr && (
                    <div className="oe-compact-list-article-item-text-long">{articleLongDescr}</div>
                  )
                : layoutType === 'AlertStack'
                ? (articleTitle || articleShortDescr || articleLongDescr) && (
                    <>
                      <div className="oe-compact-list-article-item-text-title">
                        {articleShortDescr}
                      </div>
                      <div className="oe-compact-list-article-item-text-long">
                        {articleLongDescr}
                      </div>
                    </>
                  )
                : (articleTitle || articleShortDescr || articleLongDescr) && (
                    <>
                      <div className="oe-compact-list-article-item-text-title">
                        {articleIcon && <img src={articleIcon} alt="desc.icon" />}
                        {articleTitle}
                      </div>
                      <div className="oe-compact-list-article-item-text-short">
                        {articleShortDescr}
                      </div>
                      <div className="oe-compact-list-article-item-text-long">
                        {articleLongDescr}
                      </div>
                    </>
                  )}
              {articleUpdatedAt && (
                <div className="oe-compact-list-article-item-text-time">
                  {`Updated: ${moment(articleUpdatedAt).format('MMM DD, hh:mm A')}`}
                </div>
              )}
            </div>
            {mMode !== Modes.NONE && mediaLocation === 'right' && (
              <div className="oe-compact-list-article-item-media" style={{ height, width }}>
                {contentRender}
                <div
                  className="oe-compact-list-article-item-media-selector"
                  style={{ display: judgeMainBar > 1 ? 'flex' : 'none' }}
                >
                  {bImageList && (
                    <span>
                      <FontAwesomeIcon
                        icon={faImage}
                        color="#1b95e0"
                        onClick={() => setMode(Modes.IMAGE)}
                      />
                    </span>
                  )}
                  {bVideoList && (
                    <span>
                      <FontAwesomeIcon
                        icon={faVideo}
                        color="#1b95e0"
                        onClick={() => setMode(Modes.VIDEO)}
                      />
                    </span>
                  )}
                  {bLocation && (
                    <span>
                      <FontAwesomeIcon
                        icon={faMapMarkerAlt}
                        color="#1b95e0"
                        onClick={() => setMode(Modes.LOC)}
                      />
                    </span>
                  )}
                </div>
              </div>
            )} */}
          </>
        )}
      </div>
      {articleBody && (
        <div
          className="oe-compact-list-article-body"
          dangerouslySetInnerHTML={{ __html: articleBody }}
        />
      )}
    </div>
  )
}

export default CompactListArticle
