/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import React, { useState } from 'react'
import Slider from 'react-slick'
import { graphql, withApollo } from 'react-apollo'

import { Player } from 'video-react'
import _ from 'lodash'
import moment from 'moment'
import * as compose from 'lodash.flowright'
import { Timeline } from 'react-twitter-widgets'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faTwitter } from '@fortawesome/free-brands-svg-icons'
import NWSListener from 'components/NWS'
import * as mutations from 'utils/mutations'
import { DEFAULT_STYLE } from 'utils/defaultValues'
import MediaViewGroupContainer from 'components/Shared/MediaViewGroup/Container'
import MediaViewGroupContentTopBarStacked from 'components/Shared/MediaViewGroup/Content/Top/BarStacked'
import objectAssignDeep from 'object-assign-deep'
import MapComponent from '../MapComponent'

import './index.scss'

const Modes = {
  NONE: 'none',
  LIVE: 'Live',
  IMAGE: 'Images',
  VIDEO: 'Videos',
  LOC: 'Location',
}

const settings = {
  dots: true,
  infinite: true,
  fade: true,
  speed: 1500,
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplaySpeed: 5000,
  autoplay: true,
}

const AdditionalIndex = {
  None: -1,
  Social: -2,
}

const GroupLayoutC = ({
  myGeo,
  group,
  refetch,
  upsertTracking,
  onDismissAlert,
  dismissable = true,
  data,
  style,
}) => {
  const { articles } = group
  const [current, setCurrent] = useState(AdditionalIndex.None)
  const [currentSocial, setCurrentSocial] = useState(-1)
  const [mode, setMode] = useState(Modes.IMAGE)

  if (!group) return ''

  const { style: groupStyleFrom } = group
  const params = {
    group,
    myGeo,
    layoutType: 'AlertStack',
    current,
  }
  const groupStyle = objectAssignDeep({ ...DEFAULT_STYLE }, groupStyleFrom)
  const titleFgColor = groupStyle?.title?.fg_color
  const titleBgColor = groupStyle?.title?.bg_color
  const fgColor = groupStyle?.fg_color
  const bgColor = groupStyle?.bg_color

  const outline = {
    backgroundColor: titleBgColor,
  }

  if (groupStyle?.b_outline === true) {
    outline.borderWidth = groupStyle?.outline?.width
    outline.borderStyle = 'solid'
    outline.borderColor = groupStyle?.outline?.color
    outline.borderRadius = groupStyle?.outline?.radius
  }

  if (groupStyle?.b_shadow === true) {
    outline.boxShadow = `3px 3px 3px${groupStyle?.shadow?.color}`
  }

  const groupHeaderBarStyle = {
    color: titleFgColor,
  }

  const groupFooterBarStyle = {
    color: fgColor,
  }

  const groupBodyBarStyle = {
    color: fgColor,
    backgroundColor: bgColor,
  }

  const groupTimeBarStyle = {
    display: groupStyle?.b_timestamp ? 'inherit' : 'none',
    color: titleFgColor,
    backgroundColor: 'rgba(196, 196, 196, 0.5)',
  }

  const articleSummaryBarStyle = {
    color: titleFgColor,
    backgroundColor: 'rgba(196, 196, 196, 0.7)',
  }

  if (current > -1) {
    // articleSummaryBarStyle.marginBottom = '5px'
  }

  const majorDividerStyle = {
    backgroundColor: groupStyle?.b_divide_major ? groupStyle?.divider_major : 'inherit',
  }

  const minorDividerStyle = {
    backgroundColor: groupStyle?.b_divide_minor ? groupStyle?.divider_minor : 'inherit',
  }

  const groupShortDescrStyle = {
    marginRight: groupStyle?.b_divide_major === false ? '14px' : '0px',
  }

  const article = articles.length ? articles[current] : null

  const articleStyle = objectAssignDeep({ ...DEFAULT_STYLE }, article?.style)

  const articleTitleBgColor = articleStyle?.title?.bg_color || bgColor
  const articleFgColor = articleStyle?.fg_color
  const articleBgColor = articleStyle?.bg_color || bgColor

  const articleBodyStyle = {
    color: articleFgColor,
    backgroundColor: articleBgColor,
  }

  const articleOutline = {
    backgroundColor: articleTitleBgColor,
    display: current !== -1 ? 'inherit' : 'none',
  }

  if (!article) {
    articleOutline.padding = '0px 30px'
  }

  if (articleStyle?.b_outline === true) {
    articleOutline.borderWidth = articleStyle?.outline?.width
    articleOutline.borderStyle = 'solid'
    articleOutline.borderColor = articleStyle?.outline?.color
    articleOutline.borderRadius = articleStyle?.outline?.radius
  }

  if (articleStyle?.b_shadow === true) {
    articleOutline.boxShadow = `3px 3px 3px ${articleStyle?.shadow?.color}`
  }

  let content = null
  const htmlType = _.get(article, 'data.HTML.htmlType')
  if (htmlType === 'mixed' || htmlType === 'body') {
    content = _.get(article, 'data.HTML.body') || null
  }

  let contentRender = ''
  const imageList = _.get(article, 'imageList')
  const videoList = _.get(article, 'videoList')
  const location = _.get(article, 'location')
  const viewPort = _.get(location, 'viewport') || null
  const bImageList = imageList && imageList.length > 0
  const bVideoList = videoList && videoList.length > 0
  const bLocation =
    location && location.bActive && location.type && location.type !== 'none' && viewPort
  let mMode = mode

  const availableModes = []
  if (bImageList) availableModes.push(Modes.IMAGE)
  if (bVideoList) availableModes.push(Modes.VIDEO)
  if (bLocation) availableModes.push(Modes.LOC)

  if (availableModes.length) {
    if (mMode === Modes.IMAGE && !bImageList) [mMode] = availableModes
    if (mMode === Modes.VIDEO && !bVideoList) [mMode] = availableModes
    if (mMode === Modes.LOC && !bLocation) [mMode] = availableModes
  } else {
    mMode = Modes.NONE
  }

  const judgeMainBar = availableModes.length

  const groupImage = _.get(group, 'data.desc.image') || null
  const groupShortDescr = _.get(group, 'data.desc.shortDescr') || null
  const groupLongDescr = _.get(group, 'data.desc.longDescr') || null

  switch (mMode) {
    case Modes.IMAGE:
      contentRender = (
        <div className="oe-group-layout-C-group-body-article-body-main-bar-right-media-image">
          <Slider {...settings}>
            {bImageList &&
              imageList.map((image, index) => <img alt="slide" src={image.url} key={index} />)}
          </Slider>
        </div>
      )
      break
    case Modes.VIDEO:
      contentRender = (
        <div className="oe-group-layout-C-group-body-article-body-main-bar-right-media-video">
          {videoList && videoList.length > 0 && <Player src={videoList[0].url} playsInline />}
        </div>
      )
      break
    case Modes.LOC:
      contentRender = (
        <div className="oe-group-layout-C-group-body-article-body-main-bar-right-media-location">
          {bLocation && myGeo && (
            <MapComponent
              googleMapURL="https://maps.googleapis.com/maps/api/js?key=AIzaSyDQ6fOZioeYFWHF-Q02vErr8v7duPXywRA&v=3.exp&libraries=geometry,drawing,places"
              loadingElement={<div className="loadingelement" />}
              mapElement={<div className="mapelement" id="map" />}
              containerElement={<div className="containerelement" />}
              zoom={location.viewport.zoom}
              center={{
                lat: myGeo.coordinate.latitude,
                lng: myGeo.coordinate.longitude,
              }}
              type={location.type}
              color={location.color}
              onPointAdd={() => {}}
              useCase={location.useCase}
              coordinates={location.coordinates}
              zones={location.zones}
              unit={location.viewport.unit}
              points={location.points}
              showCenterMark
            />
          )}
        </div>
      )
      break
    case Modes.NONE:
      contentRender = ''
      break
    default:
      break
  }

  const updatedAt = _.get(group, 'updatedAt')

  const sourceName = _.get(group, 'data.source') || null
  const sourceLogo = _.get(group, 'data.sourceLogo') || null

  const webLinks = _.get(group, 'data.webLinks') || []
  const sharedLinks = _.get(group, 'data.sharedLinks') || []
  const feeds = _.get(group, 'data.feeds') || []

  const articleSourceName = _.get(article, 'source.name') || null
  const articleSourceLogo = _.get(article, 'source.url') || null

  const articleImage = _.get(article, 'data.desc.image') || null
  let articleShortDescr = _.get(article, 'data.desc.shortDescr') || null
  const articleLongDescr = _.get(article, 'data.desc.longDescr') || null

  const groupIcon = _.get(group, 'data.desc.icon') || null
  const groupTitle = _.get(group, 'data.desc.title') || null

  let socialArticleBody = ''
  if (currentSocial >= 0 && feeds[currentSocial]) {
    const feed = feeds[currentSocial]
    switch (feed.type) {
      case 'Twitter':
        articleShortDescr = 'Twitter Feed'
        // socialArticleBody = <TwitterTimelineEmbed sourceType="profile" screenName={feed.value} options={{ height: 500 }} />
        socialArticleBody = (
          <Timeline
            dataSource={{
              sourceType: 'profile',
              screenName: feed.value,
            }}
            options={{
              username: 'TwitterDev',
              height: '500',
            }}
          />
        )
        break
      case 'NWS':
        articleShortDescr = 'NWS Feed'
        socialArticleBody = <NWSListener />
        break
      default:
        break
    }
  }

  const handleSharedLink = sharedLink => {
    upsertTracking({
      variables: {
        _id: group._id,
        collectionName: 'Groups',
        action: `Shared -${sharedLink.name}`,
        comment: `SharedLink (${sharedLink.name}) is clicked`,
      },
    })
      .then(() => {})
      .catch(err => {
        console.log(err)
      })
  }

  const setArticleIndex = (articleID, articleTitle, current) => {
    setCurrent(current)
    upsertTracking({
      variables: {
        _id: articleID,
        collectionName: 'Articles',
        action: 'Viewed',
        comment: `Article (${articleTitle}) is viewed`,
      },
    })
      .then(() => {})
      .catch(err => {
        console.log(err)
      })
  }

  return (
    <div>
      {_.get(group, 'availability.state') === 'on' && (
        <div className="oe-group-layout-C" style={outline}>
          {dismissable && (
            <div className="oe-dynamic-notifications-body-group-cancel" onClick={onDismissAlert}>
              &times;
            </div>
          )}
          <div className="oe-group-layout-C-group">
            <div className="oe-group-layout-C-group-header">
              {(groupIcon || groupTitle) && (
                <div
                  className="oe-group-layout-C-group-header-title-bar"
                  style={groupHeaderBarStyle}
                >
                  <div className="oe-group-layout-C-group-header-title-bar-group">
                    {groupIcon && <img src={groupIcon} alt="desc.icon" />}
                    <span>{groupTitle}</span>
                  </div>
                  {groupShortDescr && groupStyle?.b_divide_major && (
                    <div
                      className="oe-group-layout-C-group-header-title-bar-divider"
                      style={majorDividerStyle}
                    />
                  )}
                </div>
              )}
            </div>
            <div className="oe-group-layout-C-group-body">
              {(groupImage || groupShortDescr || groupLongDescr) && (
                <div className="oe-group-layout-C-group-body-desc-bar" style={groupBodyBarStyle}>
                  {groupImage && <img src={groupImage} alt="desc.clip" />}
                  <div className="oe-group-layout-C-group-body-desc-bar-text">
                    <div
                      className="oe-group-layout-C-group-body-desc-bar-text-short"
                      style={groupShortDescrStyle}
                    >
                      {groupShortDescr}
                      {groupShortDescr && groupStyle?.b_divide_minor && (
                        <div
                          className="oe-group-layout-C-group-body-desc-bar-text-divider"
                          style={minorDividerStyle}
                        />
                      )}
                    </div>
                    <div className="oe-group-layout-C-group-body-desc-bar-text-long">
                      {groupLongDescr}
                    </div>
                    {(groupIcon ||
                      groupTitle ||
                      groupImage ||
                      groupShortDescr ||
                      groupLongDescr) && (
                      <div
                        className="oe-group-layout-C-group-header-time-bar"
                        style={groupTimeBarStyle}
                      >
                        <div className="oe-group-layout-C-group-header-time-bar-updatedAt">{`Updated: ${moment(
                          updatedAt,
                        ).format('MMM DD, hh:mm A')}`}</div>
                      </div>
                    )}
                  </div>
                </div>
              )}
              {articles.length > 0 && (
                <div
                  className="oe-group-layout-C-group-body-articles-summary-bar"
                  style={articleSummaryBarStyle}
                >
                  {articles &&
                    articles.map((article, index) => {
                      const articleIcon = _.get(article, 'data.desc.icon') || null
                      const articleTitle = _.get(article, 'data.desc.title') || ''
                      const articleID = _.get(article, '_id') || 0

                      return (
                        <div key={articleID}>
                          {articleTitle.length > 0 && (
                            <div
                              className="oe-group-layout-C-group-body-articles-summary-bar-item"
                              onClick={() => {
                                if (refetch) refetch()
                                setCurrent(AdditionalIndex.None)
                                setCurrentSocial(-1)
                                setArticleIndex(articleID, articleTitle, index)
                              }}
                              style={{
                                color: index === current ? 'white' : 'inherit',
                              }}
                            >
                              <div className="oe-group-layout-C-group-body-articles-summary-bar-item-text">
                                {articleIcon && <img src={articleIcon} alt="article.icon" />}
                                <span>{articleTitle}</span>
                              </div>
                              {/* <div style={articleBottomDividerStyle} /> */}
                            </div>
                          )}
                        </div>
                      )
                    })}
                </div>
              )}
              {feeds.length > 0 && (
                <div className="oe-group-layout-C-group-body-feeds">
                  FEEDS:
                  {feeds.map((feed, index) => {
                    if (feed.type === 'Twitter') {
                      return (
                        <button
                          type="button"
                          onClick={() => {
                            setCurrentSocial(index)
                            setCurrent(AdditionalIndex.Social)
                          }}
                          key={index}
                        >
                          <FontAwesomeIcon
                            className="fa-twitter"
                            icon={faTwitter}
                            color="#1b95e0"
                            size="2x"
                          />
                        </button>
                      )
                    }
                    if (feed.type === 'NWS') {
                      return (
                        <button
                          type="button"
                          onClick={() => {
                            setCurrentSocial(index)
                            setCurrent(AdditionalIndex.Social)
                          }}
                          key={index}
                        >
                          <img src="/icons/NWS.png" alt="NWS" />
                        </button>
                      )
                    }
                  })}
                </div>
              )}
              <div className="oe-group-layout-C-group-body-article" style={articleOutline}>
                <div
                  className="oe-group-layout-C-group-body-article-cancel"
                  onClick={() => setCurrent(-1)}
                >
                  &times;
                </div>
                <MediaViewGroupContainer key={group._id} group={group} layoutType="AlertStack">
                  <MediaViewGroupContentTopBarStacked {...params} />
                </MediaViewGroupContainer>
                {/*{(articleImage || articleShortDescr || articleLongDescr) && (*/}
                {/*  <div className="oe-group-layout-C-group-body-article-header-bar" style={articleHeaderBarStyle}>*/}
                {/*    /!* {articleIcon && <img src={articleIcon} alt="desc.icon" />} *!/*/}
                {/*    /!* {articleImage && <img src={articleImage} alt="desc.image" />} *!/*/}
                {/*    <div className="oe-group-layout-C-group-body-article-header-bar-desc">*/}
                {/*      <span className="oe-group-layout-C-group-body-article-header-bar-desc-short">{articleShortDescr}</span>*/}
                {/*      {articleShortDescr && articleLongDescr && articleStyle?.b_divide_minor === true && (*/}
                {/*        <div className="oe-group-layout-C-group-body-article-header-bar-desc-divider" style={articleDescDividerStyle} />*/}
                {/*      )}*/}
                {/*      <span className="oe-group-layout-C-group-body-article-header-bar-desc-long">{articleLongDescr}</span>*/}
                {/*    </div>*/}
                {/*  </div>*/}
                {/*)}*/}

                <div className="oe-group-layout-C-group-body-article-body" style={articleBodyStyle}>
                  <div className="oe-group-layout-C-group-body-article-body-social">
                    {current === AdditionalIndex.Social && currentSocial >= 0
                      ? socialArticleBody
                      : ''}
                  </div>
                  {/*{((content && content.length) || mMode !== Modes.NONE) && (*/}
                  {/*  <div className="oe-group-layout-C-group-body-article-body-main-bar">*/}
                  {/*    {content && content.length && (*/}
                  {/*      <div className="oe-group-layout-C-group-body-article-body-main-bar-left">*/}
                  {/*        <div dangerouslySetInnerHTML={{ __html: content }} />*/}
                  {/*      </div>*/}
                  {/*    )}*/}
                  {/*    {mMode !== Modes.NONE && (*/}
                  {/*      <>*/}
                  {/*        <div className="oe-group-layout-C-group-body-article-body-main-bar-right">*/}
                  {/*          <div className="oe-group-layout-C-group-body-article-body-main-bar-right-media">{contentRender}</div>*/}
                  {/*        </div>*/}
                  {/*        <div className="oe-group-layout-C-group-body-article-body-main-bar-actions" style={{ display: judgeMainBar > 1 ? 'inherit' : 'none' }}>*/}
                  {/*          <div>*/}
                  {/*            {bImageList ? <span onClick={() => setMode(Modes.IMAGE)}>Images</span> : ''}*/}
                  {/*            {bVideoList ? <span onClick={() => setMode(Modes.VIDEO)}>Videos</span> : ''}*/}
                  {/*            {bLocation && <span onClick={() => setMode(Modes.LOC)}>Map</span>}*/}
                  {/*          </div>*/}
                  {/*        </div>*/}
                  {/*      </>*/}
                  {/*    )}*/}
                  {/*  </div>*/}
                  {/*)}*/}
                </div>
                {/*{(articleSourceLogo || articleSourceName) && (*/}
                {/*  <div className="oe-group-layout-C-group-body-article-action-bar" style={articleActionBarStyle}>*/}
                {/*    <div className="oe-group-layout-C-group-body-article-action-bar-source">*/}
                {/*      {(articleSourceLogo || articleSourceName) && <span>Source:</span>}*/}
                {/*      {articleSourceLogo && <img src={articleSourceLogo} alt="source.logo" />}*/}
                {/*      <span>{articleSourceName}</span>*/}
                {/*    </div>*/}
                {/*  </div>*/}
                {/*)}*/}
              </div>
            </div>
          </div>

          {((webLinks.length > 0 && _.isEmpty(webLinks[0]) !== true) ||
            (sharedLinks.length > 0 && _.isEmpty(sharedLinks[0]) !== true)) && (
            <div className="oe-group-layout-C-links">
              <div className="oe-group-layout-C-links-sharedLinks">
                {sharedLinks.length > 0 &&
                  _.isEmpty(sharedLinks[0]) !== true &&
                  sharedLinks.map((sharedLink, index) => (
                    // eslint-disable-next-line jsx-a11y/anchor-is-valid
                    <a
                      className="oe-group-layout-C-links-sharedLinks-item"
                      key={index}
                      onClick={() => {
                        handleSharedLink(sharedLink)
                      }}
                    >
                      {sharedLink.iconURL && <img src={sharedLink.iconURL} key={index} alt="" />}
                    </a>
                  ))}
              </div>
              <div className="oe-group-layout-C-links-webLinks">
                {webLinks.length > 0 &&
                  _.isEmpty(webLinks[0]) !== true &&
                  webLinks.map((link, index) => {
                    const label = _.get(link, 'label') || null
                    const iconURL = _.get(link, 'iconURL') || null
                    const url = _.get(link, 'url') || null

                    return (
                      <a
                        href={url}
                        className="oe-group-layout-C-links-webLinks-item"
                        key={index}
                        style={groupFooterBarStyle}
                      >
                        {iconURL && <img src={iconURL} alt="Icon URL" />}
                        {label && <span>{label}</span>}
                      </a>
                    )
                  })}
              </div>
            </div>
          )}

          {(sourceLogo || sourceName) && (
            <div className="oe-group-layout-C-footer-bar" style={groupFooterBarStyle}>
              <div className="oe-group-layout-C-footer-bar-source">
                {(sourceLogo || sourceName) && <span>Source:</span>}
                {sourceLogo && <img src={sourceLogo} alt="source.logo" />}
                <span>{sourceName}</span>
              </div>
            </div>
          )}
          {/*<div className="oe-group-layout-C-copyright">*/}
          {/*  <a style={{ color: titleFgColor, marginLeft: 'auto' }} href="https://openznet.com">*/}
          {/*    © OpenZNet Inc. 2020*/}
          {/*  </a>*/}
          {/*</div>*/}
        </div>
      )}
    </div>
  )
}

GroupLayoutC.defaultProps = {
  upsertTracking: () => {},
}

export default compose(
  graphql(mutations.upsertTracking, { name: 'upsertTracking' }),
  withApollo,
)(GroupLayoutC)
