import React, { useState } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faLink, faExternalLinkAlt, faMapMarked } from '@fortawesome/free-solid-svg-icons'

const Weblink = ({ data, width }) => {
  const [show, setShow] = useState(false)
  const showName = () => {
    if (!show) {
      setShow(true)
    } else {
      setShow(false)
    }
  }

  return (
    <div className="oe-menu-media-desc-contactbar weblinkbar" style={{ width }}>
      <span className="trigger">
        <FontAwesomeIcon icon={faLink} color="#1b95e0" onClick={showName} />
      </span>
      {show && (
        <div
          className="oe-menu-media-desc-contactbar-content"
          style={{
            backgroundColor: show ? 'lightgray' : '',
            opacity: show && 0.5,
            flexDirection: 'row',
          }}
        >
          {data.map((item, index) => {
            return (
              <span key={index}>
                <a href={`https://${item.url}`}>{item?.label}</a>
              </span>
            )
          })}
        </div>
      )}
    </div>
  )
}

export default Weblink
