import React, { useState } from 'react'
import { useMutation } from '@apollo/react-hooks'
import * as mutations from 'utils/mutations'
import { DEFAULT_STYLE } from 'utils/defaultValues'
import objectAssignDeep from 'object-assign-deep'
import Topbar from './Topbar'
import ArticleLinks from './ArticleLinks'
import Mediabox from './Mediabox'
import Descbox from './Descbox'
import Contactbar from './Contactbar'
import LeftMenu from 'components/LeftMenu'
import './index.scss'

const Modes = {
  NONE: 'none',
  LIVE: 'Live',
  IMAGE: 'Images',
  VIDEO: 'Videos',
  LOC: 'Location',
}

const MenuMediaDesc = ({ groups, myGeo, data, style }) => {
  const [groupIndex, selectGroupIndex] = useState(0)
  const [articleIndex, selectArticleIndex] = useState(-1)
  const [mediaMode, setMediaMode] = useState(Modes.IMAGE)
  const [upsertTracking] = useMutation(mutations.upsertTracking)

  if (!groups || !groups.length) return ''

  const group = groups[groupIndex]

  const articles = group?.articles
  const groupDesc = group?.data?.desc
  const groupStyleFrom = group?.style
  const groupStyle = objectAssignDeep({ ...DEFAULT_STYLE }, groupStyleFrom)

  const onGroupChange = index => {
    selectArticleIndex(-1)
    selectGroupIndex(index)
  }
  const onSelectArticleIndex = index => {
    if (index >= 0 && articles[index]) {
      upsertTracking({
        variables: {
          _id: articles[index]._id,
          collectionName: 'Articles',
          action: 'Viewed',
          comment: `Article (${articles[index].name}) is viewed`,
        },
      })
        .then(res => {
          console.log(res)
        })
        .catch(err => {
          console.log(err)
        })
    }
    selectArticleIndex(index)
  }

  const article = articles && articles.length && articleIndex >= 0 ? articles[articleIndex] : null
  const articleDesc = article?.data?.desc
  const articleStyleFrom = article?.style
  const articleStyle = objectAssignDeep({ ...DEFAULT_STYLE }, articleStyleFrom)
  const media = {
    imageList: article ? article?.imageList : group?.data?.imageList,
    videoList: article ? article?.videoList : group?.data?.videoList,
    location: article ? article?.location : group?.data?.location,
    height: (groupStyle?.mediabox?.width * 9) / 16,
    width: groupStyle?.mediabox?.width,
    mode: mediaMode,
    setMode: setMediaMode,
    myGeo,
  }

  const desc = {
    style: article ? articleStyle : groupStyle,
    icon: article ? articleDesc?.icon : groupDesc?.icon,
    title: article ? articleDesc?.title : groupDesc?.title,
    shortDescr: article ? articleDesc?.shortDescr : groupDesc?.shortDescr,
    longDescr: article ? articleDesc?.longDescr : groupDesc?.longDescr,
    image: article ? articleDesc?.image : groupDesc?.image,
    updatedAt: article ? article?.updatedAt : group?.updatedAt,
    imageHeight: groupStyle?.mediabox?.height,
    width: media.width,
  }

  const activeGroups = groups.filter(group => group?.availability?.state === 'on')

  return (
    <div className="oe-menu-media-desc">
      <Topbar groups={groups} onGroupChange={onGroupChange} />
      <ArticleLinks
        articles={articles}
        current={articleIndex}
        groupStyle={groupStyle}
        selectArticleIndex={onSelectArticleIndex}
      />
      {activeGroups && activeGroups.length>0 &&
        <LeftMenu group={group}/>
      }
      <div style={{ backgroundColor: groupStyle?.bg_color, position: 'relative'}}>
        <Mediabox {...media} subgroup={group} groups={groups} onGroupChange={onGroupChange}/>
        <Descbox {...desc} />
      </div>
    </div>
  )
}

export default MenuMediaDesc
