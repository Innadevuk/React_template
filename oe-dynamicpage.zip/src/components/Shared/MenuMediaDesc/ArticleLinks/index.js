/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable consistent-return */
import React from 'react'
import _ from 'lodash'
import Color from 'color'
import { Dropdown } from 'react-bootstrap'

const ArticleLinks = ({ articles, current, groupStyle, selectArticleIndex }) => {
  if (!articles || !articles.length) return ''

  const titleFgColor = groupStyle?.title?.fg_color
  const bg = Color(groupStyle?.bg_color)

  const b_show_highlight_bar = groupStyle?.b_show_highlight_bar
  const b_show_articles_count = groupStyle?.b_show_articles_count
  const text_articles_count = groupStyle?.text_articles_count
  const mediacount = groupStyle?.mediabox?.count < 3 ? 3 : groupStyle?.mediabox?.count || 4

  const articleSummaryBarStyle = {
    color: titleFgColor,
    backgroundColor: bg.lighten(0.5).hex(),
    borderLeft: b_show_highlight_bar ? `5px solid ${groupStyle?.hl_color}` : undefined,
    // opacity: 0.5,
  }

  const preArticles = articles.slice(0, mediacount)
  const moreArticles = articles.slice(mediacount)

  return (
    <div className="oe-menu-media-desc-articles-bar" style={articleSummaryBarStyle}>
      {b_show_articles_count && (
        <span className="label">
          {text_articles_count}&nbsp;{articles.length}
        </span>
      )}
      {preArticles.map((article, index) => {
        const articleIcon = _.get(article, 'data.desc.icon') || null
        const articleTitle = _.get(article, 'data.desc.title') || ''
        const articleID = _.get(article, '_id') || 0

        return (
          <div key={articleID}>
            {articleTitle.length > 0 && (
              <div
                className="oe-menu-media-desc-articles-bar-item"
                onClick={() => {
                  selectArticleIndex(index)
                }}
                style={{
                  color:
                    index === current
                      ? groupStyle?.hl_color
                      : article?.style?.title?.fg_color || 'black',
                }}
              >
                <div className="oe-menu-media-desc-articles-bar-item-text">
                  {articleIcon && <img src={articleIcon} alt="article.icon" />}
                  <span>{articleTitle}</span>
                </div>
                {/* <div style={articleBottomDividerStyle} /> */}
              </div>
            )}
          </div>
        )
      })}
      {moreArticles.length ? (
        <Dropdown className="more">
          <Dropdown.Toggle variant="link" id="dropdown-basic">
            More
          </Dropdown.Toggle>

          <Dropdown.Menu>
            {moreArticles.map((article, index) => {
              const articleIcon = _.get(article, 'data.desc.icon') || null
              const articleTitle = _.get(article, 'data.desc.title') || ''

              return (
                <Dropdown.Item
                  key={article._id}
                  onClick={() => selectArticleIndex(mediacount + index)}
                >
                  {articleIcon && <img src={articleIcon} alt="article.icon" />}
                  <span>{articleTitle}</span>
                </Dropdown.Item>
              )
            })}
          </Dropdown.Menu>
        </Dropdown>
      ) : (
        ''
      )}
    </div>
  )
}

export default ArticleLinks
