import React, { useState } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faAddressCard, faExternalLinkAlt, faMapMarked } from '@fortawesome/free-solid-svg-icons'

const Contactbar = ({ data, width }) => {
  const [show, setShow] = useState(false)
  const showName = () => {
    if (!show){
      setShow(true)
    } else {
      setShow(false)
    }
  }

  return (
    <div className="oe-menu-media-desc-contactbar" style={{ width}}>
        <span className="trigger">
          <FontAwesomeIcon icon={faAddressCard} color="#1b95e0" onClick={showName} />
        </span>
        {show && 
        <div className="oe-menu-media-desc-contactbar-content" style={{backgroundColor:show?'lightgray':'', opacity: show&&0.5}}>
            <span>{data?.name}</span>
            {data?.phone && (
              <a href={`tel:${data?.phone}`} className="navbar-contact-phone">
                <img src="/images/phone.png" alt="phone" />
              </a>
            )}
            {data?.email && (
              <a href={`mailto::${data?.email}`} className="navbar-contact-email">
                <img src="/images/mail.png" alt="email" />
              </a>
            )}
            {data?.address && (
              <a
                href={`https://www.google.com/maps/search/${data?.address}`}
                className="navbar-contact-email"
                target="_blank"
                rel="noopener noreferrer"
              >
                <FontAwesomeIcon icon={faMapMarked} color="black" />
              </a>
            )}
            {data?.website && (
              <a
                href={`https://${data?.website}`}
                className="navbar-contact-email"
                target="_blank"
                rel="noopener noreferrer"
              >
                <FontAwesomeIcon icon={faExternalLinkAlt} color="black" />
              </a>
            )}
        </div>
      }
    </div>
  )
}

export default Contactbar
