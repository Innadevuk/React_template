import React, { useState, useRef } from 'react'
import Slider from 'react-slick'
import ReactPlayer from 'react-player'
import MapComponent from 'components/Shared/MapComponent'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faHeart as faHeartRegular } from '@fortawesome/free-regular-svg-icons'
import {
  faVideo,
  faImage,
  faMapMarkerAlt,
  faHeart as faHeartSolid,
  faBars,
} from '@fortawesome/free-solid-svg-icons'
import { OverlayTrigger, Overlay, Popover, Col } from 'react-bootstrap'
import _ from 'lodash'
import Contactbar from '../Contactbar'
import Weblink from '../Weblink'
import './index.scss'

const Modes = {
  NONE: 'none',
  LIVE: 'Live',
  IMAGE: 'Images',
  VIDEO: 'Videos',
  LOC: 'Location',
}

const settings = {
  dots: true,
  infinite: true,
  fade: true,
  speed: 1500,
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplaySpeed: 5000,
  autoplay: true,
}

const Mediabox = ({
  imageList,
  videoList,
  location,
  mode,
  setMode,
  myGeo,
  width,
  height,
  subgroup,
  groups,
  onGroupChange,
}) => {
  const [currnetUrlIndex, setCurrentUrlIndex] = useState(0)
  const [like, setLike] = useState(true)
  const [menu, setMenu] = useState(false)
  const refs = useRef([])
  const viewPort = _.get(location, 'viewport') || null
  const bImageList = imageList && imageList.length > 0
  const bVideoList = videoList && videoList.length > 0
  const bLocation =
    location && location.bActive && location.type && location.type !== 'none' && viewPort
  let mMode = mode
  const availableModes = []
  if (bImageList) availableModes.push(Modes.IMAGE)
  if (bVideoList) availableModes.push(Modes.VIDEO)
  if (bLocation) availableModes.push(Modes.LOC)

  if (availableModes.length) {
    if (mMode === Modes.IMAGE && !bImageList) [mMode] = availableModes
    if (mMode === Modes.VIDEO && !bVideoList) [mMode] = availableModes
    if (mMode === Modes.LOC && !bLocation) [mMode] = availableModes
  } else {
    mMode = Modes.NONE
  }

  const showSelector = availableModes.length > 0

  const handleEnded = () => {
    let nextUrlIndex = (currnetUrlIndex + 1) % videoList.length
    setCurrentUrlIndex(nextUrlIndex)
  }

  const renderTooltip = ({ show }, name, ref) => (
    <Overlay show={show} target={ref} placement="top" container={ref.current}>
      <Popover placement="top">
        <Popover.Content>
          <div dangerouslySetInnerHTML={{ __html: name }} />
        </Popover.Content>
      </Popover>
    </Overlay>
  )

  const activeGroups = groups.filter(group => group?.availability?.state === 'on')

  let contentRender = ''
  switch (mMode) {
    case Modes.IMAGE:
      contentRender = (
        <div className="oe-menu-media-desc-mediabox-image">
          <Slider {...settings}>
            {bImageList &&
              imageList.map((image, index) => <img alt="slide" src={image.url} key={index} />)}
          </Slider>
        </div>
      )
      break
    case Modes.VIDEO:
      contentRender = (
        <div className="oe-menu-media-desc-mediabox-video">
          {videoList && videoList.length > 0 && (
            // <Player ref={player} src={videoList[currnetUrlIndex].url} ended={handleEnded} playsInline autoPlay muted />
            <ReactPlayer
              url={videoList[currnetUrlIndex].url}
              playsInline
              muted
              width="100%"
              height="100%"
              controls={true}
              playing={true}
              onEnded={handleEnded}
            />
          )}
        </div>
      )
      break
    case Modes.LOC:
      contentRender = (
        <div className="oe-menu-media-desc-mediabox-location">
          {bLocation && myGeo && (
            <MapComponent
              googleMapURL="https://maps.googleapis.com/maps/api/js?key=AIzaSyDQ6fOZioeYFWHF-Q02vErr8v7duPXywRA&v=3.exp&libraries=geometry,drawing,places"
              loadingElement={<div className="loadingelement" />}
              mapElement={<div className="mapelement" id="map" />}
              containerElement={<div className="containerelement" />}
              zoom={location.viewport.zoom}
              center={{
                lat: myGeo.coordinate.latitude,
                lng: myGeo.coordinate.longitude,
              }}
              type={location.type}
              color={location.color}
              onPointAdd={() => {}}
              useCase={location.useCase}
              coordinates={location.coordinates}
              zones={location.zones}
              unit={location.viewport.unit}
              points={location.points}
              showCenterMark
            />
          )}
        </div>
      )
      break
    case Modes.NONE:
      contentRender = ''
      break
    default:
      break
  }
  // if (mMode === Modes.NONE) return ''

  return (
    <div className="oe-menu-media-desc-mediabox">
      <div className="oe-menu-media-desc-mediabox-ratio" />
      <div className="oe-menu-media-desc-mediabox-content">{contentRender}</div>
      <div
        className="oe-menu-media-desc-mediabox-selector"
        style={{ display: 'flex', flexDirection: 'column', paddingTop: '10px' }}
      >
        <div className="oe-menu-media-desc-mediabox-menubar">
          <span>
            <FontAwesomeIcon icon={faBars} color="#1b95e0" onClick={() => setMenu(!menu)} />
          </span>
          {menu && (
            <div className="oe-menu-media-desc-mediabox-menubar-content">
              {activeGroups.map((group, index) => {
                const tooltipText = _.get(group, 'data.tooltip.text', '')
                const groupTitle = group?.data?.desc?.title
                const groupIcon = group?.data?.desc?.icon

                let renderItem
                if (tooltipText === '') {
                  renderItem = (
                    <Col key={index} sm>
                      <div
                        ref={refs.current[index]}
                        className="oe-menu-media-desc-topbar-item"
                        style={{
                          // borderBottomColor: _.get(group, 'style.hl_color', 'gray'),
                          // borderBottomWidth: '4px',
                          // borderBottomStyle: 'solid',
                          fontWeight: 'bold',
                        }}
                        onClick={() => {
                          onGroupChange(index)
                          setMenu(false)
                        }}
                      >
                        {groupIcon && <img src={groupIcon} alt="icon" />}
                        {groupTitle}
                      </div>
                    </Col>
                  )
                } else {
                  renderItem = (
                    <Col key={group._id} sm>
                      <OverlayTrigger
                        placement="top"
                        delay={{ show: 250, hide: 250 }}
                        overlay={props =>
                          renderTooltip(props, tooltipText || '', refs.current[index])
                        }
                      >
                        <div
                          id={index}
                          ref={refs.current[index]}
                          className="oe-menu-media-desc-topbar-item"
                          style={{
                            // borderBottomColor: _.get(group, 'style.title.bg_color', 'gray'),
                            // borderBottomWidth: '4px',
                            // borderBottomStyle: 'solid',
                            borderRadius: _.get(group, 'style.outline.radius'),
                            fontWeight: 'bold',
                          }}
                          onClick={() => {
                            onGroupChange(index)
                            setMenu(false)
                          }}
                        >
                          {groupIcon && <img src={groupIcon} alt="icon" />}
                          {groupTitle}
                        </div>
                      </OverlayTrigger>
                    </Col>
                  )
                }
                return renderItem
              })}
            </div>
          )}
        </div>
        {bImageList && (
          <span>
            <FontAwesomeIcon icon={faImage} color="#1b95e0" onClick={() => setMode(Modes.IMAGE)} />
          </span>
        )}
        {bVideoList && (
          <span>
            <FontAwesomeIcon icon={faVideo} color="#1b95e0" onClick={() => setMode(Modes.VIDEO)} />
          </span>
        )}
        {bLocation && (
          <span>
            <FontAwesomeIcon
              icon={faMapMarkerAlt}
              color="#1b95e0"
              onClick={() => setMode(Modes.LOC)}
            />
          </span>
        )}
        {subgroup?.data?.contact?.name && (
          <Contactbar data={subgroup?.data?.contact} width={width} />
        )}
        {subgroup?.data?.webLinks && subgroup.data.webLinks.length > 0 && (
          <Weblink data={subgroup?.data?.webLinks} width={width} />
        )}
        {mMode !== Modes.NONE && (
          <>
            {like ? (
              <span>
                <FontAwesomeIcon
                  icon={faHeartRegular}
                  color="#1b95e0"
                  onClick={() => setLike(!like)}
                />
              </span>
            ) : (
              <span>
                <FontAwesomeIcon
                  icon={faHeartSolid}
                  color="#1b95e0"
                  onClick={() => setLike(!like)}
                />
              </span>
            )}
          </>
        )}
      </div>
    </div>
  )
}

export default Mediabox
