import React from 'react'
import moment from 'moment'

const Descbox = ({
  style,
  icon,
  title,
  shortDescr,
  longDescr,
  image,
  updatedAt,
  imageHeight,
  width,
}) => {
  const fgColor = style?.fg_color
  const bgColor = style?.bg_color
  const titleFgColor = style?.title?.fg_color
  const titleBgColor = style?.title?.bg_color

  const outline = {
    backgroundColor: titleBgColor,
    width,
    // height,
  }

  if (style?.b_outline === true) {
    outline.borderWidth = style?.outline?.width
    outline.borderStyle = 'solid'
    outline.borderColor = style?.outline?.color
    outline.borderRadius = style?.outline?.radius
  }

  if (style?.b_shadow === true) {
    outline.boxShadow = `3px 3px 3px${style?.shadow?.color}`
  }

  const groupTimeBarStyle = {
    display: style?.b_timestamp ? 'inherit' : 'none',
    color: titleFgColor,
    backgroundColor: 'rgba(196, 196, 196, 0.5)',
  }

  const titleBarStyle = {
    color: titleFgColor,
  }

  const majorDividerStyle = {
    backgroundColor: style?.b_divide_major ? style?.divider_major : 'inherit',
  }

  const minorDividerStyle = {
    backgroundColor: style?.b_divide_minor ? style?.divider_minor : 'inherit',
  }

  const bodyBarStyle = {
    color: fgColor,
    backgroundColor: bgColor,
  }

  const shortDescrStyle = {
    marginRight: style?.b_divide_major === false ? '14px' : '0px',
  }

  const timestamp = moment(updatedAt).format('MMM DD, hh:mm A')

  return (
    <div className="oe-menu-media-desc-descbox" style={outline}>
      {/* <div className="oe-menu-media-desc-descbox-header">
        {(icon || title) && (
          <div className="oe-menu-media-desc-descbox-header-title-bar" style={titleBarStyle}>
            <div className="oe-menu-media-desc-descbox-header-title-bar-group">
              {icon && <img src={icon} alt="desc.icon" />}
              <span>{title}</span>
            </div>
            {shortDescr && style?.b_divide_major && (
              <div
                className="oe-menu-media-desc-descbox-header-title-bar-divider"
                style={majorDividerStyle}
              />
            )}
          </div>
        )}
      </div> */}
      <div className="oe-menu-media-desc-descbox-body">
        {(image || shortDescr || longDescr) && (
          <div className="oe-menu-media-desc-descbox-body-desc-bar" style={bodyBarStyle}>
            {image && <img style={{ height: imageHeight }} src={image} alt="desc.clip" />}
            <div className="oe-menu-media-desc-descbox-body-desc-bar-text">
              <div
                className="oe-menu-media-desc-descbox-body-desc-bar-text-short"
                style={shortDescrStyle}
              >
                {shortDescr}
                {shortDescr && style?.b_divide_minor && (
                  <div
                    className="oe-menu-media-desc-descbox-body-desc-bar-text-divider"
                    style={minorDividerStyle}
                  />
                )}
              </div>
              <div className="oe-menu-media-desc-descbox-body-desc-bar-text-long">{longDescr}</div>
              {(icon || title || image || shortDescr || longDescr) && (
                <div
                  className="oe-menu-media-desc-descbox-header-time-bar"
                  style={groupTimeBarStyle}
                >
                  <div className="oe-menu-media-desc-descbox-header-time-bar-updatedAt">
                    Updated:&nbsp;
                    {timestamp}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default Descbox
