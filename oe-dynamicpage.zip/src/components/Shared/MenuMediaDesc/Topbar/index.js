/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import React, { useRef } from 'react'
import { OverlayTrigger, Overlay, Popover, Container, Row, Col, Dropdown } from 'react-bootstrap'
import _ from 'lodash'

const Topbar = ({ groups, onGroupChange }) => {
  const refs = useRef([])

  if (!groups || !groups.length) return ''

  const renderTooltip = ({ show }, name, ref) => (
    <Overlay show={show} target={ref} placement="top" container={ref.current}>
      <Popover placement="top">
        <Popover.Content>
          <div dangerouslySetInnerHTML={{ __html: name }} />
        </Popover.Content>
      </Popover>
    </Overlay>
  )

  const activeGroups = groups.filter(group => group?.availability?.state === 'on')
  const inactiveGroups = groups.filter(group => group?.availability?.state !== 'on')

  return (
    <Container className="oe-menu-media-desc-topbar">
      <Row>
        {/* {activeGroups.map((group, index) => {
          const tooltipText = _.get(group, 'data.tooltip.text', '')
          // const oldActive =
          //   _.get(group, 'availability.state') !== 'on' && _.get(group, 'availability.availableAt')
          const groupTitle = group?.data?.desc?.title
          const groupIcon = group?.data?.desc?.icon

          let renderItem
          if (tooltipText === '') {
            renderItem = (
              <Col key={index} sm>
                <div
                  ref={refs.current[index]}
                  className="oe-menu-media-desc-topbar-item"
                  style={{
                    borderBottomColor: _.get(group, 'style.hl_color', 'gray'),
                    borderBottomWidth: '4px',
                    borderBottomStyle: 'solid',
                    // borderRadius: _.get(group, 'style.outline.radius'),
                    fontWeight: 'bold',
                  }}
                  onClick={() => onGroupChange(index)}
                >
                  {groupIcon && <img src={groupIcon} alt="icon" />}
                  {groupTitle}
                </div>
              </Col>
            )
          } else {
            renderItem = (
              <Col key={group._id} sm>
                <OverlayTrigger
                  placement="top"
                  delay={{ show: 250, hide: 250 }}
                  overlay={props => renderTooltip(props, tooltipText || '', refs.current[index])}
                >
                  <div
                    id={index}
                    ref={refs.current[index]}
                    className="oe-menu-media-desc-topbar-item"
                    style={{
                      borderBottomColor: _.get(group, 'style.title.bg_color', 'gray'),
                      borderBottomWidth: '4px',
                      borderBottomStyle: 'solid',
                      borderRadius: _.get(group, 'style.outline.radius'),
                      fontWeight: 'bold',
                    }}
                    onClick={() => onGroupChange(index)}
                  >
                    {groupIcon && <img src={groupIcon} alt="icon" />}
                    {groupTitle}
                  </div>
                </OverlayTrigger>
              </Col>
            )
          }

          return renderItem
        })} */}
        {inactiveGroups.length ? (
          <Dropdown className="more">
            <Dropdown.Toggle variant="link" id="dropdown-basic">
              More
            </Dropdown.Toggle>

            <Dropdown.Menu>
              {inactiveGroups.map((group, index) => {
                const groupTitle = group?.data?.desc?.title
                const groupIcon = group?.data?.desc?.icon

                return (
                  <Dropdown.Item
                    key={group._id}
                    onClick={() => onGroupChange(activeGroups.length + index)}
                  >
                    {groupIcon && <img src={groupIcon} alt="icon" />}
                    {groupTitle}
                  </Dropdown.Item>
                )
              })}
            </Dropdown.Menu>
          </Dropdown>
        ) : (
          ''
        )}
      </Row>
    </Container>
  )
}

export default Topbar
