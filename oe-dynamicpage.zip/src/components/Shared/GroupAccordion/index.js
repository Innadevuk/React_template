import React, { useEffect, useState } from 'react'
import { Accordion, Card, useAccordionToggle } from 'react-bootstrap'
import _ from 'lodash'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {
  faAngleUp,
  faAngleDown,
  faImage,
  faVideo,
  faMapMarkerAlt,
} from '@fortawesome/free-solid-svg-icons'
import objectAssignDeep from 'object-assign-deep'
import { DEFAULT_STYLE } from 'utils/defaultValues'
import FeaturedArticle from 'components/Shared/MediaViewGroup/Content/Top/Article'
import Slider from 'react-slick'
import { Player } from 'video-react'
import MapComponent from 'components/Shared/MapComponent'

import './index.scss'

const Modes = {
  NONE: 'none',
  LIVE: 'Live',
  IMAGE: 'Images',
  VIDEO: 'Videos',
  LOC: 'Location',
}
const settings = {
  dots: true,
  infinite: true,
  fade: true,
  speed: 1500,
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplaySpeed: 5000,
  autoplay: true,
}

const GroupAccordion = ({ groups, myGeo, data }) => {
  const openFlag = _.get(data, 'openFlag') || null
  const [evtKey, setEvtKey] = useState(null)
  const [isOpen, setToggle] = useState(false)
  const [isSubOpen, setSubToggle] = useState(false)
  const [evtArticleKey, setEvtArticleKey] = useState(null)
  const [mode, setMode] = useState(null)
  const [groupMode, setGroupMode] = useState('Articles')
  const [show, setShow] = useState(false)
  const groupStyle = objectAssignDeep({ ...DEFAULT_STYLE }, groups[0].style)
  const bOutlineColor = groupStyle?.outline?.color
  const bOutlineRadius = groupStyle?.outline?.radius
  const bOutlineWidth = groupStyle?.outline?.width
  const activeGroups = groups.filter(group => group?.availability?.state === 'on')
  const inactiveGroups = groups.filter(group => group?.availability?.state !== 'on')
  console.log(openFlag, groupMode)

  const CustomToggle = ({ id, group, eventKey}) => {
    let articleCount = group.articles ? group.articles.length : 0
    const groupStyle = objectAssignDeep({ ...DEFAULT_STYLE }, group.style)
    const bShowArticleCount = groupStyle?.b_show_articles_count
    const bShowShortDescr = groupStyle?.b_show_short_descr
    const textArticlesCount = groupStyle?.text_articles_count
    const bShowHighlightBar = groupStyle?.b_show_highlight_bar
    const capita = group?.private?.Capita
    if (articleCount > 20) articleCount = 20
    const imageList = group?.data?.imageList
    const videoList = group?.data?.videoList
    const location = group?.data?.location

    const decoratedOnClick = useAccordionToggle(eventKey, () => {
      setEvtKey(eventKey)
      setToggle(!isOpen)
    })
    const toggleEvent = (event, toggleType) => {
      event.preventDefault()
      event.stopPropagation()
      decoratedOnClick()
      setGroupMode(toggleType)
    }

    return (
      <Card.Header
        style={{
          backgroundColor: groupStyle?.title?.bg_color,
          color: groupStyle?.title?.fg_color,
        }}
        onClick={decoratedOnClick}
      >
        <div className="oe-dynamic-page-accordion-groups-header">
          {bShowHighlightBar && bShowArticleCount && (
            <div
              className="color-bar"
              style={{
                backgroundColor: groupStyle?.hl_color,
                opacity: articleCount * 0.05,
              }}
            />
          )}
          {_.get(group, 'data.desc.icon') && (
            <img
              src={_.get(group, 'data.desc.icon')}
              className="oe-dynamic-page-accordion-groups-icon"
              alt=""
            />
          )}
          <div className="oe-dynamic-page-accordion-groups-title">
            {_.get(group, 'data.desc.title')}
          </div>
          {bShowArticleCount && (
            <>
              &nbsp;-&nbsp;
              {articleCount}
              &nbsp;
              {textArticlesCount}
              &nbsp;
              {capita ? `${(articleCount / capita) * 100}%` : ''}
            </>
          )}
          {bShowShortDescr && (
            <span className="shortDescr">{_.get(group, 'data.desc.shortDescr')}</span>
          )}
        </div>
        <div className="oe-dynamic-page-accordion-groups-action">
          <div className="oe-dynamic-page-accordion-groups-media-selector">
            {imageList && imageList.length > 0 && (
              <span>
                <FontAwesomeIcon
                  icon={faImage}
                  color="#1b95e0"
                  onClick={e => toggleEvent(e, 'Images')}
                />
              </span>
            )}
            {videoList && videoList.length > 0 && (
              <span>
                <FontAwesomeIcon
                  icon={faVideo}
                  color="#1b95e0"
                  onClick={e => toggleEvent(e, 'Videos')}
                />
              </span>
            )}
            {location && location.bActive && location.type && location.type !== 'none' && (
              <span>
                <FontAwesomeIcon
                  icon={faMapMarkerAlt}
                  color="#1b95e0"
                  onClick={e => toggleEvent(e, 'Location')}
                />
              </span>
            )}
          </div>
          {articleCount > 0 && openFlag === null ? (
            <>
              {evtKey === id && isOpen ? (
                <FontAwesomeIcon
                  onClick={e => toggleEvent(e, 'Articles')}
                  className="arrow"
                  icon={faAngleUp}
                  size="lg"
                />
              ) : (
                <FontAwesomeIcon
                  onClick={e => toggleEvent(e, 'Articles')}
                  className="arrow"
                  icon={faAngleDown}
                  size="lg"
                />
              )}
            </>
          ) : (
            ''
          )}
        </div>
      </Card.Header>
    )
  }

  const CustomCollapse = ({ group, height }) => {
    useEffect(() => {
      const slickSlider = document.getElementsByClassName('slick-image')
      if (slickSlider) {
        for (let i = 0; i < slickSlider.length; i += 1) {
          slickSlider[i].style.height = `${height}px`
          slickSlider[i].style.width = 'auto'
        }
      }
    }, [])

    let contentRender = ''
    const imageList = _.get(group, 'data.imageList')
    const videoList = _.get(group, 'data.videoList')
    const location = _.get(group, 'data.location')
    const viewPort = _.get(location, 'viewport') || null
    const bImageList = imageList && imageList.length > 0
    const bVideoList = videoList && videoList.length > 0
    const bLocation =
      location && location.bActive && location.type && location.type !== 'none' && viewPort
    let mMode = groupMode

    const availableModes = []
    if (bImageList) availableModes.push(Modes.IMAGE)
    if (bVideoList) availableModes.push(Modes.VIDEO)
    if (bLocation) availableModes.push(Modes.LOC)

    if (availableModes.length) {
      if (mMode === Modes.IMAGE && !bImageList) [mMode] = availableModes
      if (mMode === Modes.VIDEO && !bVideoList) [mMode] = availableModes
      if (mMode === Modes.LOC && !bLocation) [mMode] = availableModes
    } else {
      mMode = Modes.NONE
    }

    switch (mMode) {
      case Modes.IMAGE:
        contentRender = (
          <div className="oe-featured-layout-group-body-featured-bar-article-item-media-image">
            <Slider {...settings}>
              {bImageList &&
                imageList.map((image, index) => (
                  <img alt="slide" src={image.url} key={index} className="slick-image" />
                ))}
            </Slider>
          </div>
        )
        break
      case Modes.VIDEO:
        contentRender = (
          <div className="oe-featured-layout-group-body-featured-bar-article-item-media-video">
            {videoList && videoList.length > 0 && <Player src={videoList[0].url} playsInline />}
          </div>
        )
        break
      case Modes.LOC:
        contentRender = (
          <div className="oe-featured-layout-group-body-featured-bar-article-item-media-location">
            {bLocation && myGeo && (
              <MapComponent
                googleMapURL="https://maps.googleapis.com/maps/api/js?key=AIzaSyDQ6fOZioeYFWHF-Q02vErr8v7duPXywRA&v=3.exp&libraries=geometry,drawing,places"
                loadingElement={<div className="loadingelement" />}
                mapElement={<div className="mapelement" id="map" />}
                containerElement={<div className="containerelement" />}
                zoom={location.viewport.zoom}
                center={{
                  lat: myGeo.coordinate.latitude,
                  lng: myGeo.coordinate.longitude,
                }}
                type={location.type}
                color={location.color}
                onPointAdd={() => {}}
                useCase={location.useCase}
                coordinates={location.coordinates}
                zones={location.zones}
                unit={location.viewport.unit}
                points={location.points}
                showCenterMark
              />
            )}
          </div>
        )
        break
      case Modes.NONE:
        contentRender = ''
        break
      default:
        break
    }

    return contentRender
  }

  const ArticleToggle = ({ children, eventKey, article }) => {
    const imageList = article?.imageList
    const videoList = article?.videoList
    const location = article?.location

    const decoratedOnClick = useAccordionToggle(eventKey, () => {
      console.log('article decorated', eventKey, isSubOpen)
      setEvtArticleKey(eventKey)
      setSubToggle(!isSubOpen)
      if (!mode) {
        if (article?.data?.desc?.longDescr) {
          setMode('Long')
        } else if (imageList && imageList.length > 0) {
          setMode(Modes.IMAGE)
        } else if (videoList && videoList.length > 0) {
          setMode(Modes.VIDEO)
        } else if (location && location.bActive && location.type && location.type !== 'none') {
          setMode(Modes.LOC)
        }
      }
    })

    return <div onClick={decoratedOnClick}>{children}</div>
  }

  const CustomRenderList = ({customgroups}) => {
    return customgroups.map((group, index) => {
      let articleCount = group.articles ? group.articles.length : 0
      const groupStyle = objectAssignDeep({ ...DEFAULT_STYLE }, group.style)
      const articleHeight = groupStyle?.mediabox?.height || 320
      const height = articleHeight
      const width = articleHeight * (16 / 9)
      const bShowShortDescr = groupStyle?.b_show_short_descr
      if (articleCount > 20) articleCount = 20
      return (
        <Card key={group._id} style={{ marginLeft: '10px', overflow: 'visible' }}>
          <CustomToggle id={index} group={group} eventKey={index}/>
          {groupMode !== 'Articles' && (
            <Accordion.Collapse eventKey={openFlag ? 0 : index}>
              <Card.Body>
                {(groupMode === 'Images' ||
                  groupMode === 'Videos' ||
                  groupMode === 'Location') && (
                  <div
                    className="oe-dynamic-page-accordion-groups-item-media"
                    style={{ height, width, margin: '0 auto' }}
                  >
                    <CustomCollapse group={group} height={height} />
                  </div>
                )}
              </Card.Body>
            </Accordion.Collapse>
          )}
          {articleCount > 0 && groupMode === 'Articles' && (
            <Accordion.Collapse eventKey={openFlag ? 0 : index}>
              <Card.Body
                style={{
                  backgroundColor: evtKey === index ? groupStyle?.title?.bg_color : '',
                  padding: '0.55rem',
                  borderColor: bOutlineColor,
                  borderWidth: bOutlineWidth,
                  borderRadius: bOutlineRadius,
                }}
              >
                <Accordion className="oe-dynamic-page-accordion-articles">
                  {group.articles &&
                    group.articles.map((article, articleIndex) => {
                      const articleStyle = objectAssignDeep({ ...DEFAULT_STYLE }, article?.style)

                      return (
                        <Card key={article._id}>
                          <ArticleToggle eventKey={articleIndex} article={article}>
                            <Card.Header
                              style={{
                                backgroundColor: articleStyle?.title?.bg_color,
                                color: articleStyle?.title?.fg_color,
                              }}
                            >
                              <div>
                                {article?.data?.desc?.icon && (
                                  <img
                                    src={article?.data?.desc?.icon}
                                    className="oe-dynamic-page-accordion-articles-icon"
                                    alt=""
                                  />
                                )}
                                <div className="oe-dynamic-page-accordion-articles-title">
                                  {article?.data?.desc?.title}
                                </div>
                                {articleStyle?.b_divide_major && (
                                  <div
                                    className="oe-dynamic-page-accordion-articles-divider"
                                    style={{ borderColor: articleStyle?.divider_major }}
                                  />
                                )}
                                {isSubOpen && (
                                  <span className="shortDescr">
                                    {article?.data?.desc?.shortDescr}
                                  </span>
                                )}
                              </div>
                              <div style={{ display: 'flex' }}>
                                {/* <div className="oe-dynamic-page-accordion-articles-media-selector">
                                </div> */}
                                {evtArticleKey === articleIndex && isSubOpen ? (
                                  <FontAwesomeIcon className="arrow" icon={faAngleUp} size="lg" />
                                ) : (
                                  <FontAwesomeIcon
                                    className="arrow"
                                    icon={faAngleDown}
                                    size="lg"
                                  />
                                )}
                              </div>
                            </Card.Header>
                          </ArticleToggle>
                          <Accordion.Collapse eventKey={articleIndex}>
                            <Card.Body>
                              <FeaturedArticle
                                article={article}
                                layoutType="AlertStack"
                                myGeo={myGeo}
                                groupStyle={groupStyle}
                                // modeType={mode}
                              />
                            </Card.Body>
                          </Accordion.Collapse>
                        </Card>
                      )
                    })}
                </Accordion>
              </Card.Body>
            </Accordion.Collapse>
          )}
        </Card>
      )
    })
  }

  return (
    <Accordion className="oe-dynamic-page-accordion-groups" defaultActiveKey={openFlag ? 0 : null}>
      <CustomRenderList customgroups={activeGroups}/>
      <div className="oe-dynamic-page-accordion-articles-morebutton" onClick={() => setShow(!show)}>
        <div className="oe-dynamic-page-accordion-articles-buttontext">
          More
        </div>
        <FontAwesomeIcon
          className="arrow"
          icon={faAngleDown}
          size="lg"
        />
      </div>
      {show && <CustomRenderList customgroups={inactiveGroups}/>}
    </Accordion>
  )
}

export default GroupAccordion
