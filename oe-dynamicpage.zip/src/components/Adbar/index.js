import React from 'react'
import './index.scss'

export default function Adbar() {
  return (
    <div className="oe-dynamicpage-adbar" style={{ zIndex: 1 }}>
      <div className="inner selfClear">
        <p className="dropdown">
          <a
            href="/MyAccount/ProfileCreate"
            role="button"
            className="myConnections"
            id="signedOutToolbarCreateProfileButton"
          >
            Create an Account
          </a>
          <span className="welcomeMessage">
            - Increase your productivity, customize your experience, and engage in information you
            care about. &nbsp;&nbsp;
          </span>
        </p>
        <ul className="nav secondary">
          <li>
            <a href="/MyAccount" role="button" className="button" id="loggedOutToolbarSignInButton">
              <span>Sign In</span>
            </a>
          </li>
        </ul>
      </div>
    </div>
  )
}
