/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React from 'react'
import _ from 'lodash'

import MediaViewGroupContainer from 'components/Shared/MediaViewGroup/Container'
import MediaViewGroupContentTopBarCarousel from 'components/Shared/MediaViewGroup/Content/Top/BarCarousel'
import MediaViewGroupContentTopBarStacked from 'components/Shared/MediaViewGroup/Content/Top/BarStacked'
import MediaViewGroupContentTopBarTextStacked from 'components/Shared/MediaViewGroup/Content/Top/BarTextStacked'
import GroupImageList from 'components/Shared/ImageList'

import './index.scss'

const ContentGroups = ({ groups, myGeo }) => (
  <div className="oe-dynamicpage-groups">
    {groups.map(group => {
      const layoutType = _.get(group, 'data.layout.type') || 'ArticlesStack'
      const params = { group, myGeo }

      switch (layoutType) {
        case 'ArticlesCarousel':
          return (
            <MediaViewGroupContainer key={group._id} group={group} layoutType={layoutType}>
              <MediaViewGroupContentTopBarCarousel {...params} />
            </MediaViewGroupContainer>
          )
        case 'ArticlesStack':
          return (
            <MediaViewGroupContainer key={group._id} group={group} layoutType={layoutType}>
              <MediaViewGroupContentTopBarStacked {...params} />
            </MediaViewGroupContainer>
          )
        case 'ArticleText':
          return (
            <MediaViewGroupContainer key={group._id} group={group} layoutType={layoutType}>
              <MediaViewGroupContentTopBarTextStacked {...params} />
            </MediaViewGroupContainer>
          )
        case 'ArticleThumbnail':
          return (
            <MediaViewGroupContainer key={group._id} group={group} layoutType={layoutType}>
              <MediaViewGroupContentTopBarStacked {...params} />
            </MediaViewGroupContainer>
          )
        case 'ImageList':
          return <GroupImageList key={group._id} group={group} />
        default:
          break
      }

      return ''
    })}
  </div>
)

export default ContentGroups
