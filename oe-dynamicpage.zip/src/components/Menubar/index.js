import React, { Component } from 'react'
import { withRouter } from 'react-router-dom'
import { Navbar, Nav, Button, Modal } from 'react-bootstrap'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPhoneVolume, faEnvelope } from '@fortawesome/free-solid-svg-icons'
import styled from 'styled-components'
import _ from 'lodash'
import objectAssignDeep from 'object-assign-deep'
import { DEFAULT_STYLE } from 'utils/defaultValues'
import './index.scss'

const OeNavbar = styled(Navbar)`
  background-color: ${props => (props.bshrink === 'true' ? props.bgcolor1 : props.bgcolor)};
  svg {
    color: ${props =>
      props.bshrink === 'true' ? props.bgcolor || 'rgb(136, 183, 206)' : props.fgcolor || 'white'};
  }
  .navbar-nav {
    .nav-link {
      color: ${props => (props.bshrink === 'true' ? props.fgcolor1 : props.fgcolor)};
      font-size: ${props => `${props.fontSize}px` || '16px'} !important;
      font-weight: ${props => props.fontWeight || '500'} !important;
      strong {
        color: ${props => props.hlcolor || 'white'};
      }
    }
    .nav-link:focus {
      color: ${props =>
        props.bshrink === 'true'
          ? props.bgcolor || 'rgb(136, 183, 206)'
          : props.fgcolor || 'white'};
    }
    .nav-link:hover {
      color: ${props => props.hlcolor || 'white'};
    }
    .nav-link::after {
      background: ${props => props.hlcolor || 'white'};
    }
  }
  .navbar-contact-phone {
    color: black;
  }
`

class Menubar extends Component {
  constructor(props) {
    super(props)
    this.state = {
      bToggle: false,
      bShrink: false,
      bMobile: false,
    }
    this.resizeHeaderOnScroll = this.resizeHeaderOnScroll.bind(this)
    this.updateWindowDimensions = this.updateWindowDimensions.bind(this)
  }

  componentDidMount() {
    window.addEventListener('scroll', this.resizeHeaderOnScroll)
    window.addEventListener('resize', this.updateWindowDimensions)
    this.updateWindowDimensions()
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.updateWindowDimensions)
  }

  handleToggle = bToggle => {
    this.setState({ bToggle })
  }

  handleClickMenu = link => {
    const { history } = this.props
    history.push(link)
    this.setState({ bToggle: false })
  }

  updateWindowDimensions = () => {
    const { bToggle, bMobile } = this.state
    if (window.innerWidth < 576) {
      if (!bMobile) this.setState({ bMobile: true })
    } else if (bMobile) {
      this.setState({ bMobile: false })
    }
    if (window.innerWidth > 991 && bToggle === true) {
      this.setState({ bToggle: false })
    }
  }

  resizeHeaderOnScroll = () => {
    const distanceY = window.pageYOffset || document.documentElement.scrollTop
    const shrinkOn = 59
    const navbar = document.querySelector('.navbar')
    const { bShrink } = this.state

    if (!navbar) return
    if (distanceY > shrinkOn) {
      if (!bShrink) this.setState({ bShrink: true })
    } else if (bShrink) this.setState({ bShrink: false })
  }

  render() {
    const { menus, data, style: orgStyle, generic, organizationInfo } = this.props
    const { history: currentRoute, toggleSubscribe } = this.props
    const { bToggle, bShrink, bMobile } = this.state
    if (_.get(data, 'bActive') === false) return ''

    // const miniLogo = _.get(generic, 'header.miniLogo')
    // const phone = _.get(generic, 'contact.phone')
    // const email = _.get(generic, 'contact.email')
    const minilogo = _.get(organizationInfo, 'avatar')
    const phone = _.get(organizationInfo, 'phone')
    const email = _.get(organizationInfo, 'email')

    const style = objectAssignDeep({ ...DEFAULT_STYLE }, orgStyle)
    console.log('style----------',style)
    return (
      <OeNavbar
        className="navbar-container"
        collapseOnSelect
        expand="sm"
        expanded={bToggle}
        onToggle={this.handleToggle}
        fontSize={_.get(style, 'title.fg.size')}
        fontWeight={_.get(style, 'title.fg.weight')}
        bgcolor={_.get(style, 'title.bg.color')}
        fgcolor={_.get(style, 'title.fg.color')}
        bgcolor1={_.get(style, 'bg_color')}
        fgcolor1={_.get(style, 'fg_color')}
        hlcolor={_.get(style, 'hl_color')}
        bshrink={bShrink ? 'true' : 'false'}
      >
        <div className="container">
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          {bMobile || bShrink ? (
            <Navbar.Brand onClick={() => this.handleClickMenu('')}>
              {miniLogo && <img className="navbar-brand-white" src={miniLogo.url} alt="white" />}
              {miniLogo && <img className="navbar-brand-black" src={miniLogo.url} alt="black" />}
            </Navbar.Brand>
          ) : (
            ''
          )}
          {bMobile && phone ? (
            <a href={`tel:${phone}`} className="navbar-contact-phone">
              <img src="/images/phone.png" alt="phone" />
            </a>
          ) : (
            ''
          )}
          {bMobile && email ? (
            <a href={`mailto:${email}`} className="navbar-contact-email">
              <img src="/images/mail.png" alt="email" />
            </a>
          ) : (
            ''
          )}
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="ml-auto mr-auto">
              {menus.map((menu, index) => {
                if (currentRoute.location.pathname === `/${menu.link}`) {
                  return (
                    <Nav.Link key={index} onClick={() => this.handleClickMenu(menu.link)}>
                      <strong>{menu.label}</strong>
                    </Nav.Link>
                  )
                }

                return (
                  <Nav.Link key={index} onClick={() => this.handleClickMenu(menu.link)}>
                    {menu.label}
                  </Nav.Link>
                )
              })}
              {/* <Button onClick={() => toggleSubscribe(true, 'Events')}>Subscribe</Button> */}
            </Nav>
          </Navbar.Collapse>
          {!bMobile && phone ? (
            <a href={`tel:${phone}`} className="navbar-contact-phone">
              <img src="/images/phone.png" alt="phone" />
              {/* <span>{phone}</span> */}
            </a>
          ) : (
            ''
          )}
          {!bMobile && email ? (
            <a href={`mailto:${email}`} className="navbar-contact-email">
              <img src="/images/mail.png" alt="mail" />
            </a>
          ) : (
            ''
          )}
        </div>
      </OeNavbar>
    )
  }
}

Menubar.propTypes = {}

Menubar.defaultProps = {}

export default withRouter(Menubar)
