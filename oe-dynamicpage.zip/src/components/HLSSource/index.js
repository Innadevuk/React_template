import React, { Component } from 'react'
import Hls from 'hls.js'

export default class HLSSource extends Component {
  constructor(props, context) {
    super(props, context)
    this.hls = new Hls()
  }

  componentDidMount() {
    // `src` is the property get from this component
    // `video` is the property insert from `Video` component
    // `video` is the html5 video element
    const { src, video, autoPlay } = this.props
    // load hls video source base on hls.js
    if (Hls.isSupported()) {
      this.hls.loadSource(src)
      this.hls.attachMedia(video)
      this.hls.on('timeupdate', () => {
        console.log('timeupdate')
      })
      this.hls.on(Hls.Events.MANIFEST_PARSED, () => {
        if (autoPlay) video.play()
        // video.play()
      })
    }
  }

  componentWillReceiveProps(nextProps) {
    const { src } = this.props
    if (src !== nextProps.src) {
      if (Hls.isSupported()) {
        this.hls.destroy()
        this.hls = new Hls()
        this.hls.loadSource(nextProps.src)
        this.hls.attachMedia(nextProps.video)
        this.hls.on(Hls.Events.MANIFEST_PARSED, () => {
          if (nextProps.autoPlay) nextProps.video.play()
        })
      }
    }
  }

  componentWillUnmount() {
    // destroy hls video source
    if (this.hls) {
      this.hls.destroy()
    }
  }

  render() {
    const { src, type } = this.props
    return <source src={src} type={type || 'application/x-mpegURL'} />
  }
}
