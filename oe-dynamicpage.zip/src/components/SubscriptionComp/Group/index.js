import React from 'react'
import { Form } from 'react-bootstrap'

const GroupRow = ({ group, smss, emails, phones, onChangeInput }) => {
  const icon = group?.data?.desc?.icon
  const title = group?.data?.desc?.title
  const bSMS = smss[group?._id] ? true : false
  const bPhone = phones[group?._id] ? true : false
  const bEmail = emails[group?._id] ? true : false

  return (
    <div className="oe-subscription-comp-group-row">
      {icon ? <img className="icon" src={icon} alt="icon" /> : <span className="icon" />}
      <Form.Check
        type="checkbox"
        label={<img src="/images/sms.png" alt="sms" />}
        name="SMS"
        className="bSMS"
        id={`${group._id}_sms`}
        checked={bSMS}
        onChange={e => onChangeInput(group?._id, 'sms', e.target.checked)}
      />
      <Form.Check
        type="checkbox"
        label={<img src="/images/phone1.png" alt="phone" />}
        name="Phone"
        className="bPhone"
        id={`${group._id}_phone`}
        checked={bPhone}
        onChange={e => onChangeInput(group?._id, 'phone', e.target.checked)}
      />
      <Form.Check
        type="checkbox"
        label={<img src="/images/mail1.png" alt="mail" />}
        name="Email"
        className="bEmail"
        id={`${group._id}_email`}
        checked={bEmail}
        onChange={e => onChangeInput(group?._id, 'email', e.target.checked)}
      />
      <span className="title">{title}</span>
    </div>
  )
}

export default GroupRow
