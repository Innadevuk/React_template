import React, { useState } from 'react'
import { useMutation, useQuery } from '@apollo/react-hooks'
import * as mutations from 'utils/mutations'
import * as queries from 'utils/queries'
import { withApollo } from 'react-apollo'
import { Button, Spinner, Form, InputGroup } from 'react-bootstrap'
import _ from 'lodash'
import GroupType from './GroupType'
import './index.scss'

const SubscriptionComp = ({ clientInfo, myGeo, client }) => {
  const groupTypeOptions = _.get(clientInfo, 'data.appInfo.groupType.options') || []
  const [smss, setSMSs] = useState({})
  const [phones, setPhones] = useState({})
  const [emails, setEmails] = useState({})
  const [upsertPhoneNumber] = useMutation(mutations.upsertPhoneNumber)
  const [deletePhoneNumber] = useMutation(mutations.deletePhoneNumber)
  const [loading, setLoading] = useState(false)
  const [phone, setPhone] = useState('')

  const { loading: loadingGroups, error: errorGroups, data } = useQuery(queries.groupingQuery, {
    variables: {
      ids: null,
      clientId: clientInfo?._id,
    },
  })

  const onChangeInput = (groupId, field, status) => {
    if (field === 'sms') setSMSs({ ...smss, [groupId]: status })
    if (field === 'phone') setPhones({ ...phones, [groupId]: status })
    if (field === 'email') setEmails({ ...emails, [groupId]: status })
  }

  const processPhone = (groupIds, smss, phone) => {
    return new Promise((resolve, reject) => {
      const promises = []

      groupIds.map(groupId => {
        if (smss[groupId]) {
          promises.push(
            upsertPhoneNumber({
              variables: {
                _id: groupId,
                collectionName: 'Groupings',
                phoneNumber: phone,
              },
            }),
          )
        } else {
          promises.push(
            deletePhoneNumber({
              variables: {
                _id: groupId,
                collectionName: 'Groupings',
                phoneNumber: phone,
              },
            }),
          )
        }
      })

      Promise.all(promises)
        .then(res => resolve(res))
        .catch(err => reject(err))
    })
  }

  const onSubscribe = () => {
    setLoading(true)
    const { grouping } = data
    const groupIds = grouping.map(group => group._id)
    processPhone(groupIds, smss, phone)
      .then(res => {
        console.log(res)
        setLoading(false)
      })
      .catch(err => {
        console.log(err)
        setLoading(false)
      })
      .finally(() => {
        setLoading(false)
      })
  }

  const onGo = () => {
    // client
    //   .query({
    //     query: queries.phoneNumbersQuery,
    //     variables: {
    //       ids: []
    //     },
    //     fetchPolicy: 'no-cache',
    //   })
    //   .then(res => {
    //     console.log(res)
    //   })
    //   .catch(err => {
    //     console.log(err)
    //   })
    //   .finally(() => {
    //     setPublishing(false)
    //     showPublishModal(false)
    //   })
  }

  return (
    <div className="oe-subscription-comp">
      <div className="oe-subscription-comp-phone">
        <label>Phone Number :</label>
        <InputGroup className="input-phone-number">
          <Form.Control value={phone} onChange={e => setPhone(e.target.value)} />
          <InputGroup.Append>
            <Button variant="outline-secondary" onClick={onGo}>
              Go
            </Button>
          </InputGroup.Append>
        </InputGroup>
      </div>
      {groupTypeOptions.map((groupType, index) => {
        let groups = []
        if (!loadingGroups && !errorGroups) {
          const { grouping } = data
          groups = grouping.filter(group => group.type === groupType)
          console.log(groups)
        }

        return (
          <GroupType
            groupType={groupType}
            groups={groups}
            loading={loadingGroups || errorGroups}
            key={index}
            myGeo={myGeo}
            smss={smss}
            phones={phones}
            emails={emails}
            onChangeInput={onChangeInput}
          />
        )
      })}
      <div className="oe-subscription-comp-footer">
        <Button
          variant="primary"
          type="submit"
          onClick={onSubscribe}
          disabled={loading || loadingGroups}
        >
          {loading ||
            (loadingGroups && (
              <>
                <Spinner animation="border" size="sm" />
                &nbsp;
              </>
            ))}
          Update Subscription
        </Button>
      </div>
    </div>
  )
}

export default withApollo(SubscriptionComp)
