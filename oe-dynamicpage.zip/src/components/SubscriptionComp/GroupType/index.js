import React, { useState } from 'react'
import * as queries from 'utils/queries'
import { useQuery } from '@apollo/react-hooks'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faAngleUp, faAngleDown } from '@fortawesome/free-solid-svg-icons'
import { Accordion, Card, useAccordionToggle, Spinner } from 'react-bootstrap'
import FilterGroup from 'listeners/FilterGroup'
import GroupRow from '../Group'

const GroupType = ({ groupType, groups, loading, myGeo, smss, emails, phones, onChangeInput }) => {
  const [isOpen, setOpen] = useState(true)

  const CustomToggle = ({ eventKey }) => {
    const decoratedOnClick = useAccordionToggle(eventKey, () => {
      setOpen(!isOpen)
    })
    const toggleEvent = event => {
      event.preventDefault()
      event.stopPropagation()
      decoratedOnClick()
    }

    return (
      <Card.Header onClick={decoratedOnClick}>
        <div className="oe-subscription-comp-accordion-header">
          <span className="oe-subscription-comp-accordion-action">
            {isOpen ? (
              <FontAwesomeIcon
                onClick={e => toggleEvent(e, 'Articles')}
                className="arrow"
                icon={faAngleUp}
                size="lg"
              />
            ) : (
              <FontAwesomeIcon
                onClick={e => toggleEvent(e, 'Articles')}
                className="arrow"
                icon={faAngleDown}
                size="lg"
              />
            )}
          </span>
          {groupType}
        </div>
      </Card.Header>
    )
  }

  if (loading) {
    return (
      <Accordion className="oe-subscription-comp-accordion" defaultActiveKey="0">
        <Card>
          <CustomToggle eventKey="0" />
          <Accordion.Collapse eventKey="0">
            <Card.Body>
              <Spinner animation="border" size="sm" />
            </Card.Body>
          </Accordion.Collapse>
        </Card>
      </Accordion>
    )
  }

  return (
    <Accordion className="oe-subscription-comp-accordion" defaultActiveKey="0">
      <Card>
        <CustomToggle eventKey="0" />
        <Accordion.Collapse eventKey="0">
          <Card.Body>
            {groups.map(group => (
              <FilterGroup key={group._id} groupId={group._id} myGeo={myGeo} filter={false}>
                <GroupRow
                  smss={smss}
                  phones={phones}
                  emails={emails}
                  onChangeInput={onChangeInput}
                />
              </FilterGroup>
            ))}
          </Card.Body>
        </Accordion.Collapse>
      </Card>
    </Accordion>
  )
}
export default GroupType
