import React from 'react'
import _ from 'lodash'
import './index.scss'

const Footer = ({ generic, data, style }) => {
  const footerText = _.get(data, 'text')
  const footerStyle = {
    backgroundColor: _.get(style, 'bg_color') || 'gray',
    color: _.get(style, 'fg_color') || 'white',
  }

  return (
    <>
      {footerText && (
        <section className="oe-dynamicpage-footer" style={footerStyle}>
          <div className="container">
            <span>{footerText}</span>
          </div>
          {/* <Container>
            <Row>
              <Col md="3">
                Browse Our Website
              </Col>
              <Col md="5">
                Contact Information
              </Col>
              <Col md="4">
                Contact Us
              </Col>
            </Row>
          </Container> */}
        </section>
      )}
    </>
  )
}

export default Footer
