/* eslint-disable no-nested-ternary */
import React from 'react'
import { withRouter } from 'react-router-dom'
import { graphql, withApollo } from 'react-apollo'
import * as compose from 'lodash.flowright'
import * as mutations from 'utils/mutations'
import { Button, Modal, Form, Row, Col, Spinner } from 'react-bootstrap'
import { Formik, FieldArray } from 'formik'
import * as queries from 'utils/queries'
import { useQuery } from '@apollo/react-hooks'
import * as yup from 'yup'
import _ from 'lodash'
import axios from 'axios'
import toastr from 'toastr'
import { EMAIL_NOW_API_URL } from 'utils/constants'
import './index.scss'

const toastrOptions = {
  closeButton: true,
  debug: false,
  newestOnTop: true,
  progressBar: true,
  positionClass: 'toast-top-right',
  preventDuplicates: false,
  onclick: null,
  showDuration: '300',
  hideDuration: '1000',
  timeOut: '5000',
  extendedTimeOut: '1000',
  showEasing: 'swing',
  hideEasing: 'linear',
  showMethod: 'fadeIn',
  hideMethod: 'fadeOut',
}

const schema = yup.object({
  bEmail: yup.bool(),
  email: yup
    .string()
    .email('Please input the valid email address')
    .when('bEmail', { is: true, then: yup.string().required('Email is required.') }),
  bSMS: yup.bool(),
  phone: yup.string().when('bSMS', { is: true, then: yup.string().required('Phone number is required.') }),
})

const generateHTML = (generic, groups, selectedIds, alert) => {
  let html = `<p>${_.get(generic, 'subscribe.desc') || ''}</p>`
  if (alert) html += `<p>${alert}</p>`
  else {
    html += '<ul>'
    for (let i = 0; i < groups.length; i += 1) {
      const group = groups[i]
      if (selectedIds.includes(group._id)) {
        html += `<li>${_.get(group, 'data.desc.title')}</li>`
      }
    }
    html += '</ul>'
  }

  return html
}

const SubscribeModal = ({ show, toggleModal, generic, clientInfo, upsertEmail, upsertPhoneNumber, groupType }) => {
  const miniLogo = _.get(generic, 'header.miniLogo')
  const { loading, error, data } = useQuery(queries.groupingQuery, {
    variables: {
      ids: null,
      clientId: clientInfo._id,
      type: groupType,
    },
  })

  let alert = null
  const groups = []

  if (loading) alert = 'Loading...'
  else if (error || !data || !data.grouping) alert = 'Something went wrong</p>'
  else {
    data.grouping.forEach(group => {
      const bAvailability = _.get(group, 'availability.state') === 'on'
      if (bAvailability) groups.push(group)
    })
  }

  if (groups.length === 0) alert = 'No Groups'

  const processEmail = (bEmail, selectedIds, email) => {
    return new Promise((resolve, reject) => {
      const html = generateHTML(generic, groups, selectedIds, alert)

      const body = [
        {
          emailTo: [email],
          subject: 'Thank you for subscribing our service!',
          text: 'Subscribe Description',
          html,
        },
      ]

      axios
        .post(EMAIL_NOW_API_URL, body, {
          headers: {
            'Content-Type': 'application/json',
          },
        })
        .then(response => {
          toastr.success('Success to send a Subscription Email!', toastrOptions)

          const promises = []

          for (const group of groups) {
            const { _id, collectionName } = group
            if (selectedIds.includes(_id)) {
              promises.push(
                upsertEmail({
                  variables: {
                    _id,
                    collectionName,
                    email,
                  },
                }),
              )
            }
          }

          Promise.all(promises)
            .then(res => resolve(res))
            .catch(err => reject(err))
        })
        .catch(err => {
          toastr.error('Failed to send a Subscription Email!', toastrOptions)
          reject(err)
        })
    })
  }

  const processPhone = (bSMS, selectedIds, phone) => {
    return new Promise((resolve, reject) => {
      const promises = []

      for (const group of groups) {
        const { _id, collectionName } = group
        if (selectedIds.includes(_id)) {
          promises.push(
            upsertPhoneNumber({
              variables: {
                _id,
                collectionName,
                phoneNumber: phone,
              },
            }),
          )
        }
      }

      Promise.all(promises)
        .then(res => resolve(res))
        .catch(err => reject(err))
    })
  }

  return (
    <Formik
      initialValues={{
        selectedIds: [],
        bEmail: false,
        email: '',
        bSMS: false,
        phone: '',
      }}
      validationSchema={schema}
      onSubmit={(values, actions) => {
        const { bEmail, bSMS, email, phone, selectedIds } = values
        if (!bEmail && !bSMS && selectedIds.length === 0) {
          actions.setSubmitting(false)

          return
        }

        actions.setSubmitting(true)

        const promises = []
        if (bEmail) {
          promises.push(processEmail(bEmail, selectedIds, email))
        }

        if (bSMS) {
          promises.push(processPhone(bSMS, selectedIds, phone))
        }

        Promise.all(promises)
          .then(res => {
            console.log(res)
          })
          .catch(err => {
            console.log(err)
          })
          .finally(() => {
            actions.setSubmitting(false)
            toggleModal(false)
          })
      }}
    >
      {({ values, errors, handleChange, touched, resetForm, handleSubmit, isSubmitting }) => (
        <Form noValidate>
          <Modal show={show} onHide={toggleModal} className="oe-subscribe">
            <Modal.Header closeButton>
              <Modal.Title>{miniLogo && <img src={miniLogo} alt="miniLogo" />}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <div className="oe-subscribe-events">
                <p>{_.get(generic, 'subscribe.desc')}</p>
                {alert ? (
                  <p>{alert}</p>
                ) : (
                  <Form.Group as={Col}>
                    <FieldArray
                      name="selectedIds"
                      render={arrayHelpers =>
                        groups.map(group => (
                          <Form.Check
                            key={group._id}
                            type="checkbox"
                            label={_.get(group, 'data.desc.title')}
                            name="eventGroups"
                            id={`eventGroup-${group._id}`}
                            value={group._id}
                            checked={values.selectedIds.includes(group._id)}
                            onChange={e => {
                              console.log(arrayHelpers)
                              if (e.target.checked) arrayHelpers.push(group._id)
                              else {
                                const idx = values.selectedIds.indexOf(group._id)
                                arrayHelpers.remove(idx)
                              }
                            }}
                          />
                        ))
                      }
                    />
                  </Form.Group>
                )}
              </div>
              <div className="oe-subscribe-notification">
                <span>Notification:</span>
                <div className="oe-subscribe-notification-body">
                  <div className="inline-check-input">
                    <Form.Check
                      type="checkbox"
                      label="Email:"
                      id="bEmail"
                      inline
                      onChange={handleChange}
                      checked={values.bEmail}
                      disabled={isSubmitting}
                    />
                    {values.bEmail && (
                      <>
                        <Form.Control
                          size="sm"
                          name="email"
                          type="email"
                          placeholder="Enter Email Address"
                          onChange={handleChange}
                          value={values.email}
                          isInvalid={touched.email && errors.email}
                          disabled={isSubmitting}
                        />
                        <Form.Control.Feedback type="invalid">
                          {errors.email}
                        </Form.Control.Feedback>
                      </>
                    )}
                  </div>
                  <div className="inline-check-input">
                    <Form.Check
                      type="checkbox"
                      label="Text:"
                      id="bSMS"
                      inline
                      onChange={handleChange}
                      checked={values.bSMS}
                      disabled={isSubmitting}
                    />
                    {values.bSMS && (
                      <>
                        <Form.Control
                          size="sm"
                          name="phone"
                          type="text"
                          placeholder="Enter Phone Number"
                          onChange={handleChange}
                          value={values.phone}
                          isInvalid={touched.phone && errors.phone}
                          disabled={isSubmitting}
                        />
                        <Form.Control.Feedback type="invalid">
                          {errors.phone}
                        </Form.Control.Feedback>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </Modal.Body>
            <Modal.Footer>
              <Button
                variant="secondary"
                onClick={() => {
                  resetForm()
                }}
                disabled={isSubmitting}
              >
                Clear
              </Button>
              <Button
                variant="primary"
                onClick={e => {
                  e.preventDefault()
                  handleSubmit()
                }}
                disabled={isSubmitting}
              >
                {isSubmitting && (
                  <>
                    <Spinner animation="border" size="sm" />
                    &nbsp;
                  </>
                )}
                Subscribe
              </Button>
            </Modal.Footer>
          </Modal>
        </Form>
      )}
    </Formik>
  )
}

export default compose(graphql(mutations.upsertEmail, { name: 'upsertEmail' }), graphql(mutations.upsertPhoneNumber, { name: 'upsertPhoneNumber' }), withApollo, withRouter)(SubscribeModal)
