/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React from 'react'
import _ from 'lodash'

import MediaViewGroupContainer from 'components/Shared/MediaViewGroup/Container'
import MediaViewGroupContentNormalBar from 'components/Shared/MediaViewGroup/Content/Normal/Bar'
import MediaViewGroupContentTopBarCarousel from 'components/Shared/MediaViewGroup/Content/Top/BarCarousel'
import MediaViewGroupContentTopBarStacked from 'components/Shared/MediaViewGroup/Content/Top/BarStacked'
import MediaViewGroupContentTopBarTextStacked from 'components/Shared/MediaViewGroup/Content/Top/BarTextStacked'
import GroupImageList from 'components/Shared/ImageList'
import GroupStreamList from 'components/Shared/GroupStreamList'
import GroupAdW300H250 from 'components/Shared/GroupAdW300H250'
import WidgetsBar from 'components/Shared/WidgetsBar'

import './index.scss'

const ContentGroup = React.forwardRef(({ group, myGeo, clientInfo }, ref) => {
  const layoutType = _.get(group, 'data.layout.type') || 'ArticlesStack'
  const params = { group, myGeo, layoutType }

  switch (layoutType) {
    case 'ArticlesCarousel':
      return (
        <MediaViewGroupContainer key={group._id} group={group} layoutType={layoutType} ref={ref}>
          <MediaViewGroupContentTopBarCarousel {...params} />
        </MediaViewGroupContainer>
      )
    case 'ArticlesStack':
      return (
        <MediaViewGroupContainer key={group._id} group={group} layoutType={layoutType} ref={ref}>
          <MediaViewGroupContentTopBarStacked {...params} />
        </MediaViewGroupContainer>
      )
    case 'ArticlesGrid':
      return (
        <>
          <WidgetsBar clientInfo={clientInfo} />
          <MediaViewGroupContainer key={group._id} group={group} layoutType={layoutType} ref={ref}>
            <MediaViewGroupContentNormalBar {...params} />
          </MediaViewGroupContainer>
        </>
      )
    case 'ArticleText':
      return (
        <MediaViewGroupContainer key={group._id} group={group} layoutType={layoutType} ref={ref}>
          <MediaViewGroupContentTopBarTextStacked {...params} />
        </MediaViewGroupContainer>
      )
    case 'ArticleThumbnail':
      return (
        <MediaViewGroupContainer key={group._id} group={group} layoutType={layoutType} ref={ref}>
          <MediaViewGroupContentTopBarStacked {...params} />
        </MediaViewGroupContainer>
      )
    case 'ImageList':
      return <GroupImageList key={group._id} group={group} ref={ref} />
    case 'group_ad_300_250':
      return <GroupAdW300H250 key={group._id} group={group} forwardedRef={ref} />
    case 'Video':
      return <GroupStreamList key={group._id} group={group} ref={ref} />
    default:
      break
  }

  return ''
})

ContentGroup.displayName = 'ContentGroup'
export default ContentGroup
