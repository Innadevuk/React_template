/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React, { createRef, useRef, useState } from 'react'
import { OverlayTrigger, Overlay, Popover } from 'react-bootstrap'
import _ from 'lodash'

import MediaViewGroupContainer from 'components/Shared/MediaViewGroup/Container'
import MediaViewGroupContentNormalBar from 'components/Shared/MediaViewGroup/Content/Normal/Bar'
import GroupLayoutC from 'components/Shared/GroupLayoutC'
import GroupAccordion from 'components/Shared/GroupAccordion'
import CompactList from 'components/Shared/CompactList'
import WidgetsBar from 'components/Shared/WidgetsBar'
import MenuStack from 'components/Shared/MenuStack'
import MenuMediaDesc from 'components/Shared/MenuMediaDesc'
import InactiveGroupsSelect from './InactiveGroupsSelect'
import './index.scss'

const DynamicNotifications = React.forwardRef(
  (
    {
      groups,
      inactiveGroups,
      myGeo,
      geoChecked,
      clientInfo,
      data,
      style,
      dismissable = true,
      groupType,
      toggleSubscribe,
      ignoreLocationFilter,
      setIgnoreLocationFilter,
    },
    ref,
  ) => {
    const refs = useRef([])

    const layoutType = _.get(data, 'layout.type') || 'List'
    const description = _.get(data, 'descr') || ''

    const [current, setCurrent] = useState(0)
    const [alert, setAlert] = useState(true)

    const prevActiveGroups = data?.prevActiveGroups
    const showPrevActiveGroups = prevActiveGroups?.show

    if (refs.current.length !== groups.length) {
      refs.current = Array(groups.length)
        .fill()
        .map((_, i) => refs.current[i] || createRef())
    }

    const renderTooltip = ({ show }, name, ref) => (
      <Overlay show={show} target={ref} placement="top" container={ref.current}>
        <Popover placement="top">
          <Popover.Content>
            <div dangerouslySetInnerHTML={{ __html: name }} />
          </Popover.Content>
        </Popover>
      </Overlay>
    )

    const currentDoc = groups[current]
    const articles = []

    if (currentDoc && currentDoc.contentIds) {
      currentDoc.contentIds.forEach(id => {
        const contentIndex = currentDoc.content.findIndex(article => article._id === id)
        if (contentIndex >= 0) articles.push(currentDoc.content[contentIndex])
      })
    }

    let groupComponent = ''
    if (groups && groups.length) {
      switch (layoutType) {
        case 'Grid':
          groupComponent = (
            <>
              {groups.map(group => (
                <MediaViewGroupContainer
                  key={group._id}
                  group={group}
                  layoutType="ArticlesGrid"
                  ref={ref}
                >
                  <MediaViewGroupContentNormalBar
                    group={group}
                    myGeo={myGeo}
                    layoutType="ArticlesGrid"
                  />
                </MediaViewGroupContainer>
              ))}
            </>
          )
          break
        case 'Menu Stack':
          groupComponent = <MenuStack groups={groups} myGeo={myGeo} data={data} style={style} />
          break
        case 'Menu-Media-Desc':
          groupComponent = <MenuMediaDesc groups={groups} myGeo={myGeo} data={data} style={style} />
          break
        case 'Menu':
          groupComponent = (
            <>
              {groups && groups.length > 1 && (
                <div className="oe-dynamic-notifications-body-bar">
                  {groups.map((group, index) => {
                    const tooltipText = _.get(group, 'data.tooltip.text') || ''
                    let renderItem
                    if (tooltipText === '') {
                      renderItem = (
                        <div
                          key={index}
                          ref={refs.current[index]}
                          className="oe-dynamic-notifications-body-bar-item"
                          style={{
                            backgroundColor: _.get(group, 'style.title.bg_color') || 'gray',
                            borderRadius: _.get(group, 'style.outline.radius'),
                          }}
                          onClick={() => setCurrent(index)}
                        />
                      )
                    } else {
                      renderItem = (
                        <OverlayTrigger
                          placement="top"
                          delay={{ show: 250, hide: 250 }}
                          overlay={props =>
                            renderTooltip(props, tooltipText || '', refs.current[index])
                          }
                          key={group._id}
                        >
                          <div
                            id={index}
                            ref={refs.current[index]}
                            className="oe-dynamic-notifications-body-bar-item"
                            style={{
                              backgroundColor: _.get(group, 'style.title.bg_color') || 'gray',
                              borderRadius: _.get(group, 'style.outline.radius'),
                            }}
                            onClick={() => setCurrent(index)}
                          />
                        </OverlayTrigger>
                      )
                    }

                    return renderItem
                  })}
                </div>
              )}
              {currentDoc && (
                <>
                  <GroupLayoutC
                    group={currentDoc}
                    myGeo={myGeo}
                    onDismissAlert={() => setAlert(false)}
                    dismissable={dismissable}
                    data={data}
                    style={style}
                  />
                </>
              )}
            </>
          )
          break
        case 'Stacked':
          groupComponent = (
            <>
              {groups &&
                groups.length > 0 &&
                groups.map((group, index) => (
                  <div key={index} className="oe-dynamic-notifications-body-group">
                    <GroupLayoutC
                      group={group}
                      myGeo={myGeo}
                      key={index}
                      onDismissAlert={() => setAlert(false)}
                      dismissable={dismissable}
                      data={data}
                      style={style}
                    />
                  </div>
                ))}
            </>
          )
          break
        case 'List':
          if (!groups || !groups.length) break
          groupComponent = (
            <GroupAccordion groups={groups} myGeo={myGeo} data={data} style={style} />
          )

          break
        case 'CompactList':
          if (!groups || !groups.length) break
          groupComponent = <CompactList groups={groups} myGeo={myGeo} data={data} style={style} />
          break
        default:
          break
      }
    }

    return (
      <>
        {alert && (
          <div className="oe-dynamic-notifications">
            <div className="oe-dynamic-notifications-body">
              <WidgetsBar clientInfo={clientInfo} groupType={groupType} data={data} />
              {/* {['Areas', 'SubAreas'].includes(groupType) && (
              <div className="oe-dynamic-notifications-body-specific">
                <div
                  className="oe-dynamic-notifications-body-specific-text"
                  dangerouslySetInnerHTML={{ __html: description }}
                />
                <div className="input-fields">
                  <Form.Check
                    type="checkbox"
                    label="My Location"
                    name="toggleLocationFilter"
                    id={`toggleLocationFilter_${groupType}`}
                    checked={!ignoreLocationFilter}
                    onChange={e => {
                      if (e.target.checked) setIgnoreLocationFilter(false)
                      else setIgnoreLocationFilter(true)
                    }}
                  />
                  <Button onClick={() => toggleSubscribe(true, groupType)}>Subscribe</Button>
                </div>
              </div>
            )} */}
              {groupComponent}
              {showPrevActiveGroups && (
                <div className="oe-dynamic-notifications-body-inactive">
                  <InactiveGroupsSelect groups={inactiveGroups} data={prevActiveGroups} />
                </div>
              )}
            </div>
          </div>
        )}
      </>
    )
  },
)

DynamicNotifications.displayName = 'DynamicNotifications'
export default DynamicNotifications
