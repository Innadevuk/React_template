import React from 'react'
import { Form, Row, Col } from 'react-bootstrap'
import moment from 'moment'

const InactiveGroupsDropdown = ({ groups, data }) => {
  const duration = data?.duration || 0
  const label = data?.label || ''

  const now = moment().utc()

  const validGroups = groups.filter(group => {
    const { availability } = group
    const availableAt = availability?.availableAt
    const diff = moment.duration(now.diff(moment(availableAt).utc()))
    const seconds = diff.asSeconds()
    // console.log(now, availableAt, seconds, duration)

    return seconds < duration
  })

  return (
    <Form inline>
      <Form.Group as={Row} style={{ marginLeft: 'auto' }}>
        <Form.Label>{label}</Form.Label>
        <Form.Control as="select">
          {validGroups.map(group => (
            <option key={group._id} value={group._id}>
              {group.name}
            </option>
          ))}
        </Form.Control>
      </Form.Group>
    </Form>
  )
}

export default InactiveGroupsDropdown
