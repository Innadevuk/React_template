import React from 'react'
import _ from 'lodash'
import { Container, Row, Col, Form, Button } from 'react-bootstrap'
import './index.scss'

const Contactus = ({ generic, data, style }) => {
  // const bActive = _.get(data, 'bActive')

  // if (bActive === false) {
  //   return ''
  // }

  const phone = _.get(generic, 'contact.phone')
  const email = _.get(generic, 'contact.email')
  const address = _.get(generic, 'contact.address')
  const displayName = _.get(generic, 'header.displayName')
  const hours = _.get(generic, 'contact.hours')

  const links = _.get(generic, 'links')

  return (
    <section className="oe-dynamicpage-contactus">
      <Container>
        <Row>
          <Col md="3">
            <div className="oe-dynamicpage-contactus-header">
              <span>Contact Information</span>
            </div>
            <span className="oe-dynamicpage-contactus-info">
              {displayName ? (
                <div>
                  <strong>3-Rivers Drilling & Blasting</strong>
                  <br />
                </div>
              ) : (
                ''
              )}
              <strong>Tel:&nbsp;</strong>
              <a href="tel:4358656980">{phone}</a>
              <br />
              <strong>Email:&nbsp;</strong>
              <a href="mailto:3rivers@infowest.com">{email}</a>
              <br />
              {hours ? (
                <div>
                  <strong>Hours of Operation:</strong>
                  <br />
                  {hours}
                </div>
              ) : (
                ''
              )}
              {address ? (
                <div>
                  <strong>Address:</strong>
                  <br />
                  {address}
                </div>
              ) : (
                ''
              )}
            </span>
          </Col>
          <Col md="5">
            <div className="oe-dynamicpage-contactus-header">
              <span>Contact Us</span>
            </div>
            <Form>
              <Form.Control placeholder="* Name" required />
              <Form.Control placeholder="* Phone" required />
              <Form.Control type="email" placeholder="* Email" required />
              <Form.Control placeholder="Best Time to Call" />
              <Form.Control as="textarea" rows="3" placeholder="Comments" />
              <Button variant="primary" type="submit">
                Submit
              </Button>
            </Form>
          </Col>
          <Col md="4">
            <div className="oe-dynamicpage-contactus-header">
              <span>Connect with us</span>
            </div>
            <div className="oe-dynamicpage-contactus-connects">
              {links &&
                links.map((link, index) => (
                  <a
                    key={index}
                    href={link.url}
                    role="button"
                    style={{ background: `url(${link.icon})` }}
                  >
                    <span />
                  </a>
                ))}
            </div>
          </Col>
        </Row>
      </Container>
    </section>
  )
}

export default Contactus
