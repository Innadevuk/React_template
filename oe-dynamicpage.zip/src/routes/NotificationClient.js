import React, { Component } from 'react'
import { graphql, withApollo } from 'react-apollo'
import * as compose from 'lodash.flowright'
import * as queries from 'utils/queries'
import { groupingUpdate, articleUpdate, groupingAdd, documentDelete } from 'utils/subscriptions'
import DynamicNotifications from 'components/DynamicNotifications'

import FilterGroups from 'listeners/FilterGroups'

class Client extends Component {
  constructor(props) {
    super(props)
    this.state = {
      subscription: null,
      articleSubscription: null,
      ignoreLocationFilter: true,
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (!prevState.subscription && !nextProps.groupingQuery.loading) {
      return {
        subscription: [
          nextProps.groupingQuery.subscribeToMore({
            document: groupingUpdate,
            updateQuery: (previousResult, { subscriptionData }) => {
              if (
                !subscriptionData.data ||
                !subscriptionData.data.groupingUpdate ||
                !previousResult ||
                !previousResult.grouping ||
                subscriptionData.data.groupingUpdate.clientId !== nextProps.clientInfo._id ||
                subscriptionData.data.groupingUpdate.type !== nextProps.groupType
              ) {
                return previousResult
              }
              const updatedIndex = previousResult.grouping.findIndex(
                group => group._id === subscriptionData.data.groupingUpdate._id,
              )
              if (updatedIndex >= 0) {
                // return Object.assign({}, previousResult, {
                //   grouping: [...previousResult.grouping.slice(0, updatedIndex), subscriptionData.data.groupingUpdate, ...previousResult.grouping.slice(updatedIndex + 1)],
                // })
                return {
                  ...previousResult,
                  grouping: [
                    ...previousResult.grouping.slice(0, updatedIndex),
                    subscriptionData.data.groupingUpdate,
                    ...previousResult.grouping.slice(updatedIndex + 1),
                  ],
                }
              }

              // return Object.assign({}, previousResult, { grouping: [...previousResult.grouping, subscriptionData.data.groupingUpdate] })
              return {
                ...previousResult,
                grouping: [...previousResult.grouping, subscriptionData.data.groupingUpdate],
              }
            },
          }),
          nextProps.groupingQuery.subscribeToMore({
            document: groupingAdd,
            updateQuery: (previousResult, { subscriptionData }) => {
              if (
                !subscriptionData.data ||
                !subscriptionData.data.groupingAdd ||
                !previousResult ||
                !previousResult.grouping ||
                subscriptionData.data.groupingAdd.clientId !== nextProps.clientInfo._id ||
                subscriptionData.data.groupingAdd.type !== nextProps.groupType
              ) {
                return previousResult
              }
              const updatedIndex = previousResult.grouping.findIndex(
                group => group._id === subscriptionData.data.groupingAdd._id,
              )
              if (updatedIndex >= 0) return previousResult

              // return Object.assign({}, previousResult, { grouping: [...previousResult.grouping, subscriptionData.data.groupingAdd] })
              return {
                ...previousResult,
                grouping: [...previousResult.grouping, subscriptionData.data.groupingAdd],
              }
            },
          }),
          nextProps.groupingQuery.subscribeToMore({
            document: documentDelete,
            updateQuery: (previousResult, { subscriptionData }) => {
              if (
                !previousResult ||
                !previousResult.grouping ||
                !subscriptionData.data ||
                !subscriptionData.data.documentDelete
              ) {
                return previousResult
              }

              const { grouping } = previousResult

              const deleteIndex = grouping.findIndex(
                group =>
                  group._id === subscriptionData.data.documentDelete._id &&
                  group.collectionName === subscriptionData.data.documentDelete.collectionName,
              )
              if (deleteIndex < 0) return previousResult

              // return Object.assign({}, previousResult, { grouping: [...grouping.slice(0, deleteIndex), ...grouping.slice(deleteIndex + 1)] })
              return {
                ...previousResult,
                grouping: [...grouping.slice(0, deleteIndex), ...grouping.slice(deleteIndex + 1)],
              }
            },
          }),
        ],
      }
    }
    if (!prevState.articleSubscription && !nextProps.eventQuery.loading) {
      return {
        articleSubscription: nextProps.eventQuery.subscribeToMore({
          document: articleUpdate,
          updateQuery: (previousResult, { subscriptionData }) => {
            if (!subscriptionData.data) return previousResult

            return previousResult
          },
        }),
      }
    }

    return null
  }

  setIgnoreLocationFilter = ignoreLocationFilter => {
    const { connectGeolocation } = this.props
    if (!ignoreLocationFilter) {
      connectGeolocation()
    }
    this.setState({ ignoreLocationFilter })
  }

  render() {
    const {
      data,
      style,
      groupingQuery: { loading, error, grouping: groups },
      clientInfo,
      myGeo,
      geoChecked,
      dismissable,
      groupType,
      toggleSubscribe,
    } = this.props

    const { ignoreLocationFilter } = this.state

    // const { bActive } = data

    // if (!bActive) {
    //   return ''
    // }

    // if (!myGeo || loading || error) {
    if (loading || error) {
      return ''
    }

    if (!groups || !groups.length) {
      return ''
    }

    return (
      <FilterGroups groups={groups} myGeo={myGeo} ignoreLocationFilter={!geoChecked}>
        <DynamicNotifications
          clientInfo={clientInfo}
          data={data}
          style={style}
          dismissable={dismissable}
          groupType={groupType}
          toggleSubscribe={toggleSubscribe}
          // ignoreLocationFilter={ignoreLocationFilter}
          // setIgnoreLocationFilter={this.setIgnoreLocationFilter}
        />
      </FilterGroups>
    )
  }
}

export default compose(
  graphql(queries.groupingQuery, {
    name: 'groupingQuery',
    options: ({ clientInfo, groupType }) => ({
      variables: {
        ids: null,
        clientId: clientInfo._id,
        type: groupType,
      },
    }),
  }),
  graphql(queries.eventQuery, {
    name: 'eventQuery',
    options: () => ({
      variables: {
        collectionName: 'Articles',
      },
    }),
  }),
  withApollo,
)(Client)
