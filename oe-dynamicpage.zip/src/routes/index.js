import React, { Component } from 'react'
import { graphql, withApollo } from 'react-apollo'
import { Route, Switch, Router, Redirect } from 'react-router-dom'
import _ from 'lodash'
import ReactLoading from 'react-loading'
import Geocode from 'react-geocode'
import * as compose from 'lodash.flowright'
import { Toast } from 'react-bootstrap'

import * as queries from 'utils/queries'
import { dataUpdate } from 'utils/subscriptions'
import Menubar from 'components/Menubar'
import { DEV_CLIENT } from 'utils/constants'
import SubscribeModal from 'components/Subscribe'
// import AdBar from 'components/Adbar'
import PageLayout from 'containers/PageLayout'
import ArticleDetail from 'containers/Article'
import GroupDetail from 'containers/Group'

import 'bootstrap/dist/css/bootstrap.min.css'
import 'video-react/dist/video-react.css'

Geocode.setApiKey('AIzaSyDQ6fOZioeYFWHF-Q02vErr8v7duPXywRA')
Geocode.setLanguage('en')
function getPosition(options) {
  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(resolve, reject, options)
  })
}

class Routes extends Component {
  constructor(props) {
    super(props)
    this.state = {
      myGeo: null,
      subscription: null,
      showSubscribe: false,
      geoChecked: false,
      geoChecking: false,
      showPrompt: false,
      subscribeGroupType: 'Events',
    }
  }

  componentWillReceiveProps(nextProps) {
    const {
      groupingQuery: { loading, grouping },
    } = this.props
    const {
      groupingQuery: { nextLoading, grouping: nextGrouping, subscribeToMore },
    } = nextProps
    const { geoChecked, geoChecking, subscription } = this.state

    if (!subscription && !nextLoading) {
      this.setState({
        subscription: subscribeToMore({
          document: dataUpdate,
          updateQuery: (previousResult, { subscriptionData }) => {
            if (!subscriptionData.data) return previousResult

            return previousResult
          },
        }),
      })
    }

    if (!geoChecked && !geoChecking && loading && !nextLoading && nextGrouping) {
      const rootFolders = _.get(nextGrouping, '0.data.ClientsData.data.folders')
      if (rootFolders) {
        const genericMenu = rootFolders.find(folder => folder.rootType === 'General')
        const geofilter = _.get(genericMenu, 'data.cfg.geofilter')

        if (geofilter) {
          this.connectGeolocation()
        }
      }
    }
  }

  connectGeolocation = () => {
    this.setState({ geoChecking: true })
    getPosition({ maximumAge: 60000, timeout: 5000 })
      .then(myPosition => {
        Geocode.fromLatLng(myPosition.coords.latitude, myPosition.coords.longitude)
          .then(geocode => {
            const myAddress = geocode.results[0].formatted_address
            let myZipCode = null
            if (myAddress && myAddress.match(/,\s\w{2}\s(\d{5})/)) {
              ;[, myZipCode] = myAddress.match(/,\s\w{2}\s(\d{5})/)
            }
            this.setState({
              myGeo: {
                coordinate: myPosition.coords,
                zip: myZipCode,
              },
              geoChecked: true,
              showPrompt: false,
              geoChecking: false,
            })
          })
          .catch(err => {
            this.setState({
              myGeo: { coordinate: myPosition.coords },
              geoChecked: true,
              showPrompt: false,
              geoChecking: false,
            })
          })
      })
      .catch(err => {
        console.log(err)
        this.setState({ myGeo: null, showPrompt: true, geoChecked: true, geoChecking: false })
      })
  }

  toggleSubscribeModal = (show, subscribeGroupType) => {
    this.setState({ showSubscribe: show, subscribeGroupType })
  }

  closePrompt = () => this.setState({ showPrompt: false })

  render() {
    const {
      groupingQuery: { loading, error, grouping },
      history,
    } = this.props
    const { myGeo, showSubscribe, showPrompt, geoChecked, subscribeGroupType } = this.state

    if (loading || error) {
      return (
        <div
          style={{
            paddingLeft: 'calc(50% - 35px)',
            paddingTop: 'calc(50vh - 35px)',
          }}
        >
          <ReactLoading type="spinningBubbles" color="lightgray" height={70} width={70} />
        </div>
      )
    }

    if (!grouping || !grouping[0] || !grouping[0]?.data?.ClientsData) {
      return 'No Client found'
    }

    // const { ClientsData: clientInfo } = grouping[0]?.data
    const clientInfo = {
      ...grouping[0]?.data?.ClientsData,
      _id: grouping[0]?._id,
      name: grouping[0]?.name,
    }

    const organizationInfo = {
      ...grouping[0]?.data.organization,
    }

    const { data: tree } = clientInfo
    let menus = []
    let generic = {}

    if (tree && tree.folders && tree.folders.length) {
      const rootFolders = tree.folders
      const rootMenu = rootFolders.find(folder => folder.rootType === 'Menus')
      if (rootMenu) {
        menus = rootMenu.folders || []
      }

      const genericMenu = rootFolders.find(folder => folder.rootType === 'General')
      generic = _.get(genericMenu, 'data') || {}
    }

    // const extratComponentFactors = rootType => {
    //   if (!_.get(tree, 'folders')) {
    //     return { data: {}, style: {} }
    //   }
    //   const menu = tree.folders.find(folder => folder.rootType === rootType)

    //   return { data: _.get(menu, 'data') || {}, style: _.get(menu, 'style') || {} }
    // }

    const extratComponentFactors = rootType => {
      const palettesInfo = {
        ...grouping[0]?.data.palettes,
      }
      return { style: palettesInfo || {} }
    }

    return (
      <Router history={history}>
        <SubscribeModal
          clientInfo={clientInfo}
          generic={generic}
          show={showSubscribe}
          toggleModal={this.toggleSubscribeModal}
          groupType={subscribeGroupType}
        />
        <Toast
          show={showPrompt}
          onClose={this.closePrompt}
          style={{
            position: 'fixed',
            top: '70px',
            right: '10px',
            zIndex: '1000',
            display: showPrompt ? 'block' : 'none',
          }}
        >
          <Toast.Header>
            <img src="holder.js/20x20?text=%20" className="rounded mr-2" alt="" />
            <strong className="mr-auto">For Geo-Targeted Feature</strong>
          </Toast.Header>
          <Toast.Body>Right now, Your browser location sharing option is turned off.</Toast.Body>
        </Toast>
        {/* <AdBar /> */}
        <Switch>
          <Route path="/article">
            {({ location }) => {
              const params = new URLSearchParams(location.search)
              const id = params.get('id')

              if (!id) {
                return <Redirect to="/" />
              }

              return <ArticleDetail _id={id} myGeo={myGeo} />
            }}
          </Route>
          <Route path="/group">
            {({ location }) => {
              const params = new URLSearchParams(location.search)
              const id = params.get('id')

              return <GroupDetail _id={id} myGeo={myGeo} />
            }}
          </Route>
          <Route path="/:path">
            {({ location }) => {
              const params = location.pathname.split('/')

              const path = params ? params[1] : ''

              const current = menus.find(menu => menu.link === path)
              const groupIds = []

              let rows = []

              if (current) {
                const { data: pageInfo } = current
                if (pageInfo) {
                  const { groups: pageGroups } = pageInfo

                  rows = pageInfo.rows

                  if (pageGroups) {
                    pageGroups.forEach(group => {
                      const _id = _.get(group, 'ref._id')
                      if (_id) groupIds.push(_id)
                    })
                  }
                }
              }

              window.scrollTo(0, 0)

              return (
                <>
                  <Menubar
                    generic={generic}
                    menus={menus}
                    organizationInfo={organizationInfo}
                    {...extratComponentFactors('Menus')}
                    // style={_.get(palettesInfo, 'title')}
                    toggleSubscribe={this.toggleSubscribeModal}
                  />
                  <PageLayout
                    rows={rows}
                    myGeo={myGeo}
                    generic={generic}
                    geoChecked={geoChecked}
                    clientInfo={clientInfo}
                    toggleSubscribe={this.toggleSubscribeModal}
                    connectGeolocation={this.connectGeolocation}
                  />
                </>
              )
            }}
          </Route>
          <Route path="/">
            {() => {
              const groupIds = []
              let rows = []

              if (menus && menus[0]) {
                const { data: pageInfo } = menus[0]
                if (pageInfo) {
                  const { groups: pageGroups } = pageInfo

                  rows = pageInfo.rows

                  if (pageGroups) {
                    pageGroups.forEach(group => {
                      const _id = _.get(group, 'ref._id')
                      if (_id) groupIds.push(_id)
                    })
                  }
                }
              }

              window.scrollTo(0, 0)

              return (
                <>
                  <Menubar
                    generic={generic}
                    menus={menus}
                    organizationInfo={organizationInfo}
                    {...extratComponentFactors('Menus')}
                    toggleSubscribe={this.toggleSubscribeModal}
                  />
                  <PageLayout
                    rows={rows}
                    myGeo={myGeo}
                    generic={generic}
                    geoChecked={geoChecked}
                    clientInfo={clientInfo}
                    toggleSubscribe={this.toggleSubscribeModal}
                    connectGeolocation={this.connectGeolocation}
                  />
                </>
              )
            }}
          </Route>
        </Switch>
      </Router>
    )
  }
}

export default compose(
  graphql(queries.groupingQuery, {
    name: 'groupingQuery',
    options: () => {
      const { hostname } = window.location
      const clientName = hostname === 'localhost' ? DEV_CLIENT : hostname

      return {
        variables: {
          // type: '/DynamicPages/',
          type: '/',
          names: [clientName],
          clientId: 'clients',
        },
      }
    },
  }),
  withApollo,
)(Routes)
