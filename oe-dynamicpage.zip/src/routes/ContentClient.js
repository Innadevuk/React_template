import React, { Component } from 'react'
import { graphql, withApollo } from 'react-apollo'
import * as compose from 'lodash.flowright'
import * as queries from 'utils/queries'
import { groupingUpdate, articleUpdate, groupingAdd, documentDelete } from 'utils/subscriptions'
import ContentGroups from 'components/ContentGroups'
import ReactLoading from 'react-loading'

import FilterGroups from 'listeners/FilterGroups'

class Client extends Component {
  constructor(props) {
    super(props)
    this.state = {
      subscription: null,
      articleSubscription: null,
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (!prevState.subscription && !nextProps.groupingQuery.loading) {
      return {
        subscription: [
          nextProps.groupingQuery.subscribeToMore({
            document: groupingUpdate,
            updateQuery: (previousResult, { subscriptionData }) => {
              if (
                !subscriptionData.data ||
                !subscriptionData.data.groupingUpdate ||
                !previousResult ||
                !previousResult.grouping ||
                !nextProps.groupIds.includes(subscriptionData.data.groupingUpdate._id)
              ) {
                return previousResult
              }
              const updatedIndex = previousResult.grouping.findIndex(group => group._id === subscriptionData.data.groupingUpdate._id)
              if (updatedIndex >= 0) {
                // return Object.assign({}, previousResult, {
                //   grouping: [...previousResult.grouping.slice(0, updatedIndex), subscriptionData.data.groupingUpdate, ...previousResult.grouping.slice(updatedIndex + 1)],
                // })
                return { ...previousResult, grouping: [...previousResult.grouping.slice(0, updatedIndex), subscriptionData.data.groupingUpdate, ...previousResult.grouping.slice(updatedIndex + 1)] }
              }

              // return Object.assign({}, previousResult, { grouping: [...previousResult.grouping, subscriptionData.data.groupingUpdate] })
              return { ...previousResult, grouping: [...previousResult.grouping, subscriptionData.data.groupingUpdate] }
            },
          }),
          nextProps.groupingQuery.subscribeToMore({
            document: groupingAdd,
            updateQuery: (previousResult, { subscriptionData }) => {
              if (!subscriptionData.data || !subscriptionData.data.groupingAdd || !previousResult || !previousResult.grouping || !nextProps.groupIds.includes(subscriptionData.data.groupingAdd._id)) {
                return previousResult
              }
              const updatedIndex = previousResult.grouping.findIndex(group => group._id === subscriptionData.data.groupingAdd._id)
              if (updatedIndex >= 0) return previousResult

              // return Object.assign({}, previousResult, { grouping: [...previousResult.grouping, subscriptionData.data.groupingAdd] })
              return { ...previousResult, grouping: [...previousResult.grouping, subscriptionData.data.groupingAdd] }
            },
          }),
          nextProps.groupingQuery.subscribeToMore({
            document: documentDelete,
            updateQuery: (previousResult, { subscriptionData }) => {
              if (!previousResult || !previousResult.grouping || !subscriptionData.data || !subscriptionData.data.documentDelete) {
                return previousResult
              }

              const { grouping } = previousResult

              const deleteIndex = grouping.findIndex(group => group._id === subscriptionData.data.documentDelete._id && group.collectionName === subscriptionData.data.documentDelete.collectionName)
              if (deleteIndex < 0) return previousResult

              // return Object.assign({}, previousResult, { grouping: [...grouping.slice(0, deleteIndex), ...grouping.slice(deleteIndex + 1)] })
              return { ...previousResult, grouping: [...grouping.slice(0, deleteIndex), ...grouping.slice(deleteIndex + 1)] }
            },
          }),
        ],
      }
    }
    if (!prevState.articleSubscription && !nextProps.eventQuery.loading) {
      return {
        articleSubscription: nextProps.eventQuery.subscribeToMore({
          document: articleUpdate,
          updateQuery: (previousResult, { subscriptionData }) => {
            if (!subscriptionData.data) return previousResult

            return previousResult
          },
        }),
      }
    }

    return null
  }

  render() {
    const {
      data: { bActive },
      groupingQuery: { loading, error, grouping: groups },
      myGeo,
      groupIds,
    } = this.props

    if (!bActive) {
      return ''
    }

    // if (!myGeo || loading) {
    if (loading) {
      return (
        <section className="oe-dynamicpage-body oe-dynamicpage-body-loading">
          <ReactLoading type="spinningBubbles" color="lightgray" height={70} width={70} />
        </section>
      )
    }

    if (error || !groups) {
      return (
        <section className="oe-dynamicpage-body oe-dynamicpage-body-loading">
          <img src="/images/error-page.png" alt="error" />
        </section>
      )
    }

    if (!groups.length) {
      return <section className="oe-dynamicpage-body" />
    }

    const reorderGroups = []
    for (let i = 0; i < groupIds.length; i += 1) {
      const findGroup = groups.find(group => group._id === groupIds[i])
      if (findGroup) reorderGroups.push(findGroup)
    }

    return (
      <section className="oe-dynamicpage-body">
        <FilterGroups groups={reorderGroups} myGeo={myGeo}>
          <ContentGroups />
        </FilterGroups>
      </section>
    )
  }
}

export default compose(
  graphql(queries.groupingQuery, {
    name: 'groupingQuery',
    options: ({ groupIds }) => ({
      variables: {
        ids: groupIds,
      },
    }),
  }),
  graphql(queries.eventQuery, {
    name: 'eventQuery',
    options: () => ({
      variables: {
        collectionName: 'Articles',
      },
    }),
  }),
  withApollo,
)(Client)
