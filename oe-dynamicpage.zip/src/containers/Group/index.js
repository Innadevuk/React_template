import React, { useReducer } from 'react'
import FilterGroup from 'listeners/FilterGroup'
import LayeredCanvas from 'containers/LayeredCanvas'

const reducer = (state, action) => {
  if (action.type === 'forward') {
    return {
      groupId: action.payload,
      history: [...state.history, state.groupId],
    }
  }

  if (action.type === 'back') {
    if (state.history) {
      const prev = state.history[state.history.length - 1]

      return {
        groupId: prev,
        history: [...state.history.slice(0, -1)],
      }
    }
  }

  return state
}

const GroupDetail = ({ _id, myGeo, clientInfo }) => {
  const [state, dispatch] = useReducer(reducer, {
    groupId: _id,
    history: [],
  })

  const changeGroup = newId => {
    dispatch({
      type: 'forward',
      payload: newId,
    })
  }

  const onBack = () => {
    dispatch({
      type: 'back',
    })
  }

  return (
    <FilterGroup groupId={state.groupId} myGeo={myGeo}>
      <LayeredCanvas
        myGeo={myGeo}
        groupId={state.groupId}
        setGroupId={changeGroup}
        goBack={onBack}
        hasBack={state.history?.length}
        clientInfo={clientInfo}
      />
    </FilterGroup>
  )
}
export default GroupDetail
