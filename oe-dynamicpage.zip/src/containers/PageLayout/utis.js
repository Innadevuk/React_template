const CellType = {
  None: undefined,
  GroupType: 'groupType',
  Group: 'group',
  Component: 'component',
}

const CellComponentType = {
  Header: 'Header',
  Contact: 'Contact',
  Subscription: 'Subscription',
  Footer: 'Footer',
  Copyright: 'Copyright',
}

export { CellType, CellComponentType }
