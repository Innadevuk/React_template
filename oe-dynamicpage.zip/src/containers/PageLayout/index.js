import React, { Component } from 'react'
import { graphql, withApollo } from 'react-apollo'
import * as compose from 'lodash.flowright'
import * as queries from 'utils/queries'
import { groupingUpdate, articleUpdate, groupingAdd, documentDelete } from 'utils/subscriptions'

import { Row, Col } from 'react-bootstrap'
import _ from 'lodash'
import Header from 'components/Header'
import Contactus from 'components/Contactus'
import Footer from 'components/Footer'
import Copyright from 'components/Copyright'
import SubscriptionComp from 'components/SubscriptionComp'
// import SubscribeForm from 'components/SubscribeForm'
import objectAssignDeep from 'object-assign-deep'
import { DEFAULT_STYLE } from 'utils/defaultValues'
import GroupDetail from 'containers/Group'
import { CellType, CellComponentType } from './utis'
import NotificationClient from '../../routes/NotificationClient'
import './index.scss'

class PageLayout extends Component {
  constructor(props) {
    super(props)
    this.state = {
      subscription: null,
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (!prevState.subscription && !nextProps.groupingQuery.loading) {
      return {
        subscription: [
          nextProps.groupingQuery.subscribeToMore({
            document: groupingUpdate,
            updateQuery: (previousResult, { subscriptionData }) => {
              if (
                !subscriptionData.data ||
                !subscriptionData.data.groupingUpdate ||
                !previousResult ||
                !previousResult.grouping ||
                subscriptionData.data.groupingUpdate.clientId !== nextProps.clientInfo._id ||
                subscriptionData.data.groupingUpdate.type !== nextProps.groupType
              ) {
                return previousResult
              }
              const updatedIndex = previousResult.grouping.findIndex(
                group => group._id === subscriptionData.data.groupingUpdate._id,
              )
              if (updatedIndex >= 0) {
                // return Object.assign({}, previousResult, {
                //   grouping: [...previousResult.grouping.slice(0, updatedIndex), subscriptionData.data.groupingUpdate, ...previousResult.grouping.slice(updatedIndex + 1)],
                // })
                return {
                  ...previousResult,
                  grouping: [
                    ...previousResult.grouping.slice(0, updatedIndex),
                    subscriptionData.data.groupingUpdate,
                    ...previousResult.grouping.slice(updatedIndex + 1),
                  ],
                }
              }

              // return Object.assign({}, previousResult, { grouping: [...previousResult.grouping, subscriptionData.data.groupingUpdate] })
              return {
                ...previousResult,
                grouping: [...previousResult.grouping, subscriptionData.data.groupingUpdate],
              }
            },
          }),
          nextProps.groupingQuery.subscribeToMore({
            document: groupingAdd,
            updateQuery: (previousResult, { subscriptionData }) => {
              if (
                !subscriptionData.data ||
                !subscriptionData.data.groupingAdd ||
                !previousResult ||
                !previousResult.grouping ||
                subscriptionData.data.groupingAdd.clientId !== nextProps.clientInfo._id ||
                subscriptionData.data.groupingAdd.type !== nextProps.groupType
              ) {
                return previousResult
              }
              const updatedIndex = previousResult.grouping.findIndex(
                group => group._id === subscriptionData.data.groupingAdd._id,
              )
              if (updatedIndex >= 0) return previousResult

              // return Object.assign({}, previousResult, { grouping: [...previousResult.grouping, subscriptionData.data.groupingAdd] })
              return {
                ...previousResult,
                grouping: [...previousResult.grouping, subscriptionData.data.groupingAdd],
              }
            },
          }),
          nextProps.groupingQuery.subscribeToMore({
            document: documentDelete,
            updateQuery: (previousResult, { subscriptionData }) => {
              if (
                !previousResult ||
                !previousResult.grouping ||
                !subscriptionData.data ||
                !subscriptionData.data.documentDelete
              ) {
                return previousResult
              }

              const { grouping } = previousResult

              const deleteIndex = grouping.findIndex(
                group =>
                  group._id === subscriptionData.data.documentDelete._id &&
                  group.collectionName === subscriptionData.data.documentDelete.collectionName,
              )
              if (deleteIndex < 0) return previousResult

              // return Object.assign({}, previousResult, { grouping: [...grouping.slice(0, deleteIndex), ...grouping.slice(deleteIndex + 1)] })
              return {
                ...previousResult,
                grouping: [...grouping.slice(0, deleteIndex), ...grouping.slice(deleteIndex + 1)],
              }
            },
          }),
        ],
      }
    }
    if (!prevState.articleSubscription && !nextProps.eventQuery.loading) {
      return {
        articleSubscription: nextProps.eventQuery.subscribeToMore({
          document: articleUpdate,
          updateQuery: (previousResult, { subscriptionData }) => {
            if (!subscriptionData.data) return previousResult

            return previousResult
          },
        }),
      }
    }

    return null
  }

  render() {
    const {
      rows,
      myGeo,
      generic,
      clientInfo,
      toggleSubscribe,
      connectGeolocation,
      geoChecked,
    } = this.props
    const renderRows = []

    if (rows) {
      rows.forEach((row, index) => {
        const { type, columns } = row

        const renderColumns = []

        if (columns) {
          columns.forEach((column, colIndex) => {
            const { ratio, cellType, group, groupType, component } = column

            let raw = ''
            switch (cellType) {
              case CellType.Group:
                raw = (
                  <GroupDetail _id={_.get(group, '_id')} myGeo={myGeo} clientInfo={clientInfo} />
                )
                break
              case CellType.Component:
                {
                  const name = _.get(component, 'name')
                  const data = _.get(component, 'data') || {}
                  const style = objectAssignDeep({ ...DEFAULT_STYLE }, _.get(component, 'style'))

                  switch (name) {
                    case CellComponentType.Header:
                      raw = <Header generic={generic} data={data} style={style} />
                      break
                    case CellComponentType.Contact:
                      raw = <Contactus generic={generic} data={data} style={style} />
                      break
                    case CellComponentType.Subscription:
                      raw = <SubscriptionComp clientInfo={clientInfo} myGeo={myGeo} />
                      break
                    case CellComponentType.Footer:
                      raw = <Footer generic={generic} data={data} style={style} />
                      break
                    case CellComponentType.Copyright:
                      raw = <Copyright generic={generic} data={data} style={style} />
                      break
                    default:
                      break
                  }
                }
                break
              case CellType.GroupType:
                {
                  const name = _.get(groupType, 'name')
                  const data = _.get(groupType, 'data') || {}
                  const style = _.get(groupType, 'style') || {}

                  // console.log(geoChecked)

                  // if (geoChecked) {
                  const dismissable = !['DND', 'Areas', 'SubAreas', 'Cases'].includes(name)
                  const commonNotificationProps = {
                    myGeo,
                    geoChecked,
                    clientInfo,
                    toggleSubscribe,
                  }

                  raw = (
                    <NotificationClient
                      {...commonNotificationProps}
                      groupType={name}
                      data={data}
                      style={style}
                      dismissable={dismissable}
                      connectGeolocation={connectGeolocation}
                    />
                  )
                  // }
                }
                break
              default:
                break
            }

            renderColumns.push(
              <Col sm={ratio} key={colIndex} style={{ paddingLeft: 0, paddingRight: 0 }}>
                {raw}
              </Col>,
            )
          })
        }
        renderRows.push(<Row key={index}>{renderColumns}</Row>)
      })
      // renderRows.splice(
      //   1,
      //   0,
      //   <Col sm={12} style={{ paddingLeft: 0, paddingRight: 0 }}>
      //     <SubscribeForm />
      //   </Col>,
      // )
    }
    return <section className="oe-dynamicpage-body">{renderRows}</section>
  }
}

export default compose(
  graphql(queries.groupingQuery, {
    name: 'groupingQuery',
    options: ({ clientInfo, groupType }) => ({
      variables: {
        ids: null,
        clientId: clientInfo._id,
        type: groupType,
      },
    }),
  }),
  graphql(queries.eventQuery, {
    name: 'eventQuery',
    options: () => ({
      variables: {
        collectionName: 'Articles',
      },
    }),
  }),
  withApollo,
)(PageLayout)
