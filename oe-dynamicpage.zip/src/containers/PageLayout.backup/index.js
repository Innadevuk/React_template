import React from 'react'
import { Row, Col } from 'react-bootstrap'
import _ from 'lodash'
import FilterGroup from 'listeners/FilterGroup'
import ContentGroup from 'components/ContentGroup'
import './index.scss'

const PageLayout = ({ rows, myGeo, data: { bActive } }) => {
  const renderRows = []

  if (!bActive) {
    return ''
  }

  if (rows) {
    rows.forEach((row, index) => {
      const { type, columns } = row

      const renderColumns = []

      if (columns) {
        columns.forEach((column, colIndex) => {
          const _id = _.get(column, 'ref._id')
          const ratio = _.get(column, 'ratio')

          renderColumns.push(
            <Col sm={ratio} key={colIndex} style={{ paddingLeft: 0, paddingRight: 0 }}>
              <FilterGroup groupId={_id} myGeo={myGeo}>
                <ContentGroup />
              </FilterGroup>
            </Col>,
          )
        })
      }
      renderRows.push(<Row key={index}>{renderColumns}</Row>)
    })
  }

  return <section className="oe-dynamicpage-body">{renderRows}</section>
}

export default PageLayout
