import React from 'react'
import { useQuery } from 'react-apollo'
import * as queries from 'utils/queries'
import { articleUpdate, documentDelete } from 'utils/subscriptions'

import { DEFAULT_STYLE } from 'utils/defaultValues'

import MediaViewGroupContentTopBarStacked from 'components/Shared/MediaViewGroup/Content/Top/BarStacked'
import MediaViewGroupContainer from 'components/Shared/MediaViewGroup/Container'
import './index.scss'

const ArticleDetail = ({ _id, myGeo }) => {
  const { loading, error, data } = useQuery(queries.eventQuery, {
    variables: {
      _id,
      collectionName: 'Articles',
    },
  })

  if (loading || error) {
    return ''
  }

  const { article: articles } = data

  const group = {
    availability: {
      state: 'on',
    },
    articles,
    style: DEFAULT_STYLE,
  }

  const layoutType = 'ArticlesStack'

  return (
    <MediaViewGroupContainer group={group} layoutType={layoutType}>
      <MediaViewGroupContentTopBarStacked group={group} myGeo={myGeo} layoutType={layoutType} />
    </MediaViewGroupContainer>
  )
}

export default ArticleDetail
