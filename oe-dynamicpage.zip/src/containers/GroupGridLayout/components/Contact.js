import React from 'react'

const Contact = ({ group }) => {
  const name = group?.data?.contact?.name

  return <div className="oe-contact">{name}</div>
}

export default Contact
