import React from 'react'

const MenuLogo = ({ group, height }) => {
  const logo = group?.data?.desc?.logo

  console.log(logo)

  return <img src={logo?.url} alt="logo" style={{ height }} />
}

export default MenuLogo
