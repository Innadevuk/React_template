/* eslint-disable react/forbid-prop-types */
import React, { useState, useEffect } from 'react'
import PropTypes from 'prop-types'
import * as queries from 'utils/queries'
import { useApolloClient } from '@apollo/react-hooks'
import { makeStyles } from '@material-ui/core/styles'
import TreeView from '@material-ui/lab/TreeView'
import ExpandMoreIcon from '@material-ui/icons/ExpandMore'
import ChevronRightIcon from '@material-ui/icons/ChevronRight'
import Chip from '@material-ui/core/Chip'
import { TreeItem } from '@material-ui/lab'
import './List.scss'

const useStyles = makeStyles({
  root: {
    height: 110,
    flexGrow: 1,
    maxWidth: 400,
  },
})

const searchTree = (element, id) => {
  if (element.id === id) {
    return element
  }
  if (element.children != null) {
    let i
    let result = null
    for (i = 0; result == null && i < element.children.length; i += 1) {
      result = searchTree(element.children[i], id)
    }

    return result
  }

  return null
}

const TxList = ({ group, myGeo, setGroupId, rowHeight, data, clientInfo }) => {
  const classes = useStyles()
  const [expanded, setExpanded] = React.useState([])
  const [selected, setSelected] = React.useState([])
  const [rootFetched, setRootFetched] = useState(false)
  const [root, setRoot] = useState({
    id: data?.grouptype,
    name: data?.grouptype,
    status: '',
    children: [],
  })

  const client = useApolloClient()

  useEffect(() => {
    async function fetchRoot() {
      const parentType = data?.grouptype?.split('/').slice(0, -2).join('/') + '/'
      const groupName = data?.grouptype?.split('/').slice(-2).join('/')
      const { data: payload } = await client.query({
        query: queries.groupingQuery,
        variables: { type: parentType, names: [groupName], clientId: clientInfo._id },
      })

      setRoot({
        ...root,
        status: payload?.grouping[0]?.data?.transmission?.status,
      })
      setRootFetched(true)
    }

    fetchRoot()
  }, [])

  const renderTree = nodes => (
    <TreeItem
      key={nodes.id}
      nodeId={nodes.id}
      label={
        <span>
          {nodes.name}&nbsp;
          <Chip
            label={nodes.status ? nodes.status : 'not downloaded'}
            size="small"
            style={{ fontSize: 10, height: 16 }}
          />
        </span>
      }
    >
      {Array.isArray(nodes.children) ? nodes.children.map(node => renderTree(node)) : null}
    </TreeItem>
  )

  const handleToggle = (event, nodeIds) => {
    setExpanded(nodeIds)
  }

  const handleSelect = async (event, nodeIds) => {
    setSelected(nodeIds)

    const search = searchTree(root, nodeIds)

    if (!search || !search.children || search.children?.length) return

    const { data } = await client.query({
      query: queries.groupingQuery,
      variables: { type: nodeIds },
    })

    if (search.children?.length) return

    data?.grouping?.forEach(group => {
      search.children.push({
        id: `${nodeIds}${group?.name}`,
        name: group?.name,
        status: group?.data?.transmission?.status,
        children: [],
      })
    })

    setRoot({ ...root })
    setExpanded([...expanded, nodeIds])
  }

  if (!rootFetched) return ''

  return (
    <TreeView
      className={classes.root}
      defaultCollapseIcon={<ExpandMoreIcon />}
      defaultExpanded={['root']}
      defaultExpandIcon={<ChevronRightIcon />}
      onNodeToggle={handleToggle}
      onNodeSelect={handleSelect}
      expanded={expanded}
      selected={selected}
    >
      {renderTree(root)}
    </TreeView>
  )
}

TxList.propTypes = {
  group: PropTypes.object,
}

TxList.defaultProps = {
  group: {},
}

export default TxList
