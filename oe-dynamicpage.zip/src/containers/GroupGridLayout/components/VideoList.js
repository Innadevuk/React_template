/* eslint-disable react/forbid-prop-types */
import React, { useState } from 'react'
import PropTypes from 'prop-types'
import { Player } from 'video-react'
import HLSSourceList from 'components/HLSSourceList'
import './VideoList.scss'

/**
 * @component VideoList
 * Plays MP4 video of a Group
 * group->data->videoList
 *
 * @todo
 * finished
 *
 * @param {object} group
 */

const VideoList = ({ group }) => {
  const [current, setCurrent] = useState(0)
  const videoList = group?.data?.videoList
  const autoLoop = group?.data?.layout?.autoLoop
  const autoStart = group?.data?.layout?.autoStart

  const onEnded = () => {
    console.log('onEnd')
    if (current + 1 < videoList.length || autoLoop) {
      setCurrent((current + 1) % videoList.length)
    }
  }

  const videoOptions = {
    autoPlay: autoStart,
    muted: autoStart,
  }

  console.log(current)

  return (
    <div className="video-list">
      <Player onEnded={onEnded} src={videoList[current]?.url} {...videoOptions} />
    </div>
  )
}

VideoList.propTypes = {
  group: PropTypes.object,
}

VideoList.defaultProps = {
  group: {},
}

export default VideoList
