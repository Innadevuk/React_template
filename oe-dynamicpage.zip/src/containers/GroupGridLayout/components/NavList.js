/* eslint-disable react/forbid-prop-types */
import React, { useState, useEffect } from 'react'
import PropTypes from 'prop-types'
import * as queries from 'utils/queries'
import { useApolloClient } from '@apollo/react-hooks'
import _ from 'lodash'
import { makeStyles } from '@material-ui/core/styles'
import TreeView from '@material-ui/lab/TreeView'
import ExpandMoreIcon from '@material-ui/icons/ExpandMore'
import ChevronRightIcon from '@material-ui/icons/ChevronRight'
import { TreeItem } from '@material-ui/lab'
import './List.scss'

const useStyles = makeStyles({
  root: {
    height: 110,
    flexGrow: 1,
    maxWidth: 400,
  },
})

const searchTree = (element, id) => {
  if (element.id === id) {
    return element
  }
  if (element.children != null) {
    let i
    let result = null
    for (i = 0; result == null && i < element.children.length; i += 1) {
      result = searchTree(element.children[i], id)
    }

    return result
  }

  return null
}

const NavList = ({ group, myGeo, setGroupId, rowHeight, data }) => {
  const classes = useStyles()
  const [expanded, setExpanded] = React.useState([])
  const [selected, setSelected] = React.useState([])
  const [root, setRoot] = useState({
    id: data?.grouptype,
    name: data?.grouptype,
    children: [],
  })

  const client = useApolloClient()

  const renderTree = nodes => (
    <TreeItem key={nodes.id} nodeId={nodes.id} label={nodes.name}>
      {Array.isArray(nodes.children) ? nodes.children.map(node => renderTree(node)) : null}
    </TreeItem>
  )

  const handleToggle = (event, nodeIds) => {
    setExpanded(nodeIds)
  }

  const handleSelect = async (event, nodeIds) => {
    setSelected(nodeIds)

    const search = searchTree(root, nodeIds)

    if (!search || !search.children || search.children?.length) return

    const { data } = await client.query({
      query: queries.groupingQuery,
      variables: { type: nodeIds },
    })

    data?.grouping?.forEach(group => {
      search.children.push({
        id: `${nodeIds}${group?.name}`,
        name: group?.name,
        children: [],
      })
    })

    setRoot({ ...root })
    setExpanded([...expanded, nodeIds])
  }

  return (
    <TreeView
      className={classes.root}
      defaultCollapseIcon={<ExpandMoreIcon />}
      defaultExpanded={['root']}
      defaultExpandIcon={<ChevronRightIcon />}
      onNodeToggle={handleToggle}
      onNodeSelect={handleSelect}
      expanded={expanded}
      selected={selected}
    >
      {renderTree(root)}
    </TreeView>
  )
}

NavList.propTypes = {
  group: PropTypes.object,
}

NavList.defaultProps = {
  group: {},
}

export default NavList
