import React, { useState } from 'react'
import { Button, Modal } from 'react-bootstrap'
import { useQuery } from '@apollo/react-hooks'
import * as queries from 'utils/queries'
import { isValidLocation } from 'utils/criteria'
import classnames from 'classnames'
import _ from 'lodash'
import Plugin from './Plugin'
import './Notification.scss'

const Notification = ({ hideLayer, group, setGroupId, myGeo }) => {
  const list = group?.data?.mainwidget?.list || []
  const notification = group?.data?.LayerNotification
  const [showPopup, setShowPopup] = useState(notification?.visible)

  const { loading: loadingFolders, error: errorFolders, data: dataFolders } = useQuery(
    queries.groupingQuery,
    {
      variables: {
        ids: list,
      },
    },
  )

  const folders = dataFolders?.grouping || []

  const validGroupTypes = []

  for (const group of folders) {
    if (!group || !group.list) {
      // console.log('Group is invalid or there is no active article in the Group')
      continue
    }

    const groupLocation = _.get(group, 'data.location')

    const bAvailability = _.get(group, 'availability.state') === 'on' // OLD ACTIVE GROUPS
    const bSchedule =
      !_.get(group, 'schedule.bActive') || _.get(group, 'schedule.status') === 'active'
    const bGroupLocation = isValidLocation(groupLocation, myGeo)

    if (!bAvailability) continue
    if (!bSchedule) continue
    if (!bGroupLocation) continue

    validGroupTypes.push(group)
  }

  const firstGroup = validGroupTypes ? validGroupTypes[0] : null

  const modalClass = classnames(
    'notification-dialog',
    notification?.position?.horizontal,
    notification?.position?.vertical || 'middle',
  )

  if (showPopup) {
    return (
      <Modal.Dialog className={modalClass}>
        <Modal.Header closeButton>
          <Modal.Title>{firstGroup?.data?.desc?.title}</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <p>{notification?.canvas?.desc}</p>
        </Modal.Body>

        <Modal.Footer>
          {/* <Button variant="secondary">Close</Button> */}
          <Button variant="primary" onClick={() => setShowPopup(false)}>
            Ok
          </Button>
        </Modal.Footer>
      </Modal.Dialog>
    )
  }

  return (
    <div className="oe-group-notification">
      <Plugin hideLayer={hideLayer} group={group} setGroupId={setGroupId} myGeo={myGeo} />
    </div>
  )
}

export default Notification
