import React from 'react'
import MapComponent from 'components/Shared/MapComponent'

const Body = ({ group, myGeo }) => {
  const location = group?.data?.location
  const viewPort = location?.viewport || null
  const bLocation =
    location && location.bActive && location.type && location.type !== 'none' && viewPort

  return (
    <div className="oe-menu-media-desc-mediabox-location">
      {bLocation && myGeo && (
        <MapComponent
          googleMapURL="https://maps.googleapis.com/maps/api/js?key=AIzaSyDQ6fOZioeYFWHF-Q02vErr8v7duPXywRA&v=3.exp&libraries=geometry,drawing,places"
          loadingElement={<div className="loadingelement" />}
          mapElement={<div className="mapelement" id="map" />}
          containerElement={<div className="containerelement" />}
          zoom={location.viewport.zoom}
          center={{
            lat: myGeo.coordinate.latitude,
            lng: myGeo.coordinate.longitude,
          }}
          type={location.type}
          color={location.color}
          onPointAdd={() => {}}
          useCase={location.useCase}
          coordinates={location.coordinates}
          zones={location.zones}
          unit={location.viewport.unit}
          points={location.points}
          showCenterMark
        />
      )}
    </div>
  )
}

export default Body
