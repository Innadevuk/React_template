/* eslint-disable react/forbid-prop-types */
import React, { useState, useEffect } from 'react'
import PropTypes from 'prop-types'
import * as queries from 'utils/queries'
import { useQuery } from '@apollo/react-hooks'
import ItemsCarousel from 'react-items-carousel'
import { Spinner, Dropdown } from 'react-bootstrap'
import _ from 'lodash'
import { isValidLocation } from 'utils/criteria'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faChevronRight, faChevronLeft } from '@fortawesome/free-solid-svg-icons'
import './List.scss'

/**
 * @component List
 * Shows List
 * group->data->groups
 *
 * @todo
 * finished
 *
 * @param {object} group
 */

const List = ({ group, myGeo, setGroupId, rowHeight }) => {
  const [currentGroupIndex, setCurrentGroupIndex] = useState(0)
  const list = group?.data?.groups?.list || []
  const palette = group?.data?.palettes?.body

  const { loading, error, data: dataFolders } = useQuery(queries.groupingQuery, {
    variables: {
      ids: list,
    },
  })

  const onSelectGroup = _id => {
    setGroupId(_id)
  }

  const folders = dataFolders?.grouping || []

  const validGroups = []

  console.log(folders)

  for (const _id of list) {
    const group = folders.find(item => item._id === _id)
    if (!group || !group.list) {
      // console.log('Group is invalid or there is no active article in the Group')
      continue
    }

    const groupLocation = _.get(group, 'data.location')

    const bAvailability = _.get(group, 'availability.state') === 'on' // OLD ACTIVE GROUPS
    const bSchedule =
      !_.get(group, 'schedule.bActive') || _.get(group, 'schedule.status') === 'active'
    const bGroupLocation = isValidLocation(groupLocation, myGeo)

    if (!bAvailability) continue
    if (!bSchedule) continue
    if (!bGroupLocation) continue

    validGroups.push(group)
  }

  const doAction = (actionType, group) => {
    switch (actionType) {
      case 'Load':
        onSelectGroup(group._id)
        break
      case 'Hide':
        console.log('Hide Action')
        break
      case 'Show':
        console.log('Show Action')
        break
      default:
        break
    }
  }

  useEffect(() => {
    if (validGroups?.length === 1) {
      const actions = validGroups[0]?.data?.actions || []
      if (actions.length === 1) {
        doAction(actions[0], validGroups[0])
      }
    }
  }, [validGroups?.length])

  const paletteStyle = {
    backgroundColor: palette?.bg?.color || 'white',
    opacity: (100 - (palette?.bg?.transparency || 0)) / 100,
    color: palette?.fg?.color || 'white',
    fontWeight: palette?.fg?.weight,
    fontSize: palette?.fg?.size,
  }

  return (
    <div className="oe-list" style={paletteStyle}>
      {loading && (
        <div className="oe-list-group-list  loading">
          <Spinner animation="border" role="status" size="sm">
            <span className="sr-only">Loading...</span>
          </Spinner>
        </div>
      )}
      {!loading && (
        <ItemsCarousel
          // Carousel configurations
          numberOfCards={4}
          gutter={10}
          // Active item configurations
          requestToChangeActive={number => {
            setCurrentGroupIndex(number % validGroups?.length)
          }}
          activeItemIndex={currentGroupIndex}
          activePosition="center"
          chevronWidth={20}
          rightChevron={<FontAwesomeIcon icon={faChevronRight} />}
          leftChevron={<FontAwesomeIcon icon={faChevronLeft} />}
          classes={{ wrapper: 'oe-list-group-list ' }}
          style={{ height: rowHeight || '60px' }}
          infiniteLoop
        >
          {validGroups?.map((group, index) => {
            const actions = group?.data?.actions?.list || []

            if (actions.length <= 1) {
              return (
                <div
                  className="oe-list-group-item"
                  key={group?._id}
                  style={{ height: rowHeight || '60px' }}
                >
                  <span
                    onClick={() => {
                      if (actions.length) {
                        doAction(actions[0], group)
                      }
                    }}
                  >
                    {group?.name || 'No Title'}
                  </span>
                </div>
              )
            }

            console.log(actions)

            return (
              <div className="oe-list-group-item" key={group?._id}>
                <Dropdown key={index}>
                  <Dropdown.Toggle>
                    <span>{group?.name || 'No Title'}</span>
                  </Dropdown.Toggle>

                  <Dropdown.Menu>
                    {actions.map((action, index) => (
                      <Dropdown.Item key={index} onClick={() => doAction(action, group)}>
                        {action}
                      </Dropdown.Item>
                    ))}
                  </Dropdown.Menu>
                </Dropdown>
              </div>
            )
          })}
        </ItemsCarousel>
      )}
    </div>
  )
}

List.propTypes = {
  group: PropTypes.object,
}

List.defaultProps = {
  group: {},
}

export default List
