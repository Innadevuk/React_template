import React from 'react'
import { Button } from 'react-bootstrap'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faTimes } from '@fortawesome/free-solid-svg-icons'

const Exit = ({ hideLayer }) => {
  return (
    <div className="oe-exit">
      <Button variant="outline-primary" onClick={() => hideLayer()}>
        <FontAwesomeIcon icon={faTimes} />
      </Button>
    </div>
  )
}

export default Exit
