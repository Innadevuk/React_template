import React from 'react'

const URL = ({ group, data }) => {
  console.log('URL', data)

  return (
    <a className="oe-url" href={data?.url} target="_blank" rel="noopener noreferrer">
      {data?.url}
    </a>
  )
}

export default URL
