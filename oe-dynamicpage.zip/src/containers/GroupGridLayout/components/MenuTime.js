import React from 'react'
import moment from 'moment'

const MenuTime = ({ data, group, style }) => {
  const current = moment().format('YYYY-MM-DD HH:mm')

  return <div>{current}</div>
}

export default MenuTime
