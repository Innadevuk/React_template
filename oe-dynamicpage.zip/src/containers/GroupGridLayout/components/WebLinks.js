import React, { useState } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faLink } from '@fortawesome/free-solid-svg-icons'
import './WebLinks.scss'

const Weblinks = ({ group, data }) => {
  const list = group?.data?.actions?.list?.filter(item => item.type === 'WebLinks') || []
  const palettes = group?.data?.palettes

  const [show, setShow] = useState(false)
  const showName = () => {
    if (!show) {
      setShow(true)
    } else {
      setShow(false)
    }
  }

  return (
    <div className="oe-web-links" style={{ width: '100%' }}>
      <span
        className="trigger"
        style={{
          backgroundColor: palettes?.canvas?.bg?.color || 'white',
          color: palettes?.canvas?.fg?.color || 'white',
        }}
      >
        <FontAwesomeIcon icon={faLink} onClick={showName} />
      </span>
      {show && (
        <div
          className="oe-web-links-content"
          style={{
            backgroundColor: show ? palettes?.body?.bg?.color || 'white' : undefined,
            opacity: show && 0.5,
            flexDirection: 'row',
          }}
        >
          {list?.map((item, index) => {
            return (
              <span key={index} style={{ color: palettes?.body?.fg?.color || 'white' }}>
                <a>{item?.displaytext}</a>
              </span>
            )
          })}
        </div>
      )}
    </div>
  )
}

export default Weblinks
