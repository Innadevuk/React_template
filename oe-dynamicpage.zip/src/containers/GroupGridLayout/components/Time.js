import React from 'react'
import moment from 'moment'

const Time = ({ data, group, style }) => {
  const current = moment().format('YYYY-MM-DD HH:mm')
  const updatedAt = moment(group?.updatedAt).format('YYYY-MM-DD HH:mm')

  const type = data?.type

  return <div>{type !== 'current' ? updatedAt : current}</div>
}

export default Time
