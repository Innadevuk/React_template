import React from 'react'
import './Divider.scss'

const Divider = ({ group }) => {
  const palette = group?.data?.palettes?.menu

  console.log(palette?.divider)

  return (
    <div
      className="oe-divider"
      style={{
        backgroundColor: palette?.divider?.color || 'white',
        height: palette?.divider?.weight,
      }}
    />
  )
}

export default Divider
