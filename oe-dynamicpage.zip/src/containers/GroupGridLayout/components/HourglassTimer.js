/* eslint-disable react/forbid-prop-types */
import React from 'react'
import PropTypes from 'prop-types'
import { groupingQuery } from 'utils/queries'
import { useQuery } from '@apollo/react-hooks'
import { Spinner } from 'react-bootstrap'
import moment from 'moment'

/**
 * @component HourglassTimer
 * Shows HourglassTimer information
 * group->data->offset
 *
 * @todo
 * finished
 *
 * @param {object} group
 */

const HourglassTimer = ({ group }) => {
  const offset = group?.data?.offset || []

  const { loading, error, data: groupingQueryData } = useQuery(groupingQuery, {
    variables: {
      ids: offset?.list?.map(item => item.groupId) || [],
    },
  })

  if (loading) {
    return (
      <ul className="oe-group-list loading">
        <Spinner animation="border" role="status" size="sm">
          <span className="sr-only">Loading...</span>
        </Spinner>
      </ul>
    )
  }

  return (
    <ul className="oe-group-list">
      {offset?.list?.map((item, index) => {
        const { datetime, duration, groupId } = item
        const group = groupingQueryData?.grouping?.find(group => group._id === groupId)

        return (
          <li key={index}>
            <span>Offset: {moment(datetime).format('hh:mm:ss')}</span>
            <br />
            <span>Duration: {duration}</span>
            <br />
            <span>Group: {group?.name}</span>
          </li>
        )
      })}
    </ul>
  )
}

HourglassTimer.propTypes = {
  group: PropTypes.object,
}

HourglassTimer.defaultProps = {
  group: {},
}

export default HourglassTimer
