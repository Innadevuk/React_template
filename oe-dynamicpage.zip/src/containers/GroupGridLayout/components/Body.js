import React from 'react'
import './Body.scss'

const Body = ({ group, rowHeight }) => {
  const body = group?.data?.desc?.body

  return (
    <div
      className="oe-html-body"
      dangerouslySetInnerHTML={{ __html: body }}
      style={{ height: rowHeight, overflow: 'scroll' }}
    />
  )
}

export default Body
