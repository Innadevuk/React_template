/* eslint-disable react/forbid-prop-types */
import React from 'react'
import PropTypes from 'prop-types'
import Slider from 'react-slick'
import './ImageList.scss'

/**
 * @component ImageList
 * Shows ImageList Carousel
 * group->data->imageList
 *
 * @todo
 * finished
 *
 * @param {object} group
 */

const settings = {
  className: 'slider',
  dots: true,
  infinite: true,
  fade: true,
  speed: 1500,
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplaySpeed: 5000,
  autoplay: true,
  variableWidth: true,
}

const ImageList = ({ group, layoutConfig, rowHeight }) => {
  const imageList = group?.data?.imageList || []

  return (
    <div className="oe-image-list">
      <Slider {...settings} style={{ height: rowHeight, overflow: 'hidden' }}>
        {imageList?.map((image, index) => (
          <div key={index}>
            <img
              alt="slide"
              src={image.url}
              key={index}
              // style={{ width: layoutConfig?.canvas?.width }}
              style={{ width: '100%' }}
            />
          </div>
        ))}
      </Slider>
    </div>
  )
}

ImageList.propTypes = {
  group: PropTypes.object,
}

ImageList.defaultProps = {
  group: {},
}

export default ImageList
