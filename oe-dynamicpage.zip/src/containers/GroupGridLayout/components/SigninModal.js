import React, { useState } from 'react'
import { Button, Modal, Form, Spinner } from 'react-bootstrap'

const SigninModal = ({ onCancel, onOk, loading }) => {
  const [username, setUsername] = useState('')

  return (
    <Modal className="oe-signin-modal" show onHide={onCancel}>
      <Modal.Header closeButton>
        <Modal.Title>Signin/Signup</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <Form.Group controlId="formBasicEmail">
          <Form.Label>Username: </Form.Label>
          <Form.Control
            value={username}
            onChange={e => setUsername(e.target.value)}
            autoComplete="off"
            disabled={loading}
          />
        </Form.Group>
      </Modal.Body>

      <Modal.Footer>
        <Button variant="secondary" onClick={onCancel} disabled={loading}>
          Close
        </Button>
        <Button
          variant="primary"
          onClick={() => onOk(username)}
          disabled={loading || !username?.length}
        >
          {loading ? <Spinner animation="border" size="sm" /> : 'OK'}
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

export default SigninModal
