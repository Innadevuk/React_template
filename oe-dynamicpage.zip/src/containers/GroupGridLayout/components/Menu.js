/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import React, { useState, useEffect, useCallback, useReducer } from 'react'
import { useApolloClient } from '@apollo/react-hooks'
import { Button, Row, Col } from 'react-bootstrap'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faBars } from '@fortawesome/free-solid-svg-icons'
import classnames from 'classnames'
import * as queries from 'utils/queries'
import * as mutations from 'utils/mutations'
import toastr from 'toastr'
import Divider from './Divider'
import MenuTime from './MenuTime'
import MenuLogo from './MenuLogo'
import MenuEvents from './MenuEvents'
import MenuDivider from './MenuDivider'
import SigninModal from './SigninModal'
import { CellType, CellComponentType } from '../utis'
import './Menu.scss'

const toastrOptions = {
  closeButton: true,
  debug: false,
  newestOnTop: true,
  progressBar: true,
  positionClass: 'toast-top-right',
  preventDuplicates: false,
  onclick: null,
  showDuration: '300',
  hideDuration: '1000',
  timeOut: '5000',
  extendedTimeOut: '1000',
  showEasing: 'swing',
  hideEasing: 'linear',
  showMethod: 'fadeIn',
  hideMethod: 'fadeOut',
}

const reducer = (state, action) => {
  switch (action.type) {
    case 'close-menu':
      return {
        ...state,
        open: false,
      }
    case 'open-menu':
      return {
        ...state,
        open: true,
      }
    case 'open-popup':
      return {
        ...state,
        popup: {
          ...state.popup,
          open: true,
          type: action.popup,
        },
      }
    case 'close-popup':
      return {
        ...state,
        popup: {
          ...state.popup,
          open: false,
          type: null,
        },
      }
    case 'set-popup-loading':
      return {
        ...state,
        popup: {
          ...state.popup,
          loading: action.loading,
        },
      }
    case 'signin-success':
    case 'signup-success':
      return {
        ...state,
        popup: {
          ...state.popup,
          loading: false,
          open: false,
          type: null,
        },
      }
    case 'signin-error':
    case 'signup-error':
      return {
        ...state,
        popup: {
          ...state.popup,
          loading: false,
          open: false,
          type: null,
        },
      }
    default:
      return state
  }

  return state
}

const Menu = ({ group, clientInfo, layoutConfig, showOneLayerWithMenu, myGeo }) => {
  const menu = group?.data?.Menu
  const apolloClient = useApolloClient()

  const [state, dispatch] = useReducer(reducer, {
    open: false,
    popup: {
      open: false,
      type: null,
      loading: false,
    },
  })

  const rows = menu?.rows || []
  const renderRows = []
  const palette = group?.data?.palettes?.menu

  const escFunction = useCallback(event => {
    if (event.keyCode === 27) {
      showOneLayerWithMenu(0)
      dispatch({ type: 'close-menu' })
    }
  }, [])

  useEffect(() => {
    document.addEventListener('keydown', escFunction, false)

    return () => {
      document.removeEventListener('keydown', escFunction, false)
    }
  }, [])

  rows.forEach((row, index) => {
    const { type, columns, height } = row

    const renderColumns = []

    if (columns) {
      columns.forEach((column, colIndex) => {
        const { ratio, cellType, component, layer } = column

        let raw = ''
        let cellHeight = height
        let clickable = true
        const params = {
          group,
          height,
          data: component?.data,
          myGeo,
        }

        switch (cellType) {
          case CellType.Component:
            switch (component?.name) {
              case CellComponentType.Divider:
                raw = <Divider {...params} />
                clickable = false
                break
              case CellComponentType.MenuLayer:
                raw = <span>{component?.data?.text}</span>
                clickable = false
                break
              case CellComponentType.MenuTime:
                raw = <MenuTime {...params} />
                clickable = false
                break
              case CellComponentType.MenuLogo:
                raw = <MenuLogo {...params} />
                clickable = false
                break
              case CellComponentType.MenuEvents:
                cellHeight = 0
                raw = <MenuEvents {...params} />
                break
              case CellComponentType.MenuDivider:
                cellHeight = 0
                clickable = false
                raw = <MenuDivider {...params} />
                break
              case CellComponentType.Signin:
                raw = <span>{component?.name}</span>
                break
              default:
                raw = <span>{component?.name}</span>
                break
            }
            break
          case CellType.Group:
            raw = <span>Group: </span>
            break
          default:
            break
        }

        const itemClass = classnames('item', { clickable })

        renderColumns.push(
          <Col
            sm={ratio}
            key={colIndex}
            style={{ paddingLeft: 0, paddingRight: 0, height: cellHeight || 'inherit' }}
          >
            <div
              className={itemClass}
              onClick={() => {
                if (!clickable) return
                switch (component?.name) {
                  case CellComponentType.Signin:
                    dispatch({
                      type: 'open-popup',
                      popup: CellComponentType.Signin,
                    })
                    break
                  default:
                    if (layer >= 0) {
                      showOneLayerWithMenu(layer)
                    }
                    break
                }
                dispatch({ type: 'close-menu' })
              }}
            >
              {raw}
            </div>
          </Col>,
        )
      })
    }

    renderRows.push(<Row key={index}>{renderColumns}</Row>)
  })

  const paletteStyle = {
    backgroundColor: palette?.bg?.color || 'white',
    opacity: (100 - (palette?.bg?.transparency || 0)) / 100,
    color: palette?.fg?.color || 'white',
    fontWeight: palette?.fg?.weight,
    fontSize: palette?.fg?.size,
    width: layoutConfig?.canvas?.width,
    height: layoutConfig?.canvas?.height,
  }

  if (!rows.length) {
    return ''
  }

  let popupRender = ''

  if (state?.popup?.open) {
    switch (state?.popup?.type) {
      case CellComponentType.Signin:
        popupRender = (
          <SigninModal
            onCancel={() => {
              dispatch({ type: 'close-popup' })
            }}
            loading={state?.popup?.loading}
            onOk={username => {
              dispatch({ type: 'set-popup-loading', loading: true })
              apolloClient
                .query({
                  query: queries.groupingQuery,
                  variables: {
                    clientId: clientInfo._id,
                    type: '/Subscribers/',
                  },
                  fetchPolicy: 'network-only',
                })
                .then(({ data }) => {
                  const subscribers = data?.grouping
                  const user = subscribers?.find(subscriber => subscriber.name === username)

                  if (!user) {
                    apolloClient
                      .mutate({
                        mutation: mutations.createGroupingMutation,
                        variables: {
                          clientId: clientInfo._id,
                          type: '/Subscribers/',
                          name: username,
                          collectionName: 'Groupings',
                        },
                      })
                      .then(() => {
                        toastr.success('Successfully Signed up!', toastrOptions)
                        dispatch({ type: 'signup-success' })
                      })
                      .catch(err => {
                        toastr.error('Failed to Signup!', toastrOptions)
                        dispatch({ type: 'signup-error' })
                      })
                  } else {
                    toastr.success('Successfully Signed in!', toastrOptions)
                    dispatch({ type: 'signin-success' })
                  }
                })
                .catch(err => {
                  toastr.error('Failed to Signin/Signup!', toastrOptions)
                  dispatch({ type: 'signin-error' })
                })
            }}
          />
        )
        break
      default:
        break
    }
  }

  return (
    <div className="oe-menu">
      {!state?.open && (
        <Button variant="dark trigger" onClick={() => dispatch({ type: 'open-menu' })}>
          <FontAwesomeIcon icon={faBars} />
        </Button>
      )}
      {state?.open && (
        <div className="oe-menu-paper" style={paletteStyle}>
          {renderRows}
        </div>
      )}
      {state?.popup?.open ? popupRender : ''}
    </div>
  )
}

export default Menu
