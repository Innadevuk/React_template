import React from 'react'
import './MenuDivider.scss'

const MenuDivider = ({ group }) => {
  const palette = group?.data?.palettes?.menu

  console.log(palette?.divider)

  return (
    <div
      className="oe-menu-divider"
      style={{
        backgroundColor: palette?.divider?.color || 'white',
        height: palette?.divider?.weight,
      }}
    />
  )
}

export default MenuDivider
