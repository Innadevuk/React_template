import React from 'react'
import moment from 'moment'
import { DEFAULT_STYLE } from 'utils/defaultValues'
import objectAssignDeep from 'object-assign-deep'
import './Desc.scss'

const Desc = ({ group }) => {
  const groupStyleFrom = group?.style
  const style = objectAssignDeep({ ...DEFAULT_STYLE }, groupStyleFrom)
  const groupDesc = group?.data?.desc
  const palettes = group?.data?.palettes

  const icon = groupDesc?.icon
  const title = groupDesc?.title
  const shortDescr = groupDesc?.shortDescr
  const longDescr = groupDesc?.longDescr
  const image = groupDesc?.image
  const updatedAt = group?.updatedAt
  const imageHeight = style?.mediabox?.height || 30
  const width = style?.mediabox?.width

  const fgColor = style?.fg_color
  const bgColor = style?.bg_color
  const titleFgColor = style?.title?.fg_color
  const titleBgColor = style?.title?.bg_color

  const outline = {
    backgroundColor: titleBgColor,
    width,
    // height,
  }

  if (style?.b_outline === true) {
    outline.borderWidth = style?.outline?.width
    outline.borderStyle = 'solid'
    outline.borderColor = style?.outline?.color
    outline.borderRadius = style?.outline?.radius
  }

  if (style?.b_shadow === true) {
    outline.boxShadow = `3px 3px 3px${style?.shadow?.color}`
  }

  const groupTimeBarStyle = {
    display: style?.b_timestamp ? 'inherit' : 'none',
    color: titleFgColor,
    backgroundColor: 'rgba(196, 196, 196, 0.5)',
  }

  const minorDividerStyle = {
    backgroundColor: style?.b_divide_minor ? style?.divider_minor : 'inherit',
  }

  const bodyBarStyle = {
    color: fgColor,
    backgroundColor: bgColor,
  }

  const bodyStyle = {
    backgroundColor: palettes?.body?.bg?.color || 'white',
    opacity: (100 - (palettes?.body?.bg?.transparency || 0)) / 100,
    color: palettes?.body?.fg?.color || 'white',
    fontSize: palettes?.body?.font?.size,
  }

  const titleStyle = {
    backgroundColor: palettes?.title?.bg?.color || 'white',
    opacity: (100 - (palettes?.title?.bg?.transparency || 0)) / 100,
    color: palettes?.title?.fg?.color || 'white',
    fontSize: palettes?.title?.font?.size,
  }

  const timestamp = moment(updatedAt).format('MMM DD, hh:mm A')

  return (
    <div className="oe-group-grid-layout-descbox" style={outline}>
      <div className="oe-group-grid-layout-descbox-body">
        {(image || shortDescr || longDescr || title) && (
          <div className="oe-group-grid-layout-descbox-body-desc-bar" style={bodyBarStyle}>
            {/* {image?.url && <img style={{ height: imageHeight }} src={image?.url} alt="desc.clip" />} */}

            <div className="oe-group-grid-layout-descbox-body-desc-bar-text" style={bodyStyle}>
              <div
                className="oe-group-grid-layout-descbox-body-desc-bar-text-title"
                style={titleStyle}
              >
                {title}
              </div>
              <div className="oe-group-grid-layout-descbox-body-desc-bar-text-short">
                {shortDescr}
                {shortDescr && style?.b_divide_minor && (
                  <div
                    className="oe-group-grid-layout-descbox-body-desc-bar-text-divider"
                    style={minorDividerStyle}
                  />
                )}
              </div>
              <div className="oe-group-grid-layout-descbox-body-desc-bar-text-long">
                {longDescr}
              </div>
              {(icon || title || image || shortDescr || longDescr) && (
                <div
                  className="oe-group-grid-layout-descbox-header-time-bar"
                  style={groupTimeBarStyle}
                >
                  <div className="oe-group-grid-layout-descbox-header-time-bar-updatedAt">
                    Updated:&nbsp;
                    {timestamp}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default Desc
