/* eslint-disable react/forbid-prop-types */
import React from 'react'
import PropTypes from 'prop-types'
import { Player } from 'video-react'
import _ from 'lodash'
import './VideoFile.scss'

/**
 * @component VideoFile
 * Plays MP4 video of a Group
 * group->data->videoList
 *
 * @todo
 * finished
 *
 * @param {object} group
 */

const VideoFile = ({ group }) => {
  const videoURL = _.get(group, 'data.videoList.0.url')
  const autoLoop = group?.data?.layout?.autoLoop
  const autoStart = group?.data?.layout?.autoStart

  return (
    <div className="video-file">
      {videoURL && <Player src={videoURL} loop={autoLoop} autoPlay={autoStart} muted={autoStart} />}
    </div>
  )
}

VideoFile.propTypes = {
  group: PropTypes.object,
}

VideoFile.defaultProps = {
  group: {},
}

export default VideoFile
