/* eslint-disable react/forbid-prop-types */
import React from 'react'
import PropTypes from 'prop-types'
import { Player } from 'video-react'
import HLSSource from 'components/HLSSource'
import _ from 'lodash'
import './Streaming.scss'

/**
 * @component Streaming
 * Plays HLS stream video of a Group
 * group->streaming->broadband_url
 *
 * @todo
 * finished
 *
 * @param {object} group
 */

const Streaming = ({ group }) => {
  const streamURL = _.get(group, 'data.streamList.0.url')
  const autoLoop = group?.data?.stream?.autoLoop
  const autoStart = group?.data?.stream?.autoStart

  return (
    <div className="video-stream">
      {streamURL && (
        <Player loop={autoLoop} muted={autoStart}>
          <HLSSource isVideoChild src={streamURL} autoPlay={autoStart} />
        </Player>
      )}
    </div>
  )
}

Streaming.propTypes = {
  group: PropTypes.object,
}

Streaming.defaultProps = {
  group: {},
}

export default Streaming
