/* eslint-disable react/forbid-prop-types */
import React from 'react'
import PropTypes from 'prop-types'
import { makeStyles } from '@material-ui/core/styles'
import Badge from '@material-ui/core/Badge'
import * as queries from 'utils/queries'
import { useQuery } from '@apollo/react-hooks'
import _ from 'lodash'
import classnames from 'classnames'
import { isValidLocation } from 'utils/criteria'
import './MenuEvents.scss'

const useStyles = makeStyles(theme => ({
  root: {
    paddingLeft: theme.spacing(1.5),
  },
}))

const MenuEvents = ({ group, myGeo, data, height }) => {
  const classes = useStyles()
  const { loading, error, data: dataFolders } = useQuery(queries.groupingQuery, {
    variables: {
      // ids: null,
      type: data?.type,
    },
  })

  const folders = dataFolders?.grouping || []

  const validGroups = []

  for (const group of folders) {
    if (!group || !group.list) {
      // console.log('Group is invalid or there is no active article in the Group')
      continue
    }

    const groupLocation = _.get(group, 'data.location')

    const bAvailability = _.get(group, 'availability.state') === 'on' // OLD ACTIVE GROUPS
    const bSchedule =
      !_.get(group, 'schedule.bActive') || _.get(group, 'schedule.status') === 'active'
    const bGroupLocation = isValidLocation(groupLocation, myGeo)

    if (!bAvailability) continue
    if (!bSchedule) continue
    if (!bGroupLocation) continue

    validGroups.push(group)
  }

  const eventClass = classnames('oe-menuevents', { hide: !validGroups.length })

  return (
    <div className={eventClass} style={{ height }}>
      <Badge
        className={classes.root}
        badgeContent={validGroups.length}
        color="error"
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'left',
        }}
      >
        {data?.text}
      </Badge>
    </div>
  )
}

MenuEvents.propTypes = {
  group: PropTypes.object,
}

MenuEvents.defaultProps = {
  group: {},
}

export default MenuEvents
