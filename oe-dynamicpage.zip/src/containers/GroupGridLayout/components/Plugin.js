/* eslint-disable no-loop-func */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable react/forbid-prop-types */
import React, { useState, useEffect } from 'react'
import PropTypes from 'prop-types'
import * as queries from 'utils/queries'
import { Spinner, Dropdown } from 'react-bootstrap'
import { useQuery } from '@apollo/react-hooks'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faChevronRight, faChevronLeft } from '@fortawesome/free-solid-svg-icons'
import ItemsCarousel from 'react-items-carousel'
import _ from 'lodash'
import { isValidLocation } from 'utils/criteria'
import './Plugin.scss'

/**
 * @component Plugin
 * Plays HLS stream video of a Group
 * group->data->mainwidget
 *
 * list: [
 *  action: array().of(string)
 *  classname: string
 *  displayname: string
 *  name: string
 *  type: string (group type)
 *  url: string (url)
 * ]
 *
 * @todo
 * progress
 *
 * @param {object} group
 */

const Plugin = ({ group, setGroupId, myGeo }) => {
  const [currentPluginIndex, setCurrentPluginIndex] = useState(0)
  const [currentGroupIndex, setCurrentGroupIndex] = useState(0)

  const list = group?.data?.mainwidget?.list || []
  const palette = group?.data?.palettes?.body

  const { loading: loadingFolders, error: errorFolders, data: dataFolders } = useQuery(
    queries.groupingQuery,
    {
      variables: {
        ids: list,
      },
    },
  )

  const folders = dataFolders?.grouping || []
  const validGroupTypes = []
  const validGroups = []

  const doAction = (actionType, group) => {
    switch (actionType) {
      case 'Load':
        setGroupId(group._id)
        break
      case 'Hide':
        console.log('Hide Action')
        break
      case 'Show':
        console.log('Show Action')
        break
      default:
        break
    }
  }

  useEffect(() => {
    if (validGroupTypes?.length === 1 && validGroups?.length === 1) {
      const actions = validGroups[0]?.data?.actions || []
      console.log(actions[0], validGroups[0])
      if (actions.length === 1) {
        doAction(actions[0], validGroups[0])
      }
    }
  }, [validGroupTypes?.length, validGroups?.length])

  for (const group of folders) {
    if (!group || !group.list) {
      // console.log('Group is invalid or there is no active article in the Group')
      continue
    }

    const groupLocation = _.get(group, 'data.location')

    const bAvailability = _.get(group, 'availability.state') === 'on' // OLD ACTIVE GROUPS
    const bSchedule =
      !_.get(group, 'schedule.bActive') || _.get(group, 'schedule.status') === 'active'
    const bGroupLocation = isValidLocation(groupLocation, myGeo)

    if (!bAvailability) continue
    if (!bSchedule) continue
    if (!bGroupLocation) continue

    validGroupTypes.push(group)
  }

  const current = validGroupTypes[currentPluginIndex] || null

  const { loading, error, data } = useQuery(queries.groupingQuery, {
    skip: !current,
    variables: {
      type: current ? current.type + current.name : null,
      collectionName: 'Groupings',
    },
  })

  if (!validGroupTypes?.length) {
    return ''
  }

  const groups = data?.grouping?.filter(group => !group.name.endsWith('/')) || []

  for (const group of groups) {
    if (!group || !group.list) {
      // console.log('Group is invalid or there is no active article in the Group')
      continue
    }

    const groupLocation = _.get(group, 'data.location')

    const bAvailability = _.get(group, 'availability.state') === 'on' // OLD ACTIVE GROUPS
    const bSchedule =
      !_.get(group, 'schedule.bActive') || _.get(group, 'schedule.status') === 'active'
    const bGroupLocation = isValidLocation(groupLocation, myGeo)

    if (!bAvailability) continue
    if (!bSchedule) continue
    if (!bGroupLocation) continue

    validGroups.push(group)
  }

  const paletteStyle = {
    backgroundColor: palette?.bg?.color || 'white',
    opacity: (100 - (palette?.bg?.transparency || 0)) / 100,
    color: palette?.fg?.color || 'white',
    fontWeight: palette?.fg?.weight,
    fontSize: palette?.fg?.size,
  }
  console.log('group----------------', data)
  console.log('list----------------', list)
  return (
    <div className="oe-plugin" style={paletteStyle}>
      {/* <div className="oe-plugin-live-stream" /> */}
      <ItemsCarousel
        // Carousel configurations
        numberOfCards={1}
        gutter={10}
        // Active item configurations
        requestToChangeActive={number => {
          setCurrentGroupIndex(0)
          setCurrentPluginIndex(number % validGroupTypes?.length)
        }}
        activeItemIndex={currentPluginIndex}
        activePosition="center"
        chevronWidth={20}
        rightChevron={validGroupTypes?.length > 1 ? <FontAwesomeIcon icon={faChevronRight} /> : ''}
        leftChevron={validGroupTypes?.length > 1 ? <FontAwesomeIcon icon={faChevronLeft} /> : ''}
        classes={{ wrapper: 'oe-plugin-list' }}
        infiniteLoop
      >
        {validGroupTypes?.map((group, index) => (
          <div key={index} className="oe-plugin-item">
            <span>{group.name}</span>
          </div>
        ))}
      </ItemsCarousel>
      {loading && (
        <div className="oe-plugin-group-list loading">
          <Spinner animation="border" role="status" size="sm">
            <span className="sr-only">Loading...</span>
          </Spinner>
        </div>
      )}
      {!loading && (
        <ItemsCarousel
          // Carousel configurations
          numberOfCards={4}
          gutter={10}
          // Active item configurations
          requestToChangeActive={number => {
            setCurrentGroupIndex(number % validGroups?.length)
          }}
          activeItemIndex={currentGroupIndex}
          activePosition="center"
          chevronWidth={20}
          rightChevron={<FontAwesomeIcon icon={faChevronRight} />}
          leftChevron={<FontAwesomeIcon icon={faChevronLeft} />}
          classes={{ wrapper: 'oe-plugin-group-list' }}
          infiniteLoop
        >
          {validGroups?.map((group, index) => {
            const actions = group?.data?.actions || []

            if (actions.length <= 1) {
              return (
                <div className="oe-plugin-group-item" key={group?._id}>
                  <span
                    onClick={() => {
                      if (actions.length) {
                        doAction(actions[0], group)
                      }
                    }}
                  >
                    {group?.data?.desc?.title || 'No Title'}
                  </span>
                </div>
              )
            }

            return (
              <div className="oe-plugin-group-item" key={group?._id}>
                <Dropdown key={index}>
                  <Dropdown.Toggle>
                    <span>{group?.data?.desc?.title || 'No Title'}</span>
                  </Dropdown.Toggle>

                  <Dropdown.Menu>
                    {actions.map((action, index) => (
                      <Dropdown.Item key={index} onClick={() => doAction(action, group)}>
                        {action}
                      </Dropdown.Item>
                    ))}
                  </Dropdown.Menu>
                </Dropdown>
              </div>
            )
          })}
        </ItemsCarousel>
      )}
    </div>
  )
}

Plugin.propTypes = {
  group: PropTypes.object,
}

Plugin.defaultProps = {
  group: {},
}

export default Plugin
