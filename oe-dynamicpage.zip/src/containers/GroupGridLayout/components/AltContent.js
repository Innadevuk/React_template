/* eslint-disable react/forbid-prop-types */
import React, { useState } from 'react'
import PropTypes from 'prop-types'
import * as queries from 'utils/queries'
import { useQuery } from '@apollo/react-hooks'
import ItemsCarousel from 'react-items-carousel'
import { Spinner } from 'react-bootstrap'
import _ from 'lodash'
import { isValidLocation } from 'utils/criteria'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faChevronRight, faChevronLeft } from '@fortawesome/free-solid-svg-icons'
import './AltContent.scss'

const AltContent = ({ group, myGeo, setGroupId, rowHeight }) => {
  const [currentGroupIndex, setCurrentGroupIndex] = useState(0)
  const palette = group?.data?.palettes?.body

  const { loading, error, data: dataFolders } = useQuery(queries.groupingQuery, {
    variables: {
      type: `${group.type}${group.name}`,
    },
  })

  const onSelectGroup = _id => {
    setGroupId(_id)
  }

  const folders = dataFolders?.grouping || []

  const validGroups = []

  for (const group of folders) {
    if (!group || group.name?.endsWith('/')) {
      // console.log('Group is invalid or there is no active article in the Group')
      continue
    }

    const groupLocation = _.get(group, 'data.location')

    const bAvailability = _.get(group, 'availability.state') === 'on' // OLD ACTIVE GROUPS
    const bSchedule =
      !_.get(group, 'schedule.bActive') || _.get(group, 'schedule.status') === 'active'
    const bGroupLocation = isValidLocation(groupLocation, myGeo)

    if (!bAvailability) continue
    if (!bSchedule) continue
    if (!bGroupLocation) continue

    validGroups.push(group)
  }

  const paletteStyle = {
    backgroundColor: palette?.bg?.color || 'white',
    opacity: (100 - (palette?.bg?.transparency || 0)) / 100,
    color: palette?.fg?.color || 'white',
    fontWeight: palette?.fg?.weight,
    fontSize: palette?.fg?.size,
  }

  return (
    <div className="oe-altcontent" style={paletteStyle}>
      {loading && (
        <div className="oe-altcontent-group-list  loading" style={{ height: rowHeight || '60px' }}>
          <Spinner animation="border" role="status" size="sm">
            <span className="sr-only">Loading...</span>
          </Spinner>
        </div>
      )}
      {!loading && (
        <ItemsCarousel
          // Carousel configurations
          numberOfCards={4}
          gutter={10}
          // Active item configurations
          requestToChangeActive={number => {
            setCurrentGroupIndex(number % validGroups?.length)
          }}
          activeItemIndex={currentGroupIndex}
          activePosition="center"
          chevronWidth={20}
          rightChevron={<FontAwesomeIcon icon={faChevronRight} />}
          leftChevron={<FontAwesomeIcon icon={faChevronLeft} />}
          classes={{ wrapper: 'oe-altcontent-group-list ' }}
          style={{ height: rowHeight || '60px' }}
          infiniteLoop
        >
          {validGroups?.map((group, index) => {
            return (
              <div
                className="oe-altcontent-group-item"
                key={group?._id}
                style={{ height: rowHeight || '60px' }}
              >
                <span
                  onClick={() => {
                    onSelectGroup(group._id)
                  }}
                >
                  {group?.name || 'No Title'}
                </span>
              </div>
            )
          })}
        </ItemsCarousel>
      )}
    </div>
  )
}

AltContent.propTypes = {
  group: PropTypes.object,
}

AltContent.defaultProps = {
  group: {},
}

export default AltContent
