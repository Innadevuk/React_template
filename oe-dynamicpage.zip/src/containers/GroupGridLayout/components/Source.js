import React from 'react'
import './Source.scss'

const Source = ({ group }) => {
  const source = group?.data?.source

  return <div className="oe-source">{source?.logo && <img src={source?.logo} alt="source" />}</div>
}

export default Source
