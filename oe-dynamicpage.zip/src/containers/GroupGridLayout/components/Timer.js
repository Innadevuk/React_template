import React from 'react'
import { useQuery } from '@apollo/react-hooks'
import * as queries from 'utils/queries'

const Timer = ({ data, group, style, timerInfo }) => {
  const { loading: loadingFolders, error: errorFolders, data: dataFolders } = useQuery(
    queries.groupingQuery,
    {
      variables: {
        ids: timerInfo?.expired ? [] : [timerInfo?.groupId],
      },
    },
  )

  const documents = dataFolders?.grouping || []
  const document = documents ? documents[0] : null

  if (timerInfo?.expired) {
    return <div className="oe-timer">Timer Expried</div>
  }

  if (loadingFolders) {
    return <div className="oe-timer">Current Timer Group: Loading...</div>
  }

  return <div className="oe-timer">Current Timer Group: {document?.name}</div>
}

export default Timer
