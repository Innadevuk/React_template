/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React, { useState, useEffect } from 'react'
import _ from 'lodash'
import classnames from 'classnames'
import { Row, Col } from 'react-bootstrap'
import objectAssignDeep from 'object-assign-deep'
import { DEFAULT_STYLE } from 'utils/defaultValues'
import { CellType, CellComponentType } from './utis'

import {
  Streaming,
  Body,
  VideoList,
  Desc,
  Plugin,
  Map,
  Time,
  ImageList,
  Contact,
  List,
  HourglassTimer,
  Source,
  Menu,
  Exit,
  Notification,
  Timer,
  VideoFile,
  URL,
  WebLinks,
  NavList,
  AltContent,
  TxList,
} from './components/index'
import './index.scss'

const renderCell = (
  { ratio, cellType, component },
  group,
  setGroupId,
  myGeo,
  setLayerVisible,
  setOverride,
  timerInfo,
  rowHeight,
  layoutConfig,
  showOneLayerWithMenu,
  clientInfo,
) => {
  let raw = ''

  switch (cellType) {
    case CellType.Component:
      {
        const name = _.get(component, 'name')
        const data = _.get(component, 'data') || {}
        const style = objectAssignDeep({ ...DEFAULT_STYLE }, _.get(component, 'style'))
        const params = {
          group,
          data,
          style,
          setGroupId,
          myGeo,
          hideLayer: () => {
            console.log('hideLayer')
            setLayerVisible(false)
          },
          setOverride,
          timerInfo,
          rowHeight,
          layoutConfig,
          showOneLayerWithMenu,
          clientInfo,
        }

        switch (name) {
          case CellComponentType.ImageList:
            raw = <ImageList {...params} />
            break
          case CellComponentType.Streaming:
            raw = <Streaming {...params} />
            break
          case CellComponentType.Body:
            raw = <Body {...params} />
            break
          case CellComponentType.VideoList:
            raw = <VideoList {...params} />
            break
          case CellComponentType.Desc:
            raw = <Desc {...params} />
            break
          case CellComponentType.Plugin:
            raw = <Plugin {...params} />
            break
          case CellComponentType.Map:
            raw = <Map {...params} />
            break
          case CellComponentType.Time:
            raw = <Time {...params} />
            break
          case CellComponentType.Contact:
            raw = <Contact {...params} />
            break
          case CellComponentType.List:
            raw = <List {...params} />
            break
          case CellComponentType.HourglassTimer:
            raw = <HourglassTimer {...params} />
            break
          case CellComponentType.Source:
            raw = <Source {...params} />
            break
          case CellComponentType.Menu:
            raw = <Menu {...params} />
            break
          case CellComponentType.Exit:
            raw = <Exit {...params} />
            break
          case CellComponentType.Notification:
            raw = <Notification {...params} />
            break
          case CellComponentType.Timer:
            raw = <Timer {...params} />
            break
          case CellComponentType.VideoFile:
            raw = <VideoFile {...params} />
            break
          case CellComponentType.URL:
            raw = <URL {...params} />
            break
          case CellComponentType.WebLinks:
            raw = <WebLinks {...params} />
            break
          case CellComponentType.NavList:
            raw = <NavList {...params} />
            break
          case CellComponentType.AltContent:
            raw = <AltContent {...params} />
            break
          case CellComponentType.TxList:
            raw = <TxList {...params} />
            break
          default:
            break
        }
      }
      break
    /*
    case CellType.Group:
      raw = (
        <FilterGroup groupId={_.get(group, '_id')} myGeo={myGeo}>
          <ContentGroup clientInfo={clientInfo} />
        </FilterGroup>
      )
      break
    */

    /*
    case CellType.GroupType:
      {
        const name = _.get(groupType, 'name')
        const data = _.get(groupType, 'data') || {}
        const style = _.get(groupType, 'style') || {}

        const dismissable = !['DND', 'Areas', 'SubAreas', 'Cases'].includes(name)
        const commonNotificationProps = {
          myGeo,
          clientInfo,
        }

        raw = (
          <NotificationClient
            {...commonNotificationProps}
            groupType={name}
            data={data}
            style={style}
            dismissable={dismissable}
          />
        )
      }
      break
      */
    default:
      break
  }

  return raw
}

const GroupGridLayout = ({
  group,
  layoutConfig,
  override,
  myGeo,
  clientInfo,
  setGroupId,
  visible,
  setLayerVisible,
  setOverride,
  offsetList,
  showOneLayerWithMenu,
}) => {
  const rows = layoutConfig?.rows || []
  const renderRows = []
  const [timerInfo, setTimerInfo] = useState({
    expired: false,
    groupId: null,
    index: -1,
  })
  const [pos, setPos] = useState(0)

  // { datetime, duration, groupId }

  useEffect(() => {
    if (visible === false) {
      setPos(0)
    } else {
    }
  }, [visible])

  useEffect(() => {
    let handle = null
    if (!visible) {
      clearTimeout(handle)

      return
    }

    let next = -1

    for (let i = 0; i < offsetList.length; i += 1) {
      if (offsetList[i].datetime > pos) {
        next = i
        break
      }
    }

    if (next >= 0) {
      const nextPos = offsetList[next].datetime
      const nextGroupId = offsetList[next].groupId
      console.log(pos, next >= 0 ? offsetList[next].datetime : -1, nextGroupId)
      handle = setTimeout(() => {
        if (visible) {
          console.log('next item')
          setTimerInfo({ groupId: nextGroupId, expired: false, index: next })
          setPos(nextPos)
        }
      }, 1000 * (nextPos - pos))
    } else {
      handle = setTimeout(
        () => {
          console.log('let expire')
          setTimerInfo({ groupId: null, expired: true, index: -1 })
        },
        timerInfo.index >= 0 ? 1000 * offsetList[timerInfo.index].duration : 0,
      )
    }

    return () => clearTimeout(handle)
  }, [pos])

  if (override?.cellType) {
    renderRows.push(
      <Row>
        <Col sm={12} style={{ paddingLeft: 0, paddingRight: 0 }}>
          {renderCell(
            { ratio: 12, cellType: override?.cellType, component: override?.component },
            group,
            setGroupId,
            myGeo,
            setLayerVisible,
            setOverride,
            timerInfo,
            rows?.length ? rows[0].height : undefined,
            layoutConfig,
            showOneLayerWithMenu,
            clientInfo,
          )}
        </Col>
      </Row>,
    )
  } else {
    rows.forEach((row, index) => {
      const { type, columns, height } = row

      const renderColumns = []

      if (columns) {
        columns.forEach((column, colIndex) => {
          const { ratio } = column

          renderColumns.push(
            <Col
              sm={ratio}
              key={colIndex}
              style={{ paddingLeft: 0, paddingRight: 0 }}
              className="col-cell"
            >
              {renderCell(
                column,
                group,
                setGroupId,
                myGeo,
                setLayerVisible,
                setOverride,
                timerInfo,
                height,
                layoutConfig,
                showOneLayerWithMenu,
                clientInfo,
              )}
            </Col>,
          )
        })
      }
      renderRows.push(
        <Row key={index} style={{ height, overflow: 'hidden' }}>
          {renderColumns}
        </Row>,
      )
    })
  }

  return (
    <section className={classnames('oe-group-grid-layout', { show: visible })}>
      {renderRows}
    </section>
  )
}

GroupGridLayout.displayName = 'ContentGroup'
export default GroupGridLayout
