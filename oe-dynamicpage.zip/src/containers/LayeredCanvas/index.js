import React, { useState, useEffect } from 'react'
import classnames from 'classnames'
import moment from 'moment'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faUndoAlt } from '@fortawesome/free-solid-svg-icons'
import GroupGridLayout from '../GroupGridLayout'
import './index.scss'

const INIT_CELL = {
  cellType: null,
}

const LayeredCanvas = ({ group, groupId, myGeo, clientInfo, setGroupId, hasBack, goBack }) => {
  const layers = group?.data?.LayoutConfig || []
  const [visibles, setVisibles] = useState(layers.map(item => item.visible || false))
  const [overrides, setOverrides] = useState([
    INIT_CELL,
    INIT_CELL,
    INIT_CELL,
    INIT_CELL,
    INIT_CELL,
    INIT_CELL,
    INIT_CELL,
    INIT_CELL,
    INIT_CELL,
    INIT_CELL,
  ])

  useEffect(() => {
    setVisibles(layers.map(item => item.visible || false))
    setOverrides([
      INIT_CELL,
      INIT_CELL,
      INIT_CELL,
      INIT_CELL,
      INIT_CELL,
      INIT_CELL,
      INIT_CELL,
      INIT_CELL,
      INIT_CELL,
      INIT_CELL,
    ])
  }, [groupId])

  const showOneLayerWithMenu = index => {
    const newVisibles = [...visibles]
    for (let i = 0; i < newVisibles.length; i++) {
      if (i === 0 || i === 9 || i === index) {
        newVisibles[i] = true
      } else {
        newVisibles[i] = false
      }
    }

    setVisibles([...newVisibles])
  }

  const offset = group?.data?.offset
  const baseWidth = group?.data?.Canvasbase?.width || 1280
  const baseHeight = group?.data?.Canvasbase?.height || 720
  const outline = group?.data?.palettes?.canvas?.outline
  const shadow = group?.data?.palettes?.canvas?.shadow

  const list =
    offset?.list?.map(item => ({
      ...item,
      datetime:
        moment(item.datetime).hours() * 3600 +
        moment(item.datetime).minutes() * 60 +
        moment(item.datetime).seconds(),
    })) || []

  const sorted = list.sort((a, b) => {
    return a.datetime - b.datetime
  })

  return (
    <div
      className="oe-canvas-base"
      style={{
        width: baseWidth,
        height: baseHeight,
        borderRadius: outline?.radius,
        borderWidth: outline?.weight,
        borderColor: outline?.color,
        borderStyle: 'solid',
        boxShadow: `3px 3px 3px ${shadow?.color}`,
      }}
    >
      {layers.map((layer, index) => (
        <section
          className={classnames(
            'oe-layered-canvas',
            layer?.position?.horizontal || 'left',
            layer?.position?.vertical || 'top',
          )}
          key={index}
          style={{
            opacity: (100.0 - (layer?.canvas?.transparency || 0)) / 100.0,
            maxWidth: layer?.canvas?.width || 1280,
            height: layer?.canvas?.height || (layer?.rows?.length ? 'unset' : 0),
          }}
        >
          <GroupGridLayout
            layoutConfig={layer}
            override={overrides[index]}
            setOverride={(overrideIndex, cell) => {
              setOverrides([
                ...overrides.slice(0, overrideIndex),
                cell,
                ...overrides.slice(overrideIndex + 1),
              ])
            }}
            myGeo={myGeo}
            group={group}
            setGroupId={setGroupId}
            visible={visibles[index]}
            offsetList={sorted}
            setLayerVisible={show => {
              setVisibles([...visibles.slice(0, index), show, ...visibles.slice(index + 1)])
            }}
            showOneLayerWithMenu={showOneLayerWithMenu}
            clientInfo={clientInfo}
          />
        </section>
      ))}
      {hasBack ? (
        <span className="btn-back">
          <FontAwesomeIcon
            icon={faUndoAlt}
            color="#ffffff"
            size="sm"
            onClick={() => {
              goBack()
            }}
          />
        </span>
      ) : (
        ''
      )}
    </div>
  )
}

LayeredCanvas.displayName = 'LayeredCanvas'
export default LayeredCanvas
